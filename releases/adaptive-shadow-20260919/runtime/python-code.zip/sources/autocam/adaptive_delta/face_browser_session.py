"""Face-family browser transport using the existing recording/publication path."""
from .drill_browser_session import DrillBrowserSession, _encode_browser
from .face_candidates import FaceGenerationRequest, generate_face_candidates, commit_face_candidate


def encode_face_browser(initial, session, request):
    return _encode_browser(initial, session, request, FaceBrowserSession)


class FaceBrowserSession(DrillBrowserSession):
    FAMILY = 'face'
    REQUEST = FaceGenerationRequest
    _generate = staticmethod(generate_face_candidates)
    _select = staticmethod(commit_face_candidate)

    @staticmethod
    def _eligible(session): return session._face

    @staticmethod
    def _preview_rows(rows): return [row for row in rows if row['alias_of'] is None]

    def invoke(self, raw_request):
        from .drill_browser_session import request_data, bounded
        request = request_data(raw_request)
        if request.get('operation') == 'shadow_view':
            if type(self) is not FaceBrowserSession: raise ValueError('Shadow projection requires the face session family')
            from .directional_shadow_session import directional_shadow_response
            return directional_shadow_response(self, request)
        if request.get('operation') != 'assembly_view': return super().invoke(raw_request)
        from .domain import fields
        fields(request, ('operation','session_epoch','expected_semantic_id','batch_id','candidate_id'))
        if type(self) is not FaceBrowserSession: raise ValueError('Assembly projection requires the face session family')
        return face_assembly_response(self, request)

    def geometry(self):
        from .codec import parse_canonical
        from .inspection import project_frame, inspection_bundle
        with self.session._lock:
            state = self.session._journal.material
            observation = self.observe()
            frame = project_frame(state, label='Accepted face-session material', outcome=None)
            bundle = parse_canonical(inspection_bundle(state.domain.source, [frame], face_state=True,
                replay=dict(status='not_run', scope='current_face_session_projection'),
                provenance=dict(projection='shared_python_prepared_face_state',
                    configuration_id=self.config_id, semantic_id=observation['semantic_id'])))
            return dict(schema=self._schema('geometry'), session_epoch=self.epoch,
                observation=observation, inspection_bundle=bundle)


def face_assembly_response(self, request):
    """Shared projection for an explicitly admitted browser family; no mutation."""
    from .drill_browser_session import bounded
    from .domain import fields, identity, qread
    from .codec import parse_canonical
    from .candidate_identity import CandidateSpec
    from .face_operation import FaceOperation
    from .face_assembly_view import FaceAssemblyView
    from .geometry import IndexedSolid, Union
    fields(request, ('operation','session_epoch','expected_semantic_id','batch_id','candidate_id'))
    if type(request['session_epoch']) is not int or request['session_epoch'] != self.epoch:
        raise ValueError('Stale face assembly session epoch')
    with self.session._lock:
        journal = self.session._journal
        if request['expected_semantic_id'] != self.session.semantic_id:
            raise ValueError('Stale face assembly semantic state')
        batch = self._batches.get(request['batch_id'])
        if batch is None: raise ValueError('Unknown face assembly batch')
        data = batch.to_data()
        if data['before_semantic_id'] != self.session.semantic_id or data['before_journal_id'] != identity(journal.export()):
            raise ValueError('Stale face assembly batch')
        rows = self._preview_rows([row for row in data['rows'] if row['candidate'] is not None and identity(row['candidate']) == request['candidate_id']])
        if len(rows) != 1: raise ValueError('Unknown face assembly candidate')
        row = rows[0]; candidate = CandidateSpec.from_data(row['candidate']); parameters = parse_canonical(candidate.parameters)
        operation = FaceOperation.from_data(parameters['operation'])
        tips = tuple(tuple(qread(v) for v in p) for p in parameters['approach_tips'])
        if self.session.candidate_face(operation,parameters['tool_id'],approach_tips=tips) != candidate:
            raise ValueError('Face assembly candidate binding differs')
        pose = journal._machine.select(operation.orientation_id)
        fixed = Union((IndexedSolid(journal._fixture,pose),journal._stationary))
        view = FaceAssemblyView(journal.material,parameters['tool_id'],operation,pose,fixed,self.session.semantic_id)
        accepted_pose = journal.semantic_snapshot()['orientation_id']
        context = dict(schema='adaptive-face-obstacle-context-1',machine_id=journal._machine.id,
            fixture_part=journal._fixture.to_data(),stationary_machine=journal._stationary.to_data(),
            accepted_orientation_id=accepted_pose,candidate_orientation_id=pose.id,
            pose_is_current=pose.id == accepted_pose)
        return bounded(dict(schema=self._schema('assembly'),session_epoch=self.epoch,
            observation=self.observe(),batch_id=batch.id,candidate_id=candidate.id,row=row,
            obstacle_context=context,projection=view.to_data())).decode('utf-8')
