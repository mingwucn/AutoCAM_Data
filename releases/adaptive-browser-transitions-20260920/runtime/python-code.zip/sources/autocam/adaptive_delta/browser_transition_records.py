"""Immutable publication supplements for selected direct-browser writer forks."""
import base64
from dataclasses import dataclass, replace
from hashlib import sha256
import json

from .codec import encode_snapshot
from .domain import canonical, identity, qdata
from .publication_evidence import publication_evidence

MAX_RECORDS = 128
MAX_BYTES = 64*1024**2


def snapshot_bytes(domain):
    from .packed_domain import PackedDomainSnapshot, verify_packed_partition
    if type(domain) is PackedDomainSnapshot:
        verify_packed_partition(domain)
        return b''.join(domain.canonical_snapshot_chunks())
    return encode_snapshot(domain)


@dataclass(frozen=True, slots=True)
class BrowserTransitionRecords:
    initial_state: bytes
    final_hash: str
    normalizer: object
    snapshots: tuple
    external_initial: str | None = None
    records: tuple = ()

    @classmethod
    def start(cls, service, *, initial_snapshot=None):
        state=service.state
        if state.revision!=0 or state.parent_event is not None:
            raise ValueError('Browser capture requires a fresh material writer')
        raw=snapshot_bytes(state.domain)
        pin=sha256(raw).hexdigest()
        external=pin if initial_snapshot is not None and sha256(initial_snapshot).hexdigest()==pin else None
        result=cls(canonical(state.to_data()),state.logical_hash,service.normalizer,
                   ((pin,raw),),external)
        result.check_budget()
        return result

    def data(self):
        return dict(schema='adaptive-browser-transition-record-1',
            initial_material=json.loads(self.initial_state),final_state_hash=self.final_hash,
            normalizer_mm3=qdata(self.normalizer),
            snapshots=[dict(sha256=pin,size_bytes=len(raw),**(
                       dict(source='bound_episode_initial_snapshot') if pin==self.external_initial else
                       dict(base64=base64.b64encode(raw).decode('ascii'))))
                       for pin,raw in self.snapshots],
            records=[json.loads(raw) for raw in self.records],
            verification='captured_at_accepted_publication_not_independently_replayed',
            manufacturing_qualified=False)

    def check_budget(self):
        # Reserve more than the fixed export binding fields require.
        if len(self.records)>MAX_RECORDS or len(canonical(self.data()))+1024>MAX_BYTES:
            raise ValueError('Browser transition record budget exceeded')

    def export(self, episode, *, task_sha256, initial_sha256):
        raw=episode.encode('utf-8')
        data=dict(self.data(),episode=dict(sha256=sha256(raw).hexdigest(),size_bytes=len(raw)),
                  task_sha256=task_sha256,initial_snapshot_sha256=initial_sha256)
        encoded=canonical(data)
        if len(encoded)>MAX_BYTES:raise ValueError('Browser transition record budget exceeded')
        return encoded.decode('ascii')


class BrowserTransitionCapture:
    """Temporary sink; its successor is published only with the browser response."""
    def __init__(self, records):self.records=records

    def synchronize(self, service):
        if service.state.logical_hash!=self.records.final_hash or service.normalizer!=self.records.normalizer:
            raise ValueError('Browser publication writer differs from captured history')

    def record_rejection(self, proposal, event_key, request_id, result):
        if (result.before_hash!=self.records.final_hash or result.after_hash!=self.records.final_hash
                or result.status not in ('REJECTED','UNRESOLVED')):
            raise ValueError('Rejected browser attempt changes captured material')

    def publish(self, before, after, event, result, receipts):
        records=self.records
        if before.logical_hash!=records.final_hash:
            raise ValueError('Browser publication is not the selected material successor')
        snapshots=dict(records.snapshots)
        # The existing writer has already computed the after-partition artifact.
        # Re-encode unseen partitions and verify that exact binding before capture.
        before_ref=sha256(snapshot_bytes(before.domain)).hexdigest()
        after_ref=event['domain_artifact']
        if before_ref not in snapshots:raise ValueError('Missing accepted predecessor partition')
        if after.domain is before.domain:
            if after_ref!=before_ref:raise ValueError('Changed publication partition bytes')
        else:
            raw=snapshot_bytes(after.domain)
            if sha256(raw).hexdigest()!=after_ref:raise ValueError('Changed publication partition bytes')
        if after_ref not in snapshots:
            snapshots[after_ref]=raw
        previous=json.loads(records.records[-1])['evidence_sha256'] if records.records else None
        evidence=publication_evidence(before,after,event,result,
            before_domain_artifact=before_ref,after_domain_artifact=after_ref,
            normalizer=records.normalizer,previous_evidence=previous)
        row=canonical(dict(event=event,event_sha256=identity(event),
                           evidence=evidence,evidence_sha256=identity(evidence)))
        following=replace(records,final_hash=after.logical_hash,snapshots=tuple(snapshots.items()),
                          records=records.records+(row,))
        following.check_budget()
        self.records=following
