"""Framework-neutral description and probes for the unchanged v4 consumer."""
from hashlib import sha256
import json
import math

FEATURE_PIN = '22b6041ed7471e2563a4ff80765d73c3dd8d21590950fc2c671c02035eebfa93'
OBJECTIVE = 'shadow-gym-bounded-fixed-axis-core-roughing-v4'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def definition(feature_bytes):
    require(sha256(feature_bytes).hexdigest() == FEATURE_PIN, 'Unsupported exact feature contract')
    f = json.loads(feature_bytes)
    return dict(schema='task-model-definition-1', version='1.0.0', objective_id=OBJECTIVE,
        task_schema=f['task_schema'], features_sha256=FEATURE_PIN,
        compatible_feature_schemas=[f['schema']],
        inputs=dict(features=dict(shape=['N', 54], candidate_count=[1, 505],
            dtype='binary64', units='dimensionless', finite=True, range=[-1, 1],
            fields=f['candidate']+f['global'], composition='candidate50_then_repeated_global4'),
            mask=dict(shape=['N'], dtype='integer', values=[0, 1], minimum_enabled=1,
                meaning=f['mask'])),
        outputs=dict(selected_index=dict(shape=[], dtype='integer', range='0 <= index < N',
            units='supplied_candidate_index', mask_required=True)),
        architecture=[dict(operation='shared_linear_score', inputs=['features', 'weights'],
            output='internal_action_scores'), dict(operation='masked_argmax',
            inputs=['internal_action_scores', 'mask'], output='selected_index', ties='first_supplied_index')],
        parameters=dict(count=54, shape=[54], dtype='binary64', finite=True,
            constraint='sum(abs(weights)) must be finite'),
        initialization=dict(fresh_parameters='all_zero', restored_parameters='externally_bound_exact_state'),
        precision=dict(products='binary64_round_to_nearest_even',
            accumulation='accurate_sum_of_rounded_products', output='finite_binary64'),
        loss_semantics='internal uncalibrated linear action-value score; no probability or separate state-value output',
        ordering=dict(scores='row_permutation_equivariant',
            selection='unique_winner_equivariant; ties_follow_supplied_order',
            geometry_rotation_invariance=False),
        serialization=dict(schema='adaptive-linear-q-checkpoint-4',
            fields=['schema', 'features', 'feature_contract_id', 'weights'],
            feature_identity='original canonical feature-contract identity; distinct from file SHA-256'),
        claim_level='bounded fixed-axis research consumer', limitations=[
            'Partial observations; no independent state-value head.',
            'MCTS is a separate planner with separate configuration.',
            'No arbitrary STEP, indexed machining, unfamiliar-family generalization or manufacturing qualification.'])


def probe(checkpoint, vectors, make_checkpoint, scores, select):
    """Exercise caller-authenticated frozen functions; never fit or change weights."""
    weights = checkpoint['weights']
    require(len(weights) == 54 and all(type(v) in (int, float) and math.isfinite(v) for v in weights),
            'Invalid finite parameter vector')
    try:
        require(math.isfinite(math.fsum(abs(v) for v in weights)), 'Parameter magnitude overflow')
    except OverflowError as error:
        raise ValueError('Parameter magnitude overflow') from error
    require(type(vectors) is list and len(vectors) == 2, 'Two archived vectors required')
    checks = []
    for index, v in enumerate(vectors):
        actual = scores(weights, v['features'], v['mask'])
        expected = [math.fsum(x*w for x, w in zip(row, weights)) for row in v['features']]
        require(actual == expected and all(math.isfinite(s) for s in actual), 'Score arithmetic mismatch')
        require(select(checkpoint, v['features'], v['mask']) == v['expected_action'], 'Archived vector mismatch')
        checks.append('archived_vector_'+str(index))
    unit = [1.0]+[0.0]*53
    cp = make_checkpoint(unit)
    rows = [[v]+[0.0]*53 for v in (-1.0, 0.0, 1.0)]
    require(select(cp, rows, [1, 1, 0]) == 1, 'Masked winner used')
    checks.append('masked_highest_excluded')
    require(select(cp, [rows[2], rows[2]], [1, 1]) == 0, 'Tie ordering changed')
    checks.append('first_index_tie')
    for order in ([0, 1, 2], [2, 0, 1], [1, 2, 0]):
        permuted = [rows[i] for i in order]
        require(scores(unit, permuted, [1]*3) == [float(rows[i][0]) for i in order]
                and order[select(cp, permuted, [1]*3)] == 2, 'Permutation behavior changed')
    checks.append('unique_winner_permutations')
    invalid = [([], []), (rows, [0, 0, 0]), (rows, [True, 1, 1]), (rows, [1]),
        ([[0.0]*53], [1]), ([[2.0]+[0.0]*53], [1]),
        ([[float('nan')]+[0.0]*53], [1]), ([[True]+[0.0]*53], [1]),
        ([rows[0]]*506, [1]*506)]
    for index, (features, mask) in enumerate(invalid):
        try:
            select(cp, features, mask)
        except (ValueError, OverflowError):
            checks.append('invalid_input_'+str(index))
        else:
            raise ValueError('Malformed consumer input accepted')
    for bad in ([0.0]*53, [float('inf')]+[0.0]*53, [True]+[0.0]*53):
        try:
            make_checkpoint(bad)
        except (ValueError, OverflowError):
            continue
        raise ValueError('Malformed parameters accepted')
    checks.append('invalid_parameters')
    return dict(schema='task-v4-consumer-probe-1', status='Passed', checks=checks,
        actual_vectors=2, synthetic_semantics_only=True, training_reproduced=False,
        runtime_activation=False)
