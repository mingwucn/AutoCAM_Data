"""Complete-envelope geometric separation, independent of task transitions."""
from __future__ import annotations

from dataclasses import dataclass

from .domain import Bounds, Relation, qdata
from .geometry import Cylinder, Cutout, Empty

I, O, M = Relation.INSIDE, Relation.OUTSIDE, Relation.MIXED


@dataclass(frozen=True, slots=True)
class ClosedQuery:
    """May be a face/edge/point for safety; never an integration cell."""
    low: tuple
    high: tuple


@dataclass(frozen=True, slots=True)
class SafetyResult:
    status: str
    reason: str
    witness: dict | None = None

    def to_data(self):
        return {"status": self.status, "reason": self.reason, "witness": self.witness}


def protected_check(envelope, protected, *, depth=8, maximum_queries=10000):
    """Test the whole envelope before any delta clipping, including contact."""
    return _protected_check(envelope,protected,depth=depth,maximum_queries=maximum_queries)


def _protected_check(envelope,protected,*,depth,maximum_queries,classify_pair=None):
    """Shared traversal; the default Fraction predicates remain the reference."""
    if isinstance(protected, Empty):
        return SafetyResult("PASS", "empty_protected_set")
    eb, pb = envelope.bounds, protected.bounds
    if eb is None or pb is None:
        return SafetyResult("PASS", "empty_intersection")
    low = tuple(max(a, b) for a, b in zip(eb.low, pb.low))
    high = tuple(min(a, b) for a, b in zip(eb.high, pb.high))
    if any(a > b for a, b in zip(low, high)):
        return SafetyResult("PASS", "separated_support_bounds")
    if type(envelope) is Cutout and type(protected) is Cylinder:
        for hole in envelope.cutters:
            if (type(hole) is Cylinder and hole.axis == protected.axis
                    and hole.low < protected.low and protected.high < hole.high
                    and protected.radius + sum(abs(a-b) for a,b in zip(hole.center,protected.center)) < hole.radius):
                return SafetyResult("PASS", "strict_cylindrical_exclusion")
    stack = [(ClosedQuery(low, high), 0)]
    queries = 0
    unresolved = False
    while stack:
        query, level = stack.pop()
        queries += 1
        if queries > maximum_queries:
            return SafetyResult("UNRESOLVED", "protected_query_budget")
        e,p=(envelope.classify(query),protected.classify(query)) if classify_pair is None else classify_pair(query)
        if e == O or p == O:
            continue
        if e == I and p == I:
            return SafetyResult("REJECTED", "protected_intersection_or_contact",
                                {"low": [qdata(v) for v in query.low], "high": [qdata(v) for v in query.high]})
        if level >= depth or any(a == b for a, b in zip(query.low, query.high)):
            unresolved = True; continue
        stack.extend((c, level+1) for c in reversed(Bounds(query.low, query.high).children()))
    return SafetyResult("UNRESOLVED", "protected_boundary_unresolved") if unresolved else SafetyResult("PASS", "complete_envelope_separation")


