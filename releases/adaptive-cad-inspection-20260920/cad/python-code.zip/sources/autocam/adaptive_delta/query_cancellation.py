"""Request-local cooperative cancellation; never a geometric classification."""


class QueryCancelled(RuntimeError):
    """A read-only query was cancelled and publishes no partial result."""


def check_query_cancel(cancel):
    if cancel is None:
        return
    if not callable(cancel):
        raise ValueError('Query cancellation must be callable')
    requested = cancel()
    if type(requested) is not bool:
        raise ValueError('Query cancellation callback must return bool')
    if requested:
        raise QueryCancelled('Query cancelled; no result published')
