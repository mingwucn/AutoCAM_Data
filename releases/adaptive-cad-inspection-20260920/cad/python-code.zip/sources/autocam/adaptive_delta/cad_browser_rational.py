"""Pinned browser bytes into the existing original rational-prism constructor."""
from hashlib import sha256
import json

from .cad_rational import _json, construct_rational_prism
from .domain import digest, fields

MODULE_PINS = ('audit_module_sha256', 'audit_wasm_sha256',
               'extractor_module_sha256', 'extractor_wasm_sha256')


def construct_browser_rational(source, snapshot, audit, observation, before, after,
                              *, source_sha256, snapshot_sha256, audit_sha256,
                              observation_sha256, execution):
    """Retain browser provenance without changing the native construction contract.

    The worker checks its module files and preserved in-memory inputs. This
    boundary independently checks transferred bytes, records and serializations.
    Hashes identify an observation; they do not authenticate its origin.
    """
    for raw, pin, limit in ((source, source_sha256, 100*1024**2),
                            (snapshot, snapshot_sha256, 100*1024**2),
                            (audit, audit_sha256, 4*1024**2),
                            (observation, observation_sha256, 4*1024**2)):
        digest(pin)
        if type(raw) is not bytes or not 1 <= len(raw) <= limit or sha256(raw).hexdigest() != pin:
            raise ValueError('Browser rational source bytes or pin differ')
    if type(before) is not bytes or type(after) is not bytes or before != snapshot or after != snapshot:
        raise ValueError('Original rational import changed during extraction')
    fields(execution, (*MODULE_PINS, 'audit_returncode', 'extractor_returncode'))
    for key in MODULE_PINS:
        digest(execution[key])
    if any(type(execution[key]) is not int or execution[key] != 0
           for key in ('audit_returncode', 'extractor_returncode')):
        raise ValueError('Successful browser audit and extraction required')
    audit_text = audit.decode('utf-8')
    a = _json(audit_text)
    if (type(a) is not dict or a.get('schema') != 'adaptive-cad-audit-1'
            or a.get('status') != 'EVALUATED' or a.get('strict_admission') is not False
            or a.get('source_unchanged') is not True
            or type(a.get('tolerance_ceiling_mm')) not in (int, float)
            or a['tolerance_ceiling_mm'] != 1e-7):
        raise ValueError('Original no-fix browser audit at 0.0000001 mm required')
    provenance = dict(schema='adaptive-browser-rational-provenance-1',
                      runtime='emscripten-browser', execution=dict(execution),
                      raw_audit_utf8=audit_text, raw_audit_sha256=audit_sha256,
                      extractor_observation_sha256=observation_sha256,
                      before_sha256=snapshot_sha256, after_sha256=snapshot_sha256)
    record = dict(schema='adaptive-cad-execution-1',
        command=['wasm:cad-audit', 'step', '/source.step', '0.0000001', '/imported.brep'],
        executable_sha256=execution['audit_wasm_sha256'], source_path='/source.step',
        source_sha256=source_sha256, imported_snapshot_sha256=snapshot_sha256,
        raw_source_unchanged=True, returncode=0, status=a['status'],
        strict_admission=False, timeout_seconds=None, tolerance_ceiling_mm='0.0000001',
        observation=a, limitations=[
            'Browser WASM execution; no native Windows executable ran in this record.',
            'Worker lifetime is controlled by the caller; no native subprocess timeout.',
            'Nominal construction only; no STEP import or original trim equality claim.',
            json.dumps(provenance, sort_keys=True, separators=(',', ':'), allow_nan=False)])
    retained = json.dumps(record, sort_keys=True, separators=(',', ':'), allow_nan=False)
    binding = dict(raw_source_sha256=source_sha256, imported_snapshot_sha256=snapshot_sha256,
                   observation_sha256=observation_sha256,
                   audit_sha256=sha256(retained.encode('utf-8')).hexdigest())
    return construct_rational_prism(observation.decode('utf-8'), retained, binding)
