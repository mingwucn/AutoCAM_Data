"""Read-only full-angle occlusion; distinct from a turning cutting envelope."""
from dataclasses import dataclass
from itertools import product

from .analytic_directional_shadow import _extrude
from .annular_directional_shadow import annular_band
from .directional_shadow_view import REASONS
from .domain import Bounds, Relation, canonical, digest, identity, qdata, rational
from .geometry import Box, Cutout, Cylinder, Empty, Sphere, Union
from .transitions import ClosedQuery, MaterialState
from .turning_tools import TurningAxis

PROFILE = 'closed_full_angle_turning_point_shadow_1'
I, O, M = Relation.INSIDE, Relation.OUTSIDE, Relation.MIXED


def _radial_squared(query, spindle):
    limits = [(query.low[k]-spindle.origin[k], query.high[k]-spindle.origin[k])
              for k in range(3) if k != spindle.axis]
    return (sum(0 if a <= 0 <= b else min(a*a, b*b) for a, b in limits),
            sum(max(a*a, b*b) for a, b in limits))


@dataclass(frozen=True, slots=True)
class _RadialBand:
    spindle: TurningAxis
    low: object
    high: object
    inner_squared: object
    outer_squared: object

    def __post_init__(self):
        if type(self.spindle) is not TurningAxis:
            raise ValueError('Explicit spindle required')
        for name in ('low', 'high', 'inner_squared', 'outer_squared'):
            object.__setattr__(self, name, rational(getattr(self, name)))
        if not self.low < self.high or not 0 <= self.inner_squared < self.outer_squared:
            raise ValueError('Invalid squared-radius shadow band')

    def classify(self, query, *, interior=False):
        lo, hi = query.low[self.spindle.axis], query.high[self.spindle.axis]
        rlo, rhi = _radial_squared(query, self.spindle)
        if interior:
            if (hi <= self.low or lo >= self.high or rlo >= self.outer_squared or
                    self.inner_squared > 0 and rhi <= self.inner_squared):
                return O
            return I if (self.low < lo and hi < self.high and rhi < self.outer_squared and
                         (self.inner_squared == 0 or rlo > self.inner_squared)) else M
        if hi < self.low or lo > self.high or rlo > self.outer_squared or rhi < self.inner_squared:
            return O
        return I if (self.low <= lo and hi <= self.high and
                     self.inner_squared <= rlo and rhi <= self.outer_squared) else M

    def to_data(self):
        return dict(kind='turning_shadow_radial_band_squared_1', spindle=self.spindle.to_data(),
                    **{name: qdata(getattr(self, name)) for name in
                       ('low', 'high', 'inner_squared', 'outer_squared')})


@dataclass(frozen=True, slots=True)
class _ShadowUnion:
    children: tuple

    def classify(self, query, *, interior=False):
        relations = [c.classify(query, interior=interior) for c in self.children]
        return I if I in relations else O if all(r == O for r in relations) else M

    def to_data(self):
        return dict(kind='turning_shadow_union_1', children=[c.to_data() for c in self.children])


def _preserved_box_shadow(shape, spindle, mode, sign):
    """Prove a source cutout retains a complete extremal shadow witness."""
    if any(type(c) not in (Box, Cylinder, Sphere) for c in shape.cutters):
        return False
    bounds, axis = shape.base.bounds, spindle.axis
    if mode == 'FACING':
        low, high = list(bounds.low), list(bounds.high)
        low[axis] = high[axis] = bounds.low[axis] if sign == 1 else bounds.high[axis]
        witnesses = (ClosedQuery(tuple(low), tuple(high)),)
    else:
        radial = [k for k in range(3) if k != axis]
        maximum = _radial_squared(bounds, spindle)[1]
        witnesses = []
        for corner in product(*[(bounds.low[k], bounds.high[k]) for k in radial]):
            if sum((c-spindle.origin[k])**2 for k, c in zip(radial, corner)) != maximum:
                continue
            low, high = list(bounds.low), list(bounds.high)
            for k, c in zip(radial, corner): low[k] = high[k] = c
            witnesses.append(ClosedQuery(tuple(low), tuple(high)))
    # One preserved maximum-radius line suffices radially. Facing requires
    # the entire entry face, including every radius in its connected orbit.
    return any(all(c.classify(q, interior=True) == O for c in shape.cutters) for q in witnesses)


def _primitives(shape, spindle, mode, sign):
    if type(shape) is Empty:
        return ()
    if type(shape) is Union:
        return tuple(p for child in shape.children for p in _primitives(child, spindle, mode, sign))
    if type(shape) is Box:
        return (shape,)
    if type(shape) is Cutout and type(shape.base) is Union:
        # Preserve the existing stepped-shaft source encoding. Difference by
        # the same open bore distributes over a finite union exactly.
        if len(shape.cutters) != 1:
            raise ValueError('Turning point-shadow requires one common through bore')
        return tuple(p for child in shape.base.children if type(child) is not Empty
                     for p in _primitives(Cutout(child, shape.cutters), spindle, mode, sign))
    if type(shape) is Cutout and type(shape.base) is Box:
        if not _preserved_box_shadow(shape, spindle, mode, sign):
            raise ValueError('Box cutout turning shadow lacks a preserved complete extremal witness')
        return (shape.base,)
    base = annular_band(shape)[0] if type(shape) is Cutout else shape
    center = tuple(spindle.origin[k] for k in range(3) if k != spindle.axis)
    if type(base) is Cylinder and base.axis == spindle.axis and base.center == center:
        return (shape,)
    if type(shape) is Sphere and tuple(shape.center[k] for k in range(3) if k != spindle.axis) == center:
        return (shape,)
    raise ValueError('Turning point-shadow blocker requires box or coaxial analytic geometry')


@dataclass(frozen=True, slots=True)
class TurningPointShadowView:
    state: MaterialState
    spindle: TurningAxis
    mode: str
    facing_sign: int | None
    rotating_fixture: object
    semantic_id: str

    def __post_init__(self):
        if type(self.state) is not MaterialState or type(self.spindle) is not TurningAxis:
            raise ValueError('Typed accepted material and explicit spindle required')
        if self.state.turning_axis != self.spindle:
            raise ValueError('Turning shadow spindle differs from frozen accepted setup')
        if self.mode not in ('OUTSIDE', 'FACING'):
            raise ValueError('Unsupported turning shadow mode')
        if ((self.mode == 'OUTSIDE' and self.facing_sign is not None) or
                (self.mode == 'FACING' and (type(self.facing_sign) is not int or self.facing_sign not in (-1, 1)))):
            raise ValueError('Turning shadow requires explicit facing sign only in FACING mode')
        digest(self.semantic_id)
        for shape in (self.state.domain.source.protected, self.rotating_fixture):
            for primitive in _primitives(shape, self.spindle, self.mode, self.facing_sign):
                b = primitive.bounds
                if any(b.low[k] <= self.exterior.low[k] or b.high[k] >= self.exterior.high[k] for k in range(3)):
                    raise ValueError('Blockers must lie strictly within the declared exterior')

    @property
    def exterior(self):
        root = self.state.domain.source.root
        return Bounds(tuple(x-root.side for x in root.bounds.low),
                      tuple(x+root.side for x in root.bounds.high))

    def _project(self, shape):
        if type(shape) is Sphere:
            return shape if self.mode == 'OUTSIDE' else _extrude(shape, self.spindle.axis, self.facing_sign, self.exterior)
        if type(shape) is Box:
            low, high = shape.bounds.low[self.spindle.axis], shape.bounds.high[self.spindle.axis]
            inner, outer = _radial_squared(shape.bounds, self.spindle)
        else:
            base, bore = annular_band(shape) if type(shape) is Cutout else (shape, None)
            low, high = base.low, base.high
            inner, outer = 0 if bore is None else bore.radius**2, base.radius**2
        if self.mode == 'OUTSIDE':
            inner = 0
        elif self.facing_sign == 1:
            high = self.exterior.high[self.spindle.axis]
        else:
            low = self.exterior.low[self.spindle.axis]
        return _RadialBand(self.spindle, low, high, inner, outer)

    def shadow(self, reason='combined'):
        if reason not in REASONS:
            raise ValueError('Unknown turning point-shadow reason')
        protected = self.state.domain.source.protected
        blockers = (protected, self.rotating_fixture) if reason == 'combined' else (
            protected if reason == 'protected' else self.rotating_fixture,)
        return _ShadowUnion(tuple(self._project(p) for blocker in blockers
                                  for p in _primitives(blocker, self.spindle, self.mode, self.facing_sign)))

    def _query(self, query):
        if type(query) is not Bounds:
            raise ValueError('Exact positive-volume query bounds required')
        root = self.state.domain.source.root.bounds
        if any(query.low[k] < root.low[k] or query.high[k] > root.high[k] for k in range(3)):
            raise ValueError('Turning shadow query outside source root')

    def classify_shadow(self, query, reason='combined', *, interior=False):
        self._query(query)
        return self.shadow(reason).classify(query, interior=interior)

    def classify(self, query, reason='combined'):
        self._query(query)
        source = self.state.domain.source
        shadow = self.shadow(reason).classify(query)
        stock = Cutout(source.stock, self.state.envelopes).classify(query)
        protected, fixture = source.protected.classify(query), self.rotating_fixture.classify(query)
        if O in (shadow, stock) or I in (protected, fixture):
            return O
        return I if shadow == stock == I and protected == fixture == O else M

    def to_data(self):
        source = self.state.domain.source
        return dict(schema='adaptive-turning-point-shadow-view-1', predicate_version=PROFILE,
            projection_only=True, operation_authorized=False, frame='original_part',
            rotation_model='full_angle_blocking_union', spindle=self.spindle.to_data(), spindle_id=self.spindle.id,
            mode=self.mode, facing_sign=self.facing_sign, source_geometry_id=source.geometry_id,
            root_id=source.root.id, root=source.root.to_data(), exterior=self.exterior.to_data(),
            partition_id=self.state.domain.logical_hash, material_hash=self.state.logical_hash,
            semantic_id=self.semantic_id, rotating_fixture_id=identity(self.rotating_fixture.to_data()),
            rotating_fixture=self.rotating_fixture.to_data(), protected=source.protected.to_data(),
            remaining_stock=Cutout(source.stock, self.state.envelopes).to_data(),
            shadows={r: self.shadow(r).to_data() for r in REASONS},
            direction_convention='outside_inward_radial_ray_or_facing_x_minus_lambda_sign_axis',
            set_semantics='closed_current_stock_intersect_full_angle_shadow_minus_closed_protected_and_rotating_fixture',
            boundary_semantics='closed_tangency_blocks_partial_cells_remain_mixed',
            finite_tool_access_status='NOT_ASSESSED', tool_length_status='NOT_ASSESSED',
            stationary_obstacles_status='NOT_ASSESSED', machine_motion_status='NOT_ASSESSED')

    def verify(self, payload):
        if canonical(payload) != canonical(self.to_data()):
            raise ValueError('Turning shadow projection differs from bound inputs')
        return identity(payload)
