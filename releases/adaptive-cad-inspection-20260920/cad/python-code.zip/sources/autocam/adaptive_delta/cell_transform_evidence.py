"""Source-bound indexed query enclosures for one inspected adaptive cell."""
from .domain import canonical, fields, identity, qread
from .geometry import Cutout, IndexedSolid, Union, region_id
from .indexed_enclosure_evidence import transform_query_with_evidence, verify_indexed_enclosure
from .indexed_queries import ClosedBounds


def _walk(source, query, visit):
    nodes = 0
    transforms = 0
    def walk(shape, path, box, depth):
        nonlocal nodes, transforms
        nodes += 1
        if nodes > 4096 or depth > 32:
            raise ValueError('Cell transform source traversal budget exceeded')
        if isinstance(shape, IndexedSolid):
            transforms += 1
            if transforms > 256:
                raise ValueError('Cell transform operand budget exceeded')
            next_box = visit(shape, path, box)
            walk(shape.base, path+['base'], next_box, depth+1)
        elif isinstance(shape, Union):
            for i, child in enumerate(shape.children):
                walk(child, path+['children', i], box, depth+1)
        elif isinstance(shape, Cutout):
            walk(shape.base, path+['base'], box, depth+1)
            for i, child in enumerate(shape.cutters):
                walk(child, path+['cutters', i], box, depth+1)
    for role in ('stock', 'target', 'protected'):
        walk(getattr(source, role), [role], query, 0)


def _header(source, address):
    if address.domain_geometry_id != source.geometry_id:
        raise ValueError('Cell transform source identity differs')
    query = source.root.cell(address)
    return query, dict(schema='adaptive-cell-transform-enclosures-1', source_geometry_id=source.geometry_id,
                       policy_id=identity(source.policy.to_data()), address=address.to_data(), query=query.to_data())


def cell_transform_enclosures(source, address):
    query, result = _header(source, address)
    entries = []
    def visit(shape, path, box):
        transformed, evidence = transform_query_with_evidence(shape.pose.inverse(), box)
        entries.append(dict(source_path=path, operand_id=region_id(shape), transform=evidence))
        return transformed
    _walk(source, query, visit)
    return dict(result, entries=entries)


def verify_cell_transform_enclosures(record, source, address):
    query, header = _header(source, address)
    fields(record, (*header, 'entries'))
    if canonical({k:record[k] for k in header}) != canonical(header):
        raise ValueError('Cell transform header differs')
    entries = record['entries']
    if type(entries) is not list or len(entries) > 256:
        raise ValueError('Cell transform inventory exceeds its budget')
    cursor = 0
    def visit(shape, path, box):
        nonlocal cursor
        if cursor >= len(entries): raise ValueError('Missing cell transform operand')
        row = entries[cursor]; cursor += 1
        fields(row, ('source_path', 'operand_id', 'transform'))
        if canonical(row['source_path']) != canonical(path) or row['operand_id'] != region_id(shape):
            raise ValueError('Cell transform operand differs')
        # Construct inverse coefficients directly; the verifier must not use a
        # production inverse/interval transform to establish the query chain.
        from .indexed_frames import IndexedOrientation
        inverse = IndexedOrientation(shape.pose.spindle, shape.pose.cosine, -shape.pose.sine)
        verify_indexed_enclosure(row['transform'], inverse, box)
        enclosure = row['transform']['enclosure']
        return ClosedBounds(tuple(map(qread, enclosure['low'])), tuple(map(qread, enclosure['high'])))
    _walk(source, query, visit)
    if cursor != len(entries): raise ValueError('Unexpected cell transform operand')
    return True
