"""Shared spindle and axial-motion values, without task/catalog dependencies."""
from dataclasses import dataclass
from fractions import Fraction
import re

from .domain import fields, identity, integer, qdata, qread, rational, triple


def _identifier(value):
    if type(value) is not str or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,95}", value):
        raise ValueError("Invalid tool identifier or revision")
    return value


@dataclass(frozen=True, slots=True)
class TurningAxis:
    axis: int
    origin: tuple

    def __post_init__(self):
        integer(self.axis, 'turning spindle axis', 0, 2)
        object.__setattr__(self, 'origin', triple(self.origin))

    def to_data(self):
        return dict(schema='adaptive-turning-axis-1', axis=self.axis,
                    origin=[qdata(v) for v in self.origin], units='mm')

    @property
    def id(self): return identity(self.to_data())

    @classmethod
    def from_data(cls, data):
        fields(data, ('schema', 'axis', 'origin', 'units'))
        if data['schema'] != 'adaptive-turning-axis-1' or data['units'] != 'mm':
            raise ValueError('Unsupported turning axis encoding')
        return cls(data['axis'], tuple(qread(v) for v in data['origin']))


@dataclass(frozen=True, slots=True)
class AxialPlunge:
    axis: int
    sign: int
    start_tip: tuple
    end_tip: tuple

    def __post_init__(self):
        integer(self.axis, "plunge axis", 0, 2)
        if type(self.sign) is not int or self.sign not in (-1, 1):
            raise ValueError("Invalid plunge sign")
        object.__setattr__(self, "start_tip", triple(self.start_tip))
        object.__setattr__(self, "end_tip", triple(self.end_tip))
        if any(self.start_tip[k] != self.end_tip[k] for k in range(3) if k != self.axis):
            raise ValueError("Axial plunge does not support side milling or lateral travel")
        if (self.end_tip[self.axis]-self.start_tip[self.axis])*self.sign <= 0:
            raise ValueError("Plunge travel must advance along the declared direction")

    def to_data(self):
        return {"schema": "adaptive-axial-plunge-1", "axis": self.axis, "sign": self.sign,
                "start_tip": [qdata(x) for x in self.start_tip], "end_tip": [qdata(x) for x in self.end_tip]}

    @classmethod
    def from_data(cls, data):
        fields(data, ("schema", "axis", "sign", "start_tip", "end_tip"))
        if data["schema"] != "adaptive-axial-plunge-1":
            raise ValueError("Unsupported motion encoding")
        return cls(data["axis"], data["sign"], tuple(qread(x) for x in data["start_tip"]),
                   tuple(qread(x) for x in data["end_tip"]))


@dataclass(frozen=True, slots=True)
class MillingTool:
    tool_id: str
    revision: str
    profile: str
    radius: Fraction
    usable_reach: Fraction
    flute_length: Fraction
    shank_radius: Fraction
    holder_radius: Fraction
    holder_length: Fraction

    def __post_init__(self):
        _identifier(self.tool_id); _identifier(self.revision)
        if self.profile not in ("FLAT_END", "BALL_END"):
            raise ValueError("Unsupported milling tool profile")
        for name in self.dimensions():
            value = rational(getattr(self, name))
            if value <= 0:
                raise ValueError(f"Tool {name} must be positive")
            object.__setattr__(self, name, value)
        if self.flute_length > self.usable_reach:
            raise ValueError("Flutes cannot extend behind the holder front")
        if self.profile == "BALL_END" and self.flute_length < 2*self.radius:
            raise ValueError("Ball profile requires flute length >= diameter")

    @staticmethod
    def dimensions():
        return ("radius", "usable_reach", "flute_length", "shank_radius", "holder_radius", "holder_length")

    def to_data(self):
        return {"schema": "adaptive-milling-tool-1", "tool_id": self.tool_id,
                "revision": self.revision, "profile": self.profile, "units": "mm",
                **{name: qdata(getattr(self, name)) for name in self.dimensions()}}

    @classmethod
    def from_data(cls, data):
        fields(data, ("schema", "tool_id", "revision", "profile", "units", *cls.dimensions()))
        if data["schema"] != "adaptive-milling-tool-1" or data["units"] != "mm":
            raise ValueError("Unsupported tool encoding")
        return cls(data["tool_id"], data["revision"], data["profile"],
                   **{name: qread(data[name]) for name in cls.dimensions()})


@dataclass(frozen=True, slots=True)
class SideMill:
    axis: int
    sign: int
    travel_axis: int
    travel_sign: int
    start_tip: tuple
    end_tip: tuple

    def __post_init__(self):
        integer(self.axis, 'spindle axis', 0, 2)
        integer(self.travel_axis, 'travel axis', 0, 2)
        if self.axis == self.travel_axis:
            raise ValueError('Side travel must be perpendicular to the spindle')
        for sign in (self.sign, self.travel_sign):
            if type(sign) is not int or sign not in (-1, 1):
                raise ValueError('Invalid side-milling direction sign')
        for name in ('start_tip', 'end_tip'):
            object.__setattr__(self, name, triple(getattr(self, name)))
        if any(self.start_tip[k] != self.end_tip[k] for k in range(3) if k != self.travel_axis):
            raise ValueError('Side milling requires fixed depth and straight lateral travel')
        if self.travel_sign*(self.end_tip[self.travel_axis]-self.start_tip[self.travel_axis]) <= 0:
            raise ValueError('Lateral motion must advance along the declared travel direction')

    def to_data(self):
        return dict(schema='adaptive-side-mill-1', axis=self.axis, sign=self.sign,
                    travel_axis=self.travel_axis, travel_sign=self.travel_sign,
                    start_tip=[qdata(v) for v in self.start_tip], end_tip=[qdata(v) for v in self.end_tip])

    @classmethod
    def from_data(cls, data):
        fields(data, ('schema', 'axis', 'sign', 'travel_axis', 'travel_sign', 'start_tip', 'end_tip'))
        if data['schema'] != 'adaptive-side-mill-1':
            raise ValueError('Unsupported side-milling motion encoding')
        return cls(data['axis'], data['sign'], data['travel_axis'], data['travel_sign'],
                   tuple(qread(v) for v in data['start_tip']), tuple(qread(v) for v in data['end_tip']))


