"""Operator observations; never input to normalized geometry or material identity."""
from hashlib import sha256
import os
from pathlib import Path
import platform
import re
import subprocess
import sysconfig


def repository_observation(directory):
    """Observe explicit checkout identity without retaining status paths/content."""
    directory = Path(directory).resolve()
    # Caller shell Git overrides must not redirect the explicitly selected tree.
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith('GIT_')}
    env['GIT_OPTIONAL_LOCKS'] = '0'

    def git(*args):
        result = subprocess.run(['git', '-C', str(directory), *args], env=env,
                                capture_output=True, timeout=10, check=True)
        return result.stdout

    try:
        before = git('rev-parse', '--verify', 'HEAD').decode('ascii').strip()
        status = git('status', '--porcelain=v1', '-z', '--untracked-files=normal')
        after = git('rev-parse', '--verify', 'HEAD').decode('ascii').strip()
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', before) or before != after:
            return dict(status='unavailable', revision=None, dirty=None,
                        status_sha256=None, reason='revision_changed_or_invalid')
        return dict(status='observed', revision=before, dirty=bool(status),
                    status_sha256=sha256(status).hexdigest(), reason=None)
    except (OSError, subprocess.SubprocessError, UnicodeError):
        return dict(status='unavailable', revision=None, dirty=None,
                    status_sha256=None, reason='git_observation_failed')


def reference_environment(repository_directory, *, dependency_lock=None):
    """Capture declared deterministic reference-demo roles and reported settings."""
    if dependency_lock is None:
        lock = dict(status='not_provided', sha256=None, size=None)
    else:
        raw = Path(dependency_lock).read_bytes()
        lock = dict(status='provided', sha256=sha256(raw).hexdigest(), size=len(raw))
    flags = {name: sysconfig.get_config_var(name)
             for name in ('CFLAGS', 'PY_CFLAGS', 'PY_CFLAGS_NODIST', 'CONFIG_ARGS')}
    # Preserve missing values; never translate an unknown build into "no flags".
    flags = {name: None if value is None else str(value) for name, value in flags.items()}
    return dict(schema='adaptive-reference-environment-1',
                repository=repository_observation(repository_directory),
                dependency_lock=lock,
                compiler=dict(python_reported=platform.python_compiler(),
                              build_flags=flags, native_build_performed=False),
                platform=dict(system=platform.system(), release=platform.release(),
                              machine=platform.machine(), python=platform.python_version()),
                execution_roles=dict(cpu='reference_geometry_and_episode_replay', gpu='unused'),
                floating_point=dict(geometry='exact_integer_and_fraction',
                                    timing='python_float', hardware_rounding_mode='not_observed',
                                    compiled_library_flags='not_reconstructed'),
                seed=dict(status='not_used', value=None, reason='fixed_deterministic_demo'),
                source_identity='separate_exact_producer_archive',
                qualification_granted=False)
