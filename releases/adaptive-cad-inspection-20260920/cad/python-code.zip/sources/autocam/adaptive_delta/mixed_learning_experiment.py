"""Read-only full-episode policy comparison over the accepted mixed learning gym."""
from collections import Counter
from hashlib import sha256
from time import perf_counter

from .candidate_identity import CandidateSpec
from .combined_inference import numeric_bytes
from .combined_mill_turn_gym import MillTurnCandidate
from .domain import canonical, fields, identity, integer, qdata, qread
from .drill_tools import DrillTool
from .face_tools import FaceMillTool
from .mixed_action_bank import _elapsed
from .mixed_learning_contract import FEATURES
from .mixed_learning_gym import MixedLearningGym
from .mixed_learning_inference import _gym, validate_checkpoint, model_action, mcts_action
from .mixed_learning_reference import RecordedMixedReference, reference_action
from .turning_tools import TurningInsert


COUNTERS = ('generated_proposals', 'generated_candidates', 'structurally_valid_candidates',
    'capability_compatible_candidates', 'geometry_certified_candidates', 'prepared_candidates',
    'representation_rejections', 'budget_pruned_proposals', 'budget_pruned_candidates',
    'alias_proposals', 'policy_candidates', 'accepted_primitive_candidates')
SCOPE = 'accepted_decision_banks_excluding_speculative_search_banks'


def _require(value, message):
    if not value: raise ValueError(message)


def _bank_metrics(observed, catalog):
    bank = observed['bank']
    _require(bank is not None and bank['schema']=='adaptive-prepared-mixed-action-bank-1', 'Checked mixed bank required')
    counts = dict.fromkeys(COUNTERS, 0)
    counts['policy_candidates'] = len(bank['entries'])
    _require(bank['policy_candidate_ids']==[e['candidate_id'] for e in bank['entries']], 'Bank exposure differs')

    def concrete(capable):
        counts['generated_candidates'] += 1
        counts['structurally_valid_candidates'] += 1
        counts['capability_compatible_candidates'] += int(capable)

    for diagnostic in bank['diagnostics']:
        family = diagnostic['family']
        if family == 'initial':
            candidate = MillTurnCandidate.from_data(diagnostic['candidate'])
            _require(candidate.kind in ('turn', 'transfer'), 'Unknown initial experiment operation')
            tool = catalog.select(observed['current_machine']['tool_id'] if candidate.kind=='turn' else candidate.tool_id)
            concrete(type(tool) is TurningInsert if candidate.kind=='turn' else type(tool) in (FaceMillTool, DrillTool))
            counts['generated_proposals'] += 1
            prepared = diagnostic['preparation']['preparation']
            _require(prepared['candidate_id']==candidate.id, 'Initial diagnostic identity differs')
            counts['geometry_certified_candidates'] += int(prepared['outcome'] is not None and prepared['outcome']['status']=='ACCEPTED')
            counts['prepared_candidates'] += int(prepared['status']=='PREPARED')
            counts['representation_rejections'] += int(prepared['status']=='REPRESENTATION_REJECTED')
        elif family == 'primitive':
            spec = diagnostic['specification']; kind = spec['kind']
            _require(kind in ('index', 'change_tool', 'no_op'), 'Unknown experiment primitive')
            fields(spec, ('kind', 'target') if kind=='index' else ('kind', 'tool_id') if kind=='change_tool' else ('kind',))
            concrete(kind!='change_tool' or type(catalog.select(spec['tool_id'])) in (FaceMillTool, DrillTool))
            counts['generated_proposals'] += 1
            accepted = diagnostic['result']['status']=='ACCEPTED'
            counts['geometry_certified_candidates'] += int(accepted and kind!='no_op')
            counts['accepted_primitive_candidates'] += int(accepted)
        elif family in ('face', 'drill'):
            generation = diagnostic['generation']; batch = generation['batch']; rows = batch['rows']
            _require(batch['proposal_count']==len(rows), 'Proposal count differs')
            counts['generated_proposals'] += len(rows)
            counts['budget_pruned_proposals'] += sum(r['status']=='NOT_EVALUATED_BUDGET' for r in rows)
            unique = [r for r in rows if r['candidate'] is not None and r.get('alias_of') is None]
            counts['alias_proposals'] += sum(r.get('alias_of') is not None for r in rows)
            _require(len(unique)==batch['candidate_count'] and len({identity(r['candidate']) for r in unique})==len(unique), 'Unique candidate count differs')
            preparations = {identity(p):p for p in generation['prepared']}
            _require(len(preparations)==len(generation['prepared']), 'Repeated prepared result')
            for row in unique:
                candidate = CandidateSpec.from_data(row['candidate']); tool = catalog.select(row['parameters']['tool_id'])
                concrete(type(tool) is (FaceMillTool if family=='face' else DrillTool)
                    and candidate.operation==('EXTERNAL_FACE_PASS' if family=='face' else 'AXIAL_DRILL')
                    and candidate.assembly_id==tool.id)
                counts['budget_pruned_candidates'] += int(row['status']=='NOT_EVALUATED_BUDGET')
                counts['representation_rejections'] += int(row['status']=='REPRESENTATION_REJECTED')
                if row['preparation_id'] is not None:
                    _require(row['preparation_id'] in preparations, 'Missing prepared diagnostic')
                    prepared = preparations[row['preparation_id']]
                    _require(identity(prepared['candidate'])==candidate.id and prepared['status']==row['status'], 'Prepared candidate binding differs')
                    counts['geometry_certified_candidates'] += int(prepared['outcome'] is not None and prepared['outcome']['status']=='ACCEPTED')
                    counts['prepared_candidates'] += int(prepared['status']=='PREPARED')
                else:
                    _require(row['status'] not in ('PREPARED','REPRESENTATION_REJECTED'), 'Missing evaluated preparation')
            _require(batch['policy_candidate_ids']==[identity(r['candidate']) for r in unique if r['selectable']], 'Generated policy ordering differs')
        else: raise ValueError('Unknown experiment candidate family')
    _require(counts['policy_candidates']==counts['prepared_candidates']+counts['accepted_primitive_candidates'], 'Policy/preparation stage reconciliation differs')
    return counts


def _expansions(search):
    if search is None: return 0
    _require(search['schema']=='adaptive-mixed-mcts-1' and len(search['traces'])==search['simulations'], 'Search trace differs')
    prefixes = set()
    for trace in search['traces']:
        actions = trace['actions']
        _require(len(actions)<=search['depth'] and len(actions)==len(trace['rewards']), 'Search path differs')
        for i, action in enumerate(actions):
            integer(action, 'search action', 0)
            prefixes.add(tuple(actions[:i+1]))
    return len(prefixes)


def evaluate_policy(initial, *, policy, model=None, reference=None, simulations=4, depth=2, exploration=1.0):
    _gym(initial)
    _require(initial.steps==0, 'Policy comparison requires original initial learning state')
    _require(policy in ('reference', 'rl', 'rl_mcts'), 'Unknown comparison policy')
    integer(simulations, 'comparison simulations', 1, 128); integer(depth, 'comparison depth', 1, 8)
    _require(type(exploration) in (int, float) and 0<exploration<=100, 'Invalid comparison exploration')
    if policy=='reference':
        _require(model is None and type(reference) is RecordedMixedReference, 'Reference comparison requires only an admitted reference')
        _require(reference.to_data()['manifest_id']==initial.manifest.id, 'Reference manifest differs')
    else:
        _require(reference is None, 'Model comparison cannot consume a demonstration selector')
        validate_checkpoint(initial, model)
    before = canonical(initial.export()); model_before = None if model is None else numeric_bytes(model)
    started = perf_counter(); gym = initial.fork()
    # Start each timed evaluation with empty derived caches, even for a warm input.
    gym._proofs = {}; gym._bank = None; gym._observation = None
    decisions = []; totals = Counter(dict.fromkeys(COUNTERS, 0))
    kinds = Counter(); cost = 0; reward = 0; expansions = 0
    while not (gym.terminated or gym.truncated):
        observed = gym.observe(); metrics = _bank_metrics(observed, gym._session.material.tool_catalog)
        trace = search = None
        if policy=='reference': action, trace = reference_action(gym, reference)
        elif policy=='rl': action = model_action(gym, model)
        else: action, search = mcts_action(gym, model, simulations=simulations, depth=depth, exploration=exploration)
        entry = observed['choices'][action]['entry']
        result = gym.step(action, expected_head=observed['head'])
        totals.update(metrics); kinds[entry['specification']['kind']] += 1
        cost += qread(entry['charged_seconds']); reward += qread(result['reward']); expansions += _expansions(search)
        decisions.append(dict(head=observed['head'], exposed_set_id=observed['bank']['exposed_set_id'],
            candidate_ids=observed['bank']['policy_candidate_ids'], selected=action,
            candidate_id=entry['candidate_id'], evaluation_id=entry['evaluation_id'],
            candidate_metrics=metrics, reference_trace=trace, search=search))
    episode = gym.export(); evaluation_seconds = perf_counter()-started
    _require(cost==_elapsed(gym._session), 'Full native cost differs from selected charges')
    started = perf_counter(); MixedLearningGym.replay(episode, expected_export_id=identity(episode))
    replay_seconds = perf_counter()-started
    _require(canonical(initial.export())==before and (model is None or numeric_bytes(model)==model_before), 'Comparison changed input')
    final = episode['final']
    record = dict(schema='adaptive-mixed-policy-evaluation-1', manifest_id=gym.manifest.id,
        manifest=gym.manifest.to_data(), feature_contract_id=identity(FEATURES), policy=policy,
        checkpoint_sha256=None if model is None else sha256(model_before).hexdigest(),
        reference_id=None if reference is None else reference.id, seed=None, seed_reason='deterministic_evaluation',
        search_budget=None if policy!='rl_mcts' else dict(simulations=simulations, depth=depth, exploration=exploration, discount=1.),
        candidate_metric_scope=SCOPE, candidate_metrics=dict(totals), action_counts=dict(kinds),
        machine_state_actions=sum(kinds[k] for k in ('transfer','index','change_tool','no_op')),
        material_commits=sum(kinds[k] for k in ('turn','face','drill')), mcts_expansions=expansions,
        mcts_simulations=0 if policy!='rl_mcts' else len(decisions)*simulations,
        declared_machining_seconds=qdata(cost), total_reward=qdata(reward),
        completed=final['terminated'] and final['stop_reason']=='COMPLETE',
        terminated=final['terminated'], truncated=final['truncated'], stop_reason=final['stop_reason'],
        decisions=decisions, episode=episode, episode_id=identity(episode), replay_verified=True,
        timing=dict(evaluation_seconds=evaluation_seconds, independent_replay_seconds=replay_seconds,
                    training_and_reference_admission_included=False),
        held_out=False, manufacturing_qualified=False, full_WP7_complete=False)
    _require(len(numeric_bytes(record))<=128*1024**2, 'Policy comparison record budget')
    return record
