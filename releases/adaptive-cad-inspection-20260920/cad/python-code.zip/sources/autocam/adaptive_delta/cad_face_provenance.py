"""Read-only import metadata; independent of material state and face contact."""
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import PurePath

from .cad import CadAuditPolicy, _validate_observation, _object, _invalid_constant
from .cad_construction import verify_target_construction
from .cad_rational import _json
from .codec import parse_canonical
from .domain import canonical, digest, fields, identity, integer, qdata

SCHEMA='adaptive-cad-face-provenance-1'
IMPORTER_FIELDS=('runtime','kernel_version','binary_sha256','module_sha256','wrapper_code_sha256')


def _bytes(raw,pin,limit):
    digest(pin)
    if type(raw) is not bytes or not 0<len(raw)<=limit or sha256(raw).hexdigest()!=pin:
        raise ValueError('Pinned provenance input bytes differ')


def build_face_provenance(certificate,audit,*,expected_certificate_sha256,expected_audit_sha256,importer):
    """Pins identify supplied records; they do not authenticate their producer."""
    _bytes(certificate,expected_certificate_sha256,32*1024**2);_bytes(audit,expected_audit_sha256,16*1024**2)
    c=parse_canonical(certificate,maximum_bytes=32*1024**2)
    if canonical(c)!=certificate:raise ValueError('Canonical construction bytes required')
    verify_target_construction(c)
    fields(importer,IMPORTER_FIELDS);digest(importer['binary_sha256'])
    if importer['kernel_version']!='7.8.1':raise ValueError('Unsupported importer kernel')
    record=json.loads(audit,object_pairs_hook=_object,parse_constant=_invalid_constant);native=importer['runtime']=='native'
    if native:
        if importer['module_sha256'] is not None or importer['wrapper_code_sha256'] is not None:
            raise ValueError('Historical native wrapper identity was not recorded')
        if (type(record) is not dict or record.get('schema')!='adaptive-cad-execution-1' or
                record.get('status')!='EVALUATED' or record.get('raw_source_unchanged') is not True or
                record.get('strict_admission') is not False or record.get('executable_sha256')!=importer['binary_sha256']):
            raise ValueError('Original native execution binding differs')
        integer(record.get('returncode'),'native return code',0,0)
        if (record.get('source_sha256')!=c['binding']['raw_source_sha256'] or
                record.get('imported_snapshot_sha256')!=c['binding']['imported_snapshot_sha256']):
            raise ValueError('Native audit belongs to another source')
        source_path=record.get('source_path')
        if type(source_path) is not str:raise ValueError('Original source path required')
        suffix=PurePath(source_path).suffix.lower()
        if suffix not in ('.step','.stp','.brep'):raise ValueError('Unknown original source format')
        kind='brep' if suffix=='.brep' else 'step';observation=record.get('observation')
        policy=CadAuditPolicy(record.get('tolerance_ceiling_mm'))
    elif importer['runtime']=='emscripten-browser':
        digest(importer['module_sha256']);digest(importer['wrapper_code_sha256'])
        observation=record;kind='step'
        if type(observation) is not dict:raise ValueError('Original browser observation required')
        policy=CadAuditPolicy(str(observation.get('tolerance_ceiling_mm')))
    else:raise ValueError('Unsupported importer runtime')
    if type(observation) is not dict or type(observation.get('faces')) is not list:
        raise ValueError('Original face inventory required')
    faces=observation['faces'];integer(len(faces),'face inventory',1,256)
    if any(type(f) is not dict for f in faces):raise ValueError('Original face object required')
    plain=[{k:v for k,v in face.items() if k!='source_face_id'} for face in faces]
    _validate_observation(dict(observation,faces=plain),kind,policy,
        'spherical_nominal' if 'spherical_parameters' in observation else None)
    if observation['status']!='EVALUATED' or observation['solid_count']!=1:
        raise ValueError('Source audit is not eligible')
    schema=c['schema']
    if schema=='adaptive-rational-prism-construction-1':
        embedded=_json(c['audit_utf8'])
        if native:
            if expected_audit_sha256!=c['binding']['audit_sha256']:raise ValueError('Original rational audit differs')
        else:
            if json.dumps(embedded['observation'],sort_keys=True,separators=(',',':'))!=json.dumps(observation,sort_keys=True,separators=(',',':')):
                raise ValueError('Rational browser audit differs')
            execution=_json(embedded['limitations'][-1])['execution']
            if (execution['audit_module_sha256']!=importer['module_sha256'] or
                    execution['audit_wasm_sha256']!=importer['binary_sha256']):
                raise ValueError('Rational browser importer differs')
        extracted={f['index']:f for f in _json(c['observation_utf8'])['faces']}
        kinds={i:{'Geom_SurfaceOfLinearExtrusion':8,'Geom_BSplineSurface':6,'Geom_BezierSurface':5}[f['surface']['type']] for i,f in extracted.items()}
    else:
        keys={'adaptive-rectilinear-construction-1':'rectilinear_parameters','adaptive-rectilinear-construction-2':'rectilinear_parameters',
              'adaptive-periodic-construction-1':'revolution_parameters','adaptive-spherical-construction-1':'spherical_parameters'}
        if json.dumps(c['extraction'],sort_keys=True,separators=(',',':'))!=json.dumps(observation.get(keys[schema]),sort_keys=True,separators=(',',':')):raise ValueError('Audit extraction differs from construction')
        extracted={f.get('session_index',f.get('index')):f for f in c['extraction']['faces']}
        kinds={i:(3 if schema=='adaptive-spherical-construction-1' else
                  {'plane':0,'cylinder':1}[f['surface']['kind']] if schema=='adaptive-periodic-construction-1' else 0) for i,f in extracted.items()}
    if set(extracted)!={f['session_index'] for f in faces}:raise ValueError('Construction face inventory differs')
    context=dict(certificate_sha256=expected_certificate_sha256,source_binding=c['binding'],audit_sha256=expected_audit_sha256,
                 importer=dict(importer),frame='original_part',units='mm')
    context_id=identity(context);rows=[]
    for face,metadata in zip(faces,plain):
        n=face['session_index'];original=extracted[n]
        if face['orientation']!=original['orientation'] or face['surface_type']!=kinds[n]:
            raise ValueError('Audit and construction face metadata differ')
        location=tuple(Q(v) for v in face['location'])
        if 'location' in original and location!=tuple(Q.from_float(float.fromhex(v)) for v in original['location']):
            raise ValueError('Original face placements differ')
        if native:
            binding=dict(source_sha256=record['source_sha256'],snapshot_sha256=record['imported_snapshot_sha256'],
                         importer_sha256=importer['binary_sha256'],face=metadata)
            native_id=sha256(json.dumps(binding,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            if face.get('source_face_id')!=native_id:raise ValueError('Native source-face identity differs')
        else:
            if 'source_face_id' in face:raise ValueError('Raw browser audit has no native face IDs')
            native_id=None
        row=dict(session_index=n,surface_type=face['surface_type'],orientation=face['orientation'],
                 location=[qdata(v) for v in location],native_face_id=native_id,persistent_name=None)
        rows.append(dict(**row,reference_sha256=identity(dict(import_context_sha256=context_id,face=row)),
            association_id=identity(dict(certificate_sha256=expected_certificate_sha256,source_face_index=n))))
    result=dict(schema=SCHEMA,scope='original_import_metadata_only',context=context,import_context_sha256=context_id,
                placement_encoding='row_major_3x4_binary64_exact_rationals_translation_mm',persistent_names='not_exported_by_importer',
                faces=rows,contact_assessed=False,machining_features_assigned=False)
    if len(canonical(result))>1024**2:raise ValueError('Face provenance response budget exceeded')
    return result


def verify_face_provenance(value,certificate,audit,**pins):
    expected=build_face_provenance(certificate,audit,**pins)
    if canonical(value)!=canonical(expected):raise ValueError('Source-face provenance differs')
    return expected
