"""Separate exact transform arithmetic from conservative spatial enclosure."""
from itertools import product
from math import prod

from .domain import canonical, identity, qdata
from .indexed_frames import IndexedOrientation
from .indexed_queries import ClosedBounds, transform_query


def _inputs(pose, query):
    if type(pose) is not IndexedOrientation:
        raise ValueError('Exact indexed orientation required')
    # Recheck the value contract, including exact unit coefficients.
    IndexedOrientation.from_data(pose.to_data())
    return ClosedBounds(query.low, query.high)


def _bounds_data(bounds):
    return dict(low=[qdata(v) for v in bounds.low], high=[qdata(v) for v in bounds.high])


def _record(pose, query, enclosure):
    widths = tuple(b-a for a, b in zip(query.low, query.high))
    enclosed_widths = tuple(b-a for a, b in zip(enclosure.low, enclosure.high))
    volume, enclosed_volume = prod(widths), prod(enclosed_widths)
    return dict(schema='adaptive-indexed-enclosure-evidence-1', scope='exact_rational_query_transform_only',
                pose_id=pose.id, pose=pose.to_data(), query_id=identity(_bounds_data(query)),
                query=_bounds_data(query), enclosure=_bounds_data(enclosure),
                input_extents_mm=[qdata(v) for v in widths],
                enclosure_extents_mm=[qdata(v) for v in enclosed_widths],
                arithmetic_error_upper_mm=[0, 1], rigid_image_volume_mm3=qdata(volume),
                enclosure_volume_mm3=qdata(enclosed_volume), enclosure_excess_volume_mm3=qdata(enclosed_volume-volume),
                assumptions=['exact_rational_inputs', 'exact_unit_rigid_pose', 'closed_affine_box', 'tight_axis_aligned_enclosure'])


def transform_query_with_evidence(pose, query):
    """Return the existing conservative result and a detached budget record."""
    closed = _inputs(pose, query)
    enclosure = transform_query(pose, closed)
    return enclosure, _record(pose, closed, enclosure)


def verify_indexed_enclosure(record, pose, query):
    """Check tight enclosure by corner extrema, independently of interval code."""
    closed = _inputs(pose, query)
    axis = pose.spindle.axis
    i, j = (axis+1) % 3, (axis+2) % 3
    matrix = [[int(r == c) for c in range(3)] for r in range(3)]
    matrix[i][i], matrix[i][j] = pose.cosine, -pose.sine
    matrix[j][i], matrix[j][j] = pose.sine, pose.cosine
    origin = pose.spindle.origin
    corners = [tuple(origin[r]+sum(matrix[r][c]*(point[c]-origin[c]) for c in range(3)) for r in range(3))
               for point in product(*zip(closed.low, closed.high))]
    enclosure = ClosedBounds(tuple(min(p[k] for p in corners) for k in range(3)),
                             tuple(max(p[k] for p in corners) for k in range(3)))
    if canonical(record) != canonical(_record(pose, closed, enclosure)):
        raise ValueError('Indexed enclosure evidence differs from exact input and corner extrema')
    return True
