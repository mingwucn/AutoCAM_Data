"""Exact milling pose/sweep constructors, independent of task services."""
from .domain import Bounds, integer, triple
from .geometry import Box, Cylinder, Empty, Sphere, Union
from .machining_values import MillingTool, AxialPlunge, SideMill


def plunge_geometry(tool, motion):
    """Exact continuous cutter, shank and holder sweeps for the declared motion."""
    if not isinstance(tool, MillingTool) or not isinstance(motion, AxialPlunge):
        raise ValueError("A supported tool and axial plunge are required")
    axis, sign = motion.axis, motion.sign
    start, end = motion.start_tip[axis], motion.end_tip[axis]
    radial_center = tuple(c for k, c in enumerate(motion.end_tip) if k != axis)

    def cylinder(first, last, radius):
        return Cylinder(axis, radial_center, radius, min(first, last), max(first, last))

    if tool.profile == "FLAT_END":
        cutting = cylinder(start-sign*tool.flute_length, end, tool.radius)
    else:
        center = list(motion.end_tip); center[axis] -= sign*tool.radius
        cutting = Union((cylinder(start-sign*tool.flute_length, center[axis], tool.radius),
                         Sphere(tuple(center), tool.radius)))
    shank = Empty() if tool.flute_length == tool.usable_reach else cylinder(
        start-sign*tool.usable_reach, end-sign*tool.flute_length, tool.shank_radius)
    holder = cylinder(start-sign*(tool.usable_reach+tool.holder_length),
                      end-sign*tool.usable_reach, tool.holder_radius)
    return {"cutting": cutting, "shank": shank, "holder": holder}


def side_geometry(tool, motion):
    """Continuous union of all tool poses, using exact existing primitives."""
    if not isinstance(tool, MillingTool) or not isinstance(motion, SideMill):
        raise ValueError('Supported milling tool and side motion required')
    axis, travel, sign = motion.axis, motion.travel_axis, motion.sign
    start, end = sorted((motion.start_tip, motion.end_tip), key=lambda p: p[travel])
    transverse = next(k for k in range(3) if k not in (axis, travel))

    def cylinder_sweep(back, front, radius):
        axial = sorted((start[axis]+sign*back, start[axis]+sign*front))
        low, high = list(start), list(end)
        low[axis], high[axis] = axial
        low[transverse] -= radius; high[transverse] += radius
        ends = tuple(Cylinder(axis, tuple(p[k] for k in range(3) if k != axis), radius, *axial)
                     for p in (start, end))
        return Union((Box(Bounds(tuple(low), tuple(high))), *ends))

    def sphere_sweep(radius):
        centers = []
        for p in (start, end):
            center = list(p); center[axis] -= sign*radius; centers.append(tuple(center))
        cylinder = Cylinder(travel, tuple(centers[0][k] for k in range(3) if k != travel),
                            radius, start[travel], end[travel])
        return Union((cylinder, *(Sphere(p, radius) for p in centers)))

    cutting = cylinder_sweep(-tool.flute_length, 0 if tool.profile == 'FLAT_END' else -tool.radius, tool.radius)
    if tool.profile == 'BALL_END':
        cutting = Union((cutting, sphere_sweep(tool.radius)))
    shank = Empty() if tool.flute_length == tool.usable_reach else cylinder_sweep(
        -tool.usable_reach, -tool.flute_length, tool.shank_radius)
    holder = cylinder_sweep(-tool.usable_reach-tool.holder_length, -tool.usable_reach, tool.holder_radius)
    return dict(cutting=cutting, shank=shank, holder=holder)


def milling_pose_geometry(tool, axis, sign, tip):
    if type(tool) is not MillingTool:
        raise ValueError('Supported milling assembly required')
    integer(axis, 'tool axis', 0, 2)
    if type(sign) is not int or sign not in (-1, 1):
        raise ValueError('Signed tool direction required')
    tip = triple(tip)
    center = tuple(v for k, v in enumerate(tip) if k != axis)

    def cylinder(a, b, radius):
        ends = (tip[axis]+sign*a, tip[axis]+sign*b)
        return Cylinder(axis, center, radius, min(ends), max(ends))

    if tool.profile == 'FLAT_END':
        cutter = cylinder(-tool.flute_length, 0, tool.radius)
    else:
        ball_center = list(tip); ball_center[axis] -= sign*tool.radius
        cutter = Union((cylinder(-tool.flute_length, -tool.radius, tool.radius), Sphere(tuple(ball_center), tool.radius)))
    shank = Empty() if tool.flute_length == tool.usable_reach else cylinder(-tool.usable_reach, -tool.flute_length, tool.shank_radius)
    holder = cylinder(-tool.usable_reach-tool.holder_length, -tool.usable_reach, tool.holder_radius)
    return dict(cutting=cutter, shank=shank, holder=holder)


