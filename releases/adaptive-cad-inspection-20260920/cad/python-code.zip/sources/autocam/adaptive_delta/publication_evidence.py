"""Geometric publication evidence values; independent of logical event identity."""
from dataclasses import replace
from fractions import Fraction

from .domain import canonical, digest, fields, identity, qdata, qread
from .evidence import predicate_version, _predicate_assumptions
from .geometry import from_data, region_id
from .partition import VolumeInterval


def _interval(data):
    fields(data,('lower_mm3','upper_mm3'))
    result=VolumeInterval(qread(data['lower_mm3']),qread(data['upper_mm3']))
    if result.lower<0:raise ValueError('Negative publication volume')
    return result


def conservation_record(before,after,removed):
    # Reclassification can raise a lower bound without creating material. Compare
    # histories only after rebasing to the same accepted refined partition.
    rebased=replace(before,domain=after.domain)
    prior=rebased.remaining();current=after.remaining()
    combined=VolumeInterval(current.lower+removed.lower,current.upper+removed.upper)
    return validate_conservation(dict(schema='adaptive-interval-conservation-1',
        method='same_partition_remaining_and_interval_overlap',
        before_remaining=prior.to_data(),after_remaining=current.to_data(),
        removed=removed.to_data(),sum_bounds=combined.to_data(),
        remaining_nonincrease=current.lower<=prior.lower and current.upper<=prior.upper,
        intervals_overlap=max(prior.lower,combined.lower)<=min(prior.upper,combined.upper)),removed)


def validate_conservation(record,removed):
    fields(record,('schema','method','before_remaining','after_remaining','removed','sum_bounds',
                   'remaining_nonincrease','intervals_overlap'))
    if record['schema']!='adaptive-interval-conservation-1' or record['method']!='same_partition_remaining_and_interval_overlap':
        raise ValueError('Unsupported conservation record')
    prior=_interval(record['before_remaining']);current=_interval(record['after_remaining'])
    supplied=_interval(record['removed']);combined=_interval(record['sum_bounds'])
    if supplied!=removed or combined!=VolumeInterval(current.lower+removed.lower,current.upper+removed.upper):
        raise ValueError('Conservation operands differ')
    monotone=current.lower<=prior.lower and current.upper<=prior.upper
    overlap=max(prior.lower,combined.lower)<=min(prior.upper,combined.upper)
    if record['remaining_nonincrease'] is not monotone or record['intervals_overlap'] is not overlap or not (monotone and overlap):
        raise ValueError('Publication conservation check failed')
    # Normalize only through canonical serialization at the caller boundary;
    # this value builder must not mutate a supplied evidence object.
    return record


def publication_evidence(before,after,event,result,*,before_domain_artifact,after_domain_artifact,
                         normalizer,previous_evidence=None,recorded_conservation=None):
    """Build evidence, or structurally check supplied arithmetic without replaying it."""
    from .storage import action_from_data
    digest(before_domain_artifact);digest(after_domain_artifact)
    if previous_evidence is not None:digest(previous_evidence)
    if (before.domain.source.to_data()!=after.domain.source.to_data()
        or before.tool_catalog!=after.tool_catalog or before.turning_axis!=after.turning_axis):
        raise ValueError('Publication changes frozen source or setup')
    event_id=identity(event)
    if (event_id!=result.event_id or event.get('before_hash')!=before.logical_hash
        or event.get('parent_event')!=before.parent_event or after.parent_event!=event_id
        or event.get('domain_hash')!=after.domain.logical_hash or event.get('domain_artifact')!=after_domain_artifact
        or result.before_hash!=before.logical_hash or result.after_hash!=after.logical_hash
        or result.status!='ACCEPTED' or result.duplicate_delivery or after.revision!=before.revision+1):
        raise ValueError('Publication event/state/result binding differs')
    if type(normalizer) is not Fraction or normalizer<0 or result.removed.lower<0 or result.reward!=(result.removed.lower/normalizer if normalizer else Fraction()):
        raise ValueError('Publication reward or removal differs')
    if event.get('reward')!=qdata(result.reward):raise ValueError('Event reward differs')
    if event.get('kind')=='action':
        action=action_from_data(event['action']);envelope=action.envelope
        repeated=region_id(envelope) in {region_id(e) for e in before.envelopes}
        expected=before.envelopes if repeated else before.envelopes+(envelope,)
        if (canonical([e.to_data() for e in after.envelopes])!=canonical([e.to_data() for e in expected])
            or event.get('removed')!=result.removed.to_data()
            or result.reason!=('idempotent_geometry' if repeated else 'bounded_removal')):
            raise ValueError('Publication action/history differs')
        safety=event['safety'];fields(safety,('status','reason','witness'))
        if safety['status']!='PASS':raise ValueError('Accepted publication lacks passed safety')
        if repeated and (result.removed.lower or result.removed.upper):raise ValueError('Repeated geometry removes material')
        operation=dict(kind='action',action_id=identity(action.to_data()),parameters=action.to_data(),
                       required_scope=action.scope,achieved_scope=action.scope,
                       scope_basis='declared_geometric_action_with_passed_safety')
    elif event.get('kind')=='refinement':
        envelope=from_data(event['envelope'])
        if (canonical([e.to_data() for e in after.envelopes])!=canonical([e.to_data() for e in before.envelopes])
            or result.removed.lower or result.removed.upper or result.reward or result.reason!='refinement_only'):
            raise ValueError('Refinement changes material history or earns removal')
        operation=dict(kind='refinement',action_id=None,parameters=dict(envelope=envelope.to_data(),max_depth=event['max_depth']),
                       required_scope='PARTITION_REFINEMENT',achieved_scope='PARTITION_REFINEMENT',
                       scope_basis='unchanged_removal_history')
        safety=None
    else:raise ValueError('Unsupported publication kind')
    from .packed_domain import PackedDomainSnapshot
    def count(domain):
        return domain.count if type(domain) is PackedDomainSnapshot else len(domain.leaves)
    old_count,new_count=count(before.domain),count(after.domain)
    if new_count<old_count or (new_count-old_count)%7:raise ValueError('Invalid refinement leaf counts')
    source=after.domain.source
    predicates={role:dict(source_id=region_id(shape),version=predicate_version(shape),assumptions=_predicate_assumptions(shape))
                for role,shape in (('stock',source.stock),('target',source.target),('protected',source.protected),('envelope',envelope))}
    conserved=(conservation_record(before,after,result.removed) if recorded_conservation is None
               else validate_conservation(recorded_conservation,result.removed))
    if operation['kind']=='refinement' and conserved['before_remaining']!=conserved['after_remaining']:
        raise ValueError('Refinement changes rebased remaining bounds')
    return dict(schema='adaptive-publication-evidence-1',previous_evidence=previous_evidence,
        event_id=event_id,parent_event=before.parent_event,before_hash=before.logical_hash,after_hash=after.logical_hash,
        source_id=source.geometry_id,policy_id=identity(source.policy.to_data()),operation=operation,
        predicate_contracts=predicates,predicate_basis='independent_certificate_families_not_archived_query_proofs',
        refinement=dict(before_domain_hash=before.domain.logical_hash,after_domain_hash=after.domain.logical_hash,
            before_artifact=before_domain_artifact,after_artifact=after_domain_artifact,
            before_leaf_count=old_count,after_leaf_count=new_count,split_count=(new_count-old_count)//7,
            reconstruction='compare_complete_bound_partition_integer_addresses'),
        reward_policy=dict(profile='definite_new_removal_over_initial_eligible_upper_v1',normalizer_mm3=qdata(normalizer)),
        conservation=conserved,safety=safety,result=result.to_data(),manufacturing_qualified=False)
