"""Exact box point-shadow operands; read-only, never finite-tool access."""
from dataclasses import dataclass

from .domain import Bounds, Relation, canonical, digest, identity, integer
from .geometry import Box, Cutout, Empty, Union
from .transitions import MaterialState

PROFILE = 'closed_box_axis_point_shadow_1'
REASONS = ('protected', 'fixture', 'combined')


def _boxes(shape):
    if type(shape) is Empty:
        return ()
    if type(shape) is Box:
        return (shape,)
    if type(shape) is Union:
        return tuple(box for child in shape.children for box in _boxes(child))
    raise ValueError('Point-shadow profile requires exact Box, Empty or Union blockers')


@dataclass(frozen=True, slots=True)
class DirectionalShadowView:
    state: MaterialState
    axis: int
    sign: int
    fixture: object
    semantic_id: str

    def __post_init__(self):
        if type(self.state) is not MaterialState:
            raise ValueError('Typed accepted material required')
        integer(self.axis, 'part-frame direction axis', 0, 2)
        integer(self.sign, 'part-frame travel sign', -1, 1)
        if self.sign == 0:
            raise ValueError('Nonzero direction required')
        digest(self.semantic_id)
        exterior = self.exterior
        for shape in (self.state.domain.source.protected, self.fixture):
            for box in _boxes(shape):
                if any(box.bounds.low[k] <= exterior.low[k] or
                       box.bounds.high[k] >= exterior.high[k] for k in range(3)):
                    raise ValueError('Blockers must lie strictly within the declared exterior')

    @property
    def exterior(self):
        root = self.state.domain.source.root
        return Bounds(tuple(x-root.side for x in root.bounds.low),
                      tuple(x+root.side for x in root.bounds.high))

    def shadow(self, reason='combined'):
        if reason not in REASONS:
            raise ValueError('Unknown point-shadow reason')
        protected = self.state.domain.source.protected
        obstacles = (protected, self.fixture) if reason == 'combined' else (
            protected if reason == 'protected' else self.fixture,)
        boxes = []
        for obstacle in obstacles:
            for box in _boxes(obstacle):
                low, high = list(box.bounds.low), list(box.bounds.high)
                if self.sign == 1:
                    high[self.axis] = self.exterior.high[self.axis]
                else:
                    low[self.axis] = self.exterior.low[self.axis]
                boxes.append(Box(Bounds(tuple(low), tuple(high))))
        return Union(tuple(boxes))

    def _query(self, query):
        if type(query) is not Bounds:
            raise ValueError('Exact positive-volume query bounds required')
        root = self.state.domain.source.root.bounds
        if any(query.low[k] < root.low[k] or query.high[k] > root.high[k] for k in range(3)):
            raise ValueError('Point-shadow queries must lie within the source root')

    def classify_shadow(self, query, reason='combined'):
        self._query(query)
        return self.shadow(reason).classify(query)

    def classify(self, query, reason='combined'):
        self._query(query)
        source = self.state.domain.source
        shadow = self.shadow(reason).classify(query)
        stock = Cutout(source.stock, self.state.envelopes).classify(query)
        protected = source.protected.classify(query)
        fixture = self.fixture.classify(query)
        if Relation.OUTSIDE in (shadow, stock) or Relation.INSIDE in (protected, fixture):
            return Relation.OUTSIDE
        if shadow == stock == Relation.INSIDE and protected == fixture == Relation.OUTSIDE:
            return Relation.INSIDE
        return Relation.MIXED

    def to_data(self):
        source = self.state.domain.source
        return dict(schema='adaptive-directional-shadow-view-1', predicate_version=PROFILE,
            projection_only=True, operation_authorized=False, frame='original_part',
            direction_convention='entry_into_part_exterior_ray_x_minus_lambda_d',
            axis=self.axis, sign=self.sign, source_geometry_id=source.geometry_id,
            root_id=source.root.id, root=source.root.to_data(), exterior=self.exterior.to_data(),
            partition_id=self.state.domain.logical_hash, material_hash=self.state.logical_hash,
            semantic_id=self.semantic_id, fixture_id=identity(self.fixture.to_data()),
            fixture=self.fixture.to_data(), protected=source.protected.to_data(),
            remaining_stock=Cutout(source.stock, self.state.envelopes).to_data(),
            shadows={reason: self.shadow(reason).to_data() for reason in REASONS},
            set_semantics='closed_current_stock_intersect_closed_point_shadow_minus_closed_protected_and_fixture',
            boundary_semantics='closed_ray_tangency_blocks_partial_cells_remain_mixed',
            finite_tool_access_status='NOT_ASSESSED', tool_length_status='NOT_ASSESSED',
            stock_exposure_status='NOT_ASSESSED', machine_motion_status='NOT_ASSESSED')

    def verify(self, payload):
        if canonical(payload) != canonical(self.to_data()):
            raise ValueError('Point-shadow projection differs from current bound inputs')
        return identity(payload)
