"""Offline diagnostic inference through the admitted-package boundary."""
import json
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import tempfile

from . import model_finalization as p
from . import v4_consumer_definition as d

CODE_INVENTORY_PIN = 'fc196384037f965edd3a3b837f7e8e71dd6c336b150ebb0d72e4402fef14169c'
MAX_JOB_BYTES = 8 * 1024**2
MAX_REQUEST_BYTES = 2 * 1024**2
WORKER = Path(__file__).resolve().parents[3]/'tools/shadow_gym/v4_consumer_worker.py'


def host_environment():
    return dict(schema='task-consumer-adapter-environment-1', python_version=sys.version,
        python_sha256=p.digest(Path(sys.executable).read_bytes()), implementation=platform.python_implementation(),
        platform=sys.platform, machine=platform.machine(), isolated_stdlib=True,
        numerical_precision=dict(radix=sys.float_info.radix, mantissa_bits=sys.float_info.mant_dig,
                                 max_exponent=sys.float_info.max_exp))


@p.admission_boundary
def prepare(package_raw, expected_sha256, store, trusted):
    """Return verified immutable execution bytes without creating files or importing a scorer."""
    subject = p.load(package_raw, expected_sha256, store, trusted)
    return (subject, *_prepare_payload(subject['records'], store))


def _prepare_payload(records, store):
    """Shared byte validation. This helper does not assert package admission."""
    payload = p.document(records['payload'], store, role='payload')
    definition = p.document(records['model_definition'], store, role='model_definition')
    compatibility = p.document(records['compatibility'], store, role='compatibility')
    p.require(compatibility.get('adapter') == 'frozen_python_stdlib_v4'
              and compatibility.get('runtime_activation') is False, 'Unsupported consumer adapter')
    p.require(payload['schema'] == 'task-consumer-payload-1'
              and compatibility['schema'] == 'task-model-compatibility-1'
              and compatibility.get('status') == 'Compatible', 'Unsupported candidate schema/status')
    members = payload.get('members'); names = set()
    p.require(type(members) is list and 1 <= len(members) <= 100, 'Candidate member limit')
    for row in members:
        name = row['path']; path = PurePosixPath(name)
        p.require(type(name) is str and bool(path.parts) and not path.is_absolute() and path.as_posix() == name
                  and '..' not in path.parts and '\\' not in name and ':' not in name and '\x00' not in name
                  and name.casefold() not in names, 'Unsafe/duplicate candidate member')
        names.add(name.casefold())
        p.require(row['reference']['classification'] != 'Restricted', 'Restricted embedded content')
        if name.startswith('consumer-src/'):
            p.require(row['reference']['role'] == 'consumer_source', 'Consumer source role mismatch')
    files = {row['path']:p.resolve(row['reference'], store) for row in payload['members']}
    p.require(sum(map(len, files.values())) <= MAX_JOB_BYTES, 'Consumer payload size limit')
    required = {'checkpoint.json', 'feature-contract.json', 'consumer-vectors.json',
                'tool-catalog.json', 'compatibility.json', 'model-card.md'}
    p.require(required <= files.keys() and all(name in required or name.startswith('consumer-src/')
                                              for name in files), 'Unsupported consumer layout')
    role_paths = {row['reference']['role']:row['path'] for row in payload['members']
                  if row['reference']['role'] != 'consumer_source'}
    p.require(all(role_paths.get(role) == path for role, path in (
        ('checkpoint', 'checkpoint.json'), ('features', 'feature-contract.json'),
        ('consumer_vectors', 'consumer-vectors.json'), ('model_card', 'model-card.md'),
        ('catalog', 'tool-catalog.json'), ('original_compatibility', 'compatibility.json'))),
        'Consumer member role/path mismatch')
    source_inventory = [dict(path=name, sha256=p.digest(raw), size=len(raw))
                        for name, raw in sorted(files.items()) if name != 'model-card.md']
    p.require(compatibility.get('source_inventory') == source_inventory, 'Consumer inventory mismatch')
    code = [row for row in source_inventory if row['path'].startswith('consumer-src/')]
    p.require(p.digest(p.encode(code)) == CODE_INVENTORY_PIN, 'Unsupported frozen scorer source')
    p.require(definition == d.definition(files['feature-contract.json']), 'Unsupported model definition semantics')
    p.require(compatibility.get('definition_sha256') == records['model_definition']['sha256']
              and compatibility.get('checkpoint_sha256') == p.digest(files['checkpoint.json'])
              and compatibility.get('features_sha256') == p.digest(files['feature-contract.json']),
              'Consumer definition/parameter/features binding mismatch')
    p.require(compatibility.get('catalog_sha256') == p.digest(files['tool-catalog.json']), 'Consumer catalog mismatch')
    environment = p.encode(host_environment())
    p.require(compatibility.get('adapter_environment_sha256') == p.digest(environment)
              and store.get(p.digest(environment)) == environment, 'Consumer host compatibility mismatch')
    semantic_hash = compatibility.get('semantic_validation_sha256')
    p.require(type(semantic_hash) is str and semantic_hash in store
              and p.digest(store[semantic_hash]) == semantic_hash, 'Consumer validation unresolved')
    validation = json.loads(store[semantic_hash])
    p.require(validation.get('schema') == 'task-v4-consumer-probe-1' and validation.get('status') == 'Passed'
              and validation.get('actual_vectors') == 2 and validation.get('runtime_activation') is False,
              'Consumer semantic validation missing')
    return files, definition, compatibility


@p.admission_boundary
def predict(package_raw, expected_sha256, store, trusted, request, *, timeout_seconds=30):
    """Select an index for normalized features; does not authorize a machining operation."""
    subject, files, definition, compatibility = prepare(package_raw, expected_sha256, store, trusted)
    value = _execute(files, definition, compatibility, request, timeout_seconds)
    return dict(schema='task-admitted-v4-inference-1', package_sha256=expected_sha256,
        checkpoint_sha256=compatibility['checkpoint_sha256'],
        definition_sha256=subject['records']['model_definition']['sha256'],
        request_sha256=value['request_sha256'], selected_index=value['selected_index'],
        claim_scope=subject['claim_scope'], limitations=subject['limitations'],
        prohibited_uses=subject['prohibited_uses'], runtime_activation=False, manufacturing_qualified=False)


def _execute(files, definition, compatibility, request, timeout_seconds):
    p.require(type(timeout_seconds) in (int, float) and 0 < timeout_seconds <= 60, 'Invalid consumer timeout')
    p.require(type(request) is dict and set(request) == {'features', 'mask'}, 'Invalid inference request fields')
    request_raw = p.encode(request)
    p.require(len(request_raw) <= MAX_REQUEST_BYTES, 'Inference request size limit')
    # Callers have completed their respective admission or candidate byte checks.
    with tempfile.TemporaryDirectory(prefix='shadow-admitted-v4-') as temporary:
        root = Path(temporary)
        job_files = {'payload/'+name:raw for name, raw in files.items()}
        job_files.update({'request.json':request_raw, 'definition.json':p.encode(definition),
            'compatibility.json':p.encode(compatibility), 'adapter.py':Path(d.__file__).read_bytes()})
        p.require(sum(map(len, job_files.values())) <= MAX_JOB_BYTES, 'Consumer job size limit')
        for name, raw in job_files.items():
            path = root/name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        manifest = p.encode(dict(schema='task-v4-consumer-job-1', members=[
            dict(path=name, sha256=p.digest(raw), size=len(raw)) for name, raw in sorted(job_files.items())]))
        (root/'job.json').write_bytes(manifest)
        command = [sys.executable, '-I', '-S', '-B'] + (['-O'] if sys.flags.optimize else [])
        command += [str(WORKER), '--job', str(root), '--expected-sha256', p.digest(manifest)]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=timeout_seconds, cwd=root)
        except subprocess.TimeoutExpired as error:
            raise p.AdmissionError('Consumer inference timed out') from error
        p.require(result.returncode == 0, 'Consumer execution failed: '+result.stderr[-2000:])
        value = json.loads(result.stdout)
        p.require(type(value) is dict and set(value) == {'schema', 'selected_index', 'request_sha256',
                  'checkpoint_sha256', 'runtime_activation'}, 'Invalid consumer result')
        index = value['selected_index']
        p.require(value['schema'] == 'task-v4-consumer-output-1'
                  and value['request_sha256'] == p.digest(request_raw)
                  and value['checkpoint_sha256'] == compatibility['checkpoint_sha256']
                  and value['runtime_activation'] is False
                  and type(index) is int and 0 <= index < len(request['features'])
                  and request['mask'][index] == 1, 'Consumer result identity or index mismatch')
    return value


@p.admission_boundary
def validate_candidate(records, store, *, timeout_seconds=30):
    """Run only saved validation vectors. No caller inference request or approval."""
    files, definition, compatibility = _prepare_payload(records, store)
    vectors = json.loads(files['consumer-vectors.json'])
    p.require(type(vectors) is list and len(vectors) == 2, 'Two saved consumer vectors required')
    vector = vectors[0]
    request = dict(features=vector['features'], mask=vector['mask'])
    value = _execute(files, definition, compatibility, request, timeout_seconds)
    p.require(type(vector['expected_action']) is int and value['selected_index'] == vector['expected_action'],
              'Saved validation action mismatch')
    probe = json.loads(store[compatibility['semantic_validation_sha256']])
    return dict(schema='task-v4-candidate-validation-1', status='Passed',
        subject_payload_sha256=records['payload']['sha256'],
        definition_sha256=records['model_definition']['sha256'],
        compatibility_sha256=records['compatibility']['sha256'],
        checkpoint_sha256=compatibility['checkpoint_sha256'],
        host_environment_sha256=compatibility['adapter_environment_sha256'],
        saved_vectors=2, semantic_checks=len(probe['checks']),
        semantic_validation_sha256=compatibility['semantic_validation_sha256'],
        worker_sha256=p.digest(WORKER.read_bytes()), adapter_sha256=p.digest(Path(d.__file__).read_bytes()),
        consumer_sha256=p.digest(Path(__file__).read_bytes()), finalizer_sha256=p.digest(Path(p.__file__).read_bytes()),
        optimization=sys.flags.optimize, isolated_stdlib_process=True,
        caller_inference_request_accepted=False, attributable_receipt=False,
        canonical_model_admission=False, runtime_activation=False, manufacturing_qualified=False, evidence_case_sealed=False)
