"""Seal an external task evidence case over an already admitted package."""
import json
import math
import re

from . import model_finalization as packages

REQUIRED_ROLES=frozenset(('objective','source','dataset','annotations','split','preprocessing','features',
    'model_definition','recipe','producer','environment','hardware','seeds','training_run','checkpoint',
    'profile','evaluation','selection','consumer_validation','content_review','package_approval','package',
    'reproduction','negative_evidence','limitations'))
RELATIONS=frozenset(('derived_from','trained_with','evaluated_by','selected_by','packaged_as',
    'reproduced_by','rejected_because','approved_by'))
REPRO_TYPES=frozenset(('exact_rerun','numerically_equivalent_rerun','statistical_replication','scientific_reproduction'))
REPRO_ROLES=frozenset(('reproduction','reproduction_report'))
REQUIRED_EDGES=(('checkpoint','trained_with','training_run'),('checkpoint','evaluated_by','evaluation'),
    ('checkpoint','selected_by','selection'),('checkpoint','packaged_as','package'),
    ('evaluation','derived_from','profile'),('evaluation','derived_from','dataset'),
    ('selection','derived_from','negative_evidence'),('package','approved_by','package_approval'),
    ('package','reproduced_by','reproduction'))
require=packages.require


def number(value):return type(value) in (int,float) and math.isfinite(value)


def check_reproduction(report,profile):
    kind=report.get('claim_type');tolerance=report.get('tolerance')
    require(kind in REPRO_TYPES and report.get('outcome') in ('Reproduced','WithinTolerance'),
            'Reproduction outcome missing or unsuccessful')
    require(type(tolerance) is dict and set(tolerance)=={'absolute','relative'}
            and all(number(v) and v>=0 for v in tolerance.values())
            and profile.get('case_tolerances',{}).get(kind)==tolerance,'Undeclared reproduction tolerance')
    if kind=='exact_rerun':
        require(report['outcome']=='Reproduced' and tolerance==dict(absolute=0,relative=0),'Exact rerun is not exact')


def field(value,pointer):
    require(type(pointer) is str and pointer.startswith('/'),'Metric field pointer required')
    for token in pointer[1:].split('/'):
        token=token.replace('~1','/').replace('~0','~')
        if type(value) is list:
            require(token.isdigit() and str(int(token))==token,'Invalid array field pointer')
            value=value[int(token)]
        else:
            require(type(value) is dict and token in value,'Unresolved metric field')
            value=value[token]
    return value


def bindings(subject,package,store):
    records=subject['records'];result={k:v for k,v in records.items() if k in REQUIRED_ROLES}
    payload=packages.document(records['payload'],store)
    for member in payload['members']:
        if member['reference']['role'] in ('checkpoint','features'):
            result[member['reference']['role']]=member['reference']
    result['package_approval']=package['approval']
    wrapper=packages.document(records['training_run'],store)
    lineage=wrapper.get('lineage');require(type(lineage) is dict,'Training lineage references missing')
    for role in REQUIRED_ROLES-set(result)-{'package'}:
        require(role in lineage,'Mandatory lineage binding missing: '+role)
        result[role]=lineage[role]
    return result


@packages.admission_boundary
def seal(package_ref,nodes,edges,claims,store,trusted):
    package_raw=packages.resolve(package_ref,store,role='model_package')
    subject=packages.load(package_raw,package_ref['sha256'],store,trusted);package=json.loads(package_raw)
    expected=bindings(subject,package,store);expected['package']=package_ref
    profile=packages.document(subject['records']['profile'],store)
    require(type(nodes) is list and 1<=len(nodes)<=256,'Invalid evidence node count')
    by_id={};by_role={}
    for node in nodes:
        require(type(node) is dict and set(node) in ({'id','role','state','schema','reference'},
            {'id','role','state','schema','reference','verification'}),'Invalid node fields')
        nid=node['id'];role=node['role']
        require(type(nid) is str and re.fullmatch('[a-z][a-z0-9_-]{0,63}',nid) is not None
                and nid not in by_id,'Invalid/duplicate node identity')
        require(type(role) is str and bool(role),'Missing node role')
        require(node['state'] in ('Available','NotApplicable'),'Unavailable or blocked node: '+nid)
        ref=node['reference'];packages.resolve(ref,store)
        require(node['schema']==ref['schema'],'Node schema/reference mismatch')
        if role in REQUIRED_ROLES:
            require(role not in by_role,'Duplicate mandatory role: '+role)
            require(ref==expected[role],'Node differs from approved package lineage: '+role)
            by_role[role]=nid
        if node['state']=='NotApplicable':
            require(role in ('annotations','preprocessing'),'Mandatory lifecycle role cannot be omitted')
            reason=packages.document(ref,store,schema='task-evidence-applicability-1')
            require(reason.get('role')==role and type(reason.get('reason')) is str and bool(reason['reason'])
                    and reason.get('profile_sha256')==subject['records']['profile']['sha256'],
                    'Invalid inapplicability rationale')
            # The admitted profile names a stable rationale identity, avoiding a
            # cycle between the profile bytes and the reason's profile reference.
            reason_id=packages.digest(packages.encode(dict(role=role,reason=reason['reason'])))
            require(profile.get('not_applicable',{}).get(role)==reason.get('reason_id')==reason_id,
                    'Inapplicability not declared by admitted profile')
        if role in REPRO_ROLES:
            if role=='reproduction_report':
                wrapper=packages.document(subject['records']['training_run'],store)
                require(ref in wrapper.get('additional_reproduction',[]),'Unbound additional reproduction evidence')
            report=packages.document(ref,store,schema='task-reproduction-report-1')
            check_reproduction(report,profile)
            verification=node.get('verification')
            details=packages.receipt(verification,store,trusted,role='reproduction_verification',
                scope='reproduction_verification',decision='Verified',subject=ref['sha256'])
            require(details.get('claim_type')==report['claim_type'],'Reproduction verification type mismatch')
        else:require('verification' not in node,'Unexpected node verification role')
        by_id[nid]=node
    require(set(by_role)==REQUIRED_ROLES,'Missing mandatory lifecycle nodes')
    objective=packages.document(by_id[by_role['objective']]['reference'],store)
    require(objective.get('objective_id')==subject['objective_id'],'Scientific objective mismatch')
    limits=packages.document(by_id[by_role['limitations']]['reference'],store)
    require(all(limits.get(k)==subject[k] for k in ('limitations','prohibited_uses','claim_scope')),
            'Limitations differ from approved package')
    require(type(edges) is list and len(edges)<=2048,'Invalid evidence edge count')
    triples=[];adj={nid:set() for nid in by_id};derived={nid:set() for nid in by_id}
    for edge in edges:
        require(type(edge) is dict and set(edge)=={'source','relation','target'},'Invalid edge fields')
        a,r,b=edge['source'],edge['relation'],edge['target']
        require(a in by_id and b in by_id and a!=b and r in RELATIONS,'Unresolved/unknown evidence edge')
        triple=(a,r,b);require(triple not in triples,'Duplicate evidence edge');triples.append(triple)
        adj[a].add(b);adj[b].add(a)
        if r=='derived_from':derived[a].add(b)
    for a,r,b in REQUIRED_EDGES:
        require((by_role[a],r,by_role[b]) in triples,'Mandatory relationship missing')
    visited=set();active=set()
    def visit(nid):
        require(nid not in active,'Derivation cycle')
        if nid in visited:return
        active.add(nid)
        for child in derived[nid]:visit(child)
        active.remove(nid);visited.add(nid)
    for nid in by_id:visit(nid)
    connected=set();pending=[by_role['package']]
    while pending:
        nid=pending.pop()
        if nid in connected:continue
        connected.add(nid);pending.extend(adj[nid]-connected)
    require(connected==set(by_id),'Orphan evidence node')
    require(type(claims) is list and 1<=len(claims)<=512,'No explicit scientific claims or claim budget exceeded')
    claim_ids=set()
    for claim in claims:
        require(type(claim) is dict and set(claim)=={'id','type','scope','support_node','metric_pointer','metric_value',
            'denominator_pointer','denominator','tolerance','limitations'},'Invalid claim fields')
        require(type(claim['id']) is str and bool(claim['id']) and claim['id'] not in claim_ids,'Duplicate/missing claim identity')
        claim_ids.add(claim['id']);kind=claim['type']
        require(kind=='descriptive_metric' or kind in REPRO_TYPES,'Unknown scientific claim type')
        require(claim['scope']==subject['claim_scope'],'Claim exceeds admitted package scope')
        require(type(claim['limitations']) is list and bool(claim['limitations'])
                and all(type(x) is str and bool(x) for x in claim['limitations']),'Claim limitations missing')
        support=by_id[claim['support_node']]
        require(support['state']=='Available' and (support['role']=='evaluation' if kind=='descriptive_metric' else support['role'] in REPRO_ROLES),
                'Claim support role mismatch')
        record=packages.document(support['reference'],store)
        metric=field(record,claim['metric_pointer']);denominator=field(record,claim['denominator_pointer'])
        require(number(metric) and number(claim['metric_value']) and metric==claim['metric_value'],'Metric claim differs from source')
        require(type(denominator) is int and denominator>0 and type(claim['denominator']) is int
                and denominator==claim['denominator'],'Denominator claim differs from source')
        tolerance=claim['tolerance']
        require(type(tolerance) is dict and set(tolerance)=={'absolute','relative'}
                and all(number(x) and x>=0 for x in tolerance.values())
                and profile.get('case_tolerances',{}).get(kind)==tolerance,'Tolerance not declared in admitted profile')
        if kind!='descriptive_metric':
            require(record['claim_type']==kind and record.get('tolerance')==tolerance,'Exact/replication claim or tolerance mismatch')
            if kind=='exact_rerun':
                require(record['outcome']=='Reproduced' and tolerance==dict(absolute=0,relative=0),'Exact rerun is not exact')
    return packages.encode(dict(schema='task-training-evidence-case-1',version='1.0.0',kind='TrainingEvidenceCase',state='Sealed',
        package=package_ref,nodes=sorted(nodes,key=lambda n:n['id']),
        edges=[dict(source=a,relation=r,target=b) for a,r,b in sorted(triples)],claims=sorted(claims,key=lambda c:c['id']),
        runtime_activation=False,manufacturing_qualified=False))


@packages.admission_boundary
def reopen(raw,expected_sha256,store,trusted):
    require(type(raw) is bytes and packages.digest(raw)==expected_sha256,'External case pin mismatch')
    value=json.loads(raw);require(value.get('schema')=='task-training-evidence-case-1','Unknown evidence-case schema')
    require(raw==seal(value['package'],value['nodes'],value['edges'],value['claims'],store,trusted),
            'Sealed case contents or authority changed')
    return value
