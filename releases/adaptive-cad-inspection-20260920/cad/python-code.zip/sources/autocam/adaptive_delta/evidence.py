"""Portable complete-cell predicate certificates and independent arithmetic checks."""
from fractions import Fraction
from itertools import product

from .domain import Bounds, CellAddress, Relation, fields, identity, qdata, qread
from .geometry import Box, Cutout, Cylinder, RoundedCylinder, RoundedAnnulus, Empty, Sphere, Union, UnresolvedRegion, IndexedSolid, has_sphere, has_rounded_cylinder, has_rounded_annulus, region_id, supported
from .partition import AnalyticClassifier

I, O, M = Relation.INSIDE, Relation.OUTSIDE, Relation.MIXED


def _arithmetic_relation(shape, query, interior, prism_resolver=None):
    """Checker does not call Region.classify or trust the claimed relation."""
    from .drill_geometry import ConicalPoint, DrillCutting
    from .face_geometry import AnnularSweep
    from .rational_prism_queries import NominalRationalPrism
    if isinstance(shape, NominalRationalPrism):
        if prism_resolver is None: raise ValueError('Retained rational prism proof required')
        return prism_resolver(shape,query,interior)
    if isinstance(shape, (ConicalPoint, DrillCutting)):
        cone = shape.point if isinstance(shape, DrillCutting) else shape
        back = (cone.sign*(cone.tip[cone.axis]-(shape.cylinder.low if cone.sign == 1 else shape.cylinder.high))
                if isinstance(shape, DrillCutting) else cone.height)
        axial = sorted(cone.sign*(cone.tip[cone.axis]-p) for p in (query.low[cone.axis],query.high[cone.axis]))
        if (axial[1] <= 0 or axial[0] >= back) if interior else (axial[1] < 0 or axial[0] > back): return O
        axes = tuple(k for k in range(3) if k != cone.axis)
        far = max(sum((p-c)**2 for p,c in zip(corner,(cone.tip[k] for k in axes)))
                  for corner in product(*( (query.low[k],query.high[k]) for k in axes)))
        near = sum((max(query.low[k], min(cone.tip[k],query.high[k]))-cone.tip[k])**2 for k in axes)
        upper_radius = cone.radius*min(cone.height,back,axial[1])/cone.height
        lower_radius = cone.radius*min(cone.height,max(0,axial[0]))/cone.height
        best_margin, worst_margin = upper_radius**2-near, lower_radius**2-far
        if best_margin <= 0 if interior else best_margin < 0: return O
        inside = (0 < axial[0] and axial[1] < back and worst_margin > 0) if interior else (
            0 <= axial[0] and axial[1] <= back and worst_margin >= 0)
        return I if inside else M
    if isinstance(shape, AnnularSweep):
        low,high = query.low[shape.axis],query.high[shape.axis]
        if (high <= shape.low or low >= shape.high) if interior else (high < shape.low or low > shape.high): return O
        x0,x1 = query.low[shape.travel_axis],query.high[shape.travel_axis]
        k = 3-shape.axis-shape.travel_axis
        y0,y1 = query.low[k]-shape.transverse_center,query.high[k]-shape.transverse_center
        corners = tuple(product((x0,x1),(y0,y1)))
        def outer_distance(x,y): return (x-max(shape.start,min(x,shape.end)))**2+y*y
        def endpoint_distance(x,y): return max((x-shape.start)**2,(x-shape.end)**2)+y*y
        nearest_y = max(y0,min(0,y1))
        nearest_x = max(x0,min(shape.start,x1))
        outer_min = outer_distance(nearest_x,nearest_y)
        outer_max = max(outer_distance(x,y) for x,y in corners)
        middle = (shape.start+shape.end)/2
        lens_min = endpoint_distance(max(x0,min(middle,x1)),nearest_y)
        lens_max = max(endpoint_distance(x,y) for x,y in corners)
        outer2,inner2 = shape.outer_radius**2,shape.inner_radius**2
        if interior:
            has_lens = shape.end-shape.start < 2*shape.inner_radius
            if outer_min >= outer2 or (has_lens and lens_max <= inner2): return O
            inside = shape.low < low and high < shape.high and outer_max < outer2 and (not has_lens or lens_min > inner2)
        else:
            if outer_min > outer2 or lens_max < inner2: return O
            inside = shape.low <= low and high <= shape.high and outer_max <= outer2 and lens_min >= inner2
        return I if inside else M
    if isinstance(shape, IndexedSolid):
        # Independent of the generator's interval transform: enumerate extrema
        # of the linear inverse map over all complete-box corners.
        pose = shape.pose; origin = pose.spindle.origin
        i, j = (pose.spindle.axis+1) % 3, (pose.spindle.axis+2) % 3
        points = []
        for corner in product(*zip(query.low, query.high)):
            p = list(corner); a, b = p[i]-origin[i], p[j]-origin[j]
            p[i] = origin[i]+pose.cosine*a+pose.sine*b
            p[j] = origin[j]-pose.sine*a+pose.cosine*b
            points.append(p)
        enclosure = Bounds(tuple(min(p[k] for p in points) for k in range(3)),
                           tuple(max(p[k] for p in points) for k in range(3)))
        return _arithmetic_relation(shape.base, enclosure, interior, prism_resolver)
    if isinstance(shape, Empty):
        return O
    if isinstance(shape, UnresolvedRegion):
        return M
    if isinstance(shape, Box):
        # Endpoint relation proof, with separate strictness for open interiors.
        intervals = list(zip(query.low, query.high, shape.bounds.low, shape.bounds.high))
        outside = any((hi <= a or lo >= b) if interior else (hi < a or lo > b)
                      for lo, hi, a, b in intervals)
        inside = all((a < lo and hi < b) if interior else (a <= lo and hi <= b)
                     for lo, hi, a, b in intervals)
        return O if outside else (I if inside else M)
    if isinstance(shape, Cylinder):
        axes = tuple(i for i in range(3) if i != shape.axis)
        intervals = [(query.low[k]-c, query.high[k]-c) for k, c in zip(axes, shape.center)]
        corners = product(*intervals)
        farthest = max(sum(x*x for x in p) for p in corners)
        closest = tuple(max(a, min(Fraction(), b)) for a, b in intervals)
        nearest = sum(x*x for x in closest)
        lo, hi, radius2 = query.low[shape.axis], query.high[shape.axis], shape.radius**2
        if interior:
            return O if hi <= shape.low or lo >= shape.high or nearest >= radius2 else (
                I if shape.low < lo and hi < shape.high and farthest < radius2 else M)
        return O if hi < shape.low or lo > shape.high or nearest > radius2 else (
            I if shape.low <= lo and hi <= shape.high and farthest <= radius2 else M)
    if isinstance(shape, (RoundedCylinder,RoundedAnnulus)):
        base=shape.base;axes=base.radial_axes
        inner2=shape.inner_radius**2 if type(shape) is RoundedAnnulus else 0
        farthest=max(sum((p[k]-c)**2 for k,c in zip(axes,base.center)) for p in product(*zip(query.low,query.high)))
        nearest=sum((max(query.low[k],min(c,query.high[k]))-c)**2 for k,c in zip(axes,base.center))
        def contains(radial2,gap,axially_open):
            if interior and type(shape) is RoundedAnnulus and radial2==0 and shape.allowance**2==inner2 and gap==0 and axially_open:return True
            available=shape.allowance**2-gap**2
            if available<0:return False
            if radial2<inner2:
                delta=inner2+radial2-available
                if delta<0:return True
                lhs=delta**2;rhs=4*inner2*radial2
                return lhs<rhs if interior else lhs<=rhs
            if radial2<=base.radius**2:return available>0 if interior else True
            delta=radial2-base.radius**2-available
            if delta<=0:return True
            lhs=delta**2;rhs=4*base.radius**2*available
            return lhs<rhs if interior else lhs<=rhs
        low,high=query.low[base.axis],query.high[base.axis]
        radial_near=farthest if farthest<inner2 else nearest if nearest>base.radius**2 else inner2
        if not contains(radial_near,max(base.low-high,low-base.high,0),low<base.high and high>base.low):return O
        gap=max(base.low-low,high-base.high,0)
        return I if all(contains(q,gap,base.low<low and high<base.high) for q in (nearest,farthest)) else M
    if isinstance(shape, Sphere):
        corners = product(*zip(query.low, query.high))
        farthest = max(sum((x-c)**2 for x, c in zip(p, shape.center)) for p in corners)
        closest = tuple(max(a, min(c, b)) for a, b, c in zip(query.low, query.high, shape.center))
        nearest = sum((x-c)**2 for x, c in zip(closest, shape.center))
        if interior:
            return O if nearest >= shape.radius**2 else (I if farthest < shape.radius**2 else M)
        return O if nearest > shape.radius**2 else (I if farthest <= shape.radius**2 else M)
    if isinstance(shape, Union):
        children = [_arithmetic_relation(c, query, interior, prism_resolver) for c in shape.children]
        return I if I in children else (O if all(c == O for c in children) else M)
    if isinstance(shape, Cutout):
        base = _arithmetic_relation(shape.base, query, interior, prism_resolver)
        cuts = [_arithmetic_relation(c, query, not interior, prism_resolver) for c in shape.cutters]
        return O if base == O or I in cuts else (I if base == I and all(c == O for c in cuts) else M)
    raise ValueError("Unsupported certificate predicate")


def _has_indexed(shape):
    if isinstance(shape, IndexedSolid): return True
    if isinstance(shape, Union): return any(_has_indexed(c) for c in shape.children)
    if isinstance(shape, Cutout): return _has_indexed(shape.base) or any(_has_indexed(c) for c in shape.cutters)
    return False


def _has_prism(shape):
    from .rational_prism_queries import NominalRationalPrism
    if isinstance(shape, NominalRationalPrism): return True
    if isinstance(shape, IndexedSolid): return _has_prism(shape.base)
    if isinstance(shape, Union): return any(_has_prism(c) for c in shape.children)
    if isinstance(shape, Cutout): return any(_has_prism(c) for c in (shape.base,*shape.cutters))
    return False


def _prism_key(geometry_id, query, interior):
    return identity(dict(geometry_id=geometry_id,query=query,interior=interior))


def _prism_resolver(records):
    from .rational_prism_evidence import verify_recorded_prism_query
    if type(records) is not list: raise ValueError('Rational proof list required')
    proofs={}; used=set()
    for record in records:
        if type(record) is not dict or not {'geometry_id','query','interior'} <= record.keys():
            raise ValueError('Invalid rational proof binding')
        key=_prism_key(record['geometry_id'],record['query'],record['interior'])
        if key in proofs: raise ValueError('Duplicate rational proof')
        proofs[key]=record
    if list(proofs)!=sorted(proofs): raise ValueError('Noncanonical rational proof ordering')
    def resolve(shape,query,interior):
        key=_prism_key(region_id(shape),query.to_data(),interior)
        if key not in proofs: raise ValueError('Missing rational prism proof')
        if key not in used:
            verify_recorded_prism_query(proofs[key],shape,query,interior=interior)
            used.add(key)
        return Relation(proofs[key]['relation'])
    def complete():
        if used!=set(proofs): raise ValueError('Unused rational prism proof')
    return resolve,complete


def _finite_tool_features(shape):
    from .drill_geometry import ConicalPoint, DrillCutting
    from .face_geometry import AnnularSweep
    if isinstance(shape, (ConicalPoint,DrillCutting)): return {'continuous_conical_radial_profile'}
    if isinstance(shape, AnnularSweep): return {'finite_annular_translation_with_endpoint_lens'}
    if isinstance(shape, IndexedSolid): return _finite_tool_features(shape.base)
    if isinstance(shape, Union): return set().union(*(_finite_tool_features(c) for c in shape.children))
    if isinstance(shape, Cutout): return set().union(*(_finite_tool_features(c) for c in (shape.base,*shape.cutters)))
    return set()


def _predicate_assumptions(shape):
    profile = (["rigid_indexed_analytic_sources", "inverse_query_axis_aligned_enclosure"]
               if _has_indexed(shape) else ["principal_axis_analytic_sources"])
    rational=["positive_weight_regular_grid_prism", "independent_recorded_control_cover"] if _has_prism(shape) else []
    return ["exact_rational_inputs", *profile, *sorted(_finite_tool_features(shape)), *rational, "closed_query_box"]


def predicate_version(shape):
    if _has_prism(shape): return 'exact-rational-prism-composite-1'
    if _finite_tool_features(shape): return 'exact-finite-tool-analytic-1'
    if _has_indexed(shape): return 'exact-indexed-analytic-1'
    if has_rounded_annulus(shape):return 'exact-analytic-4'
    if has_rounded_cylinder(shape):return 'exact-analytic-3'
    return "exact-analytic-2" if has_sphere(shape) else "exact-analytic-1"


def predicate_certificate(shape, query, *, interior=False):
    result = {"schema": "adaptive-predicate-certificate-1", "predicate_version": predicate_version(shape),
            "source_id": region_id(shape), "query": query.to_data(), "interior": interior,
            "relation": shape.classify(query, interior=interior).value,
            "grade": "bounded" if supported(shape) else "unresolved",
            "assumptions": _predicate_assumptions(shape)}
    if _has_prism(shape):
        from .rational_prism_queries import prism_cell_query
        records={}
        def collect(prism,box,mode):
            key=_prism_key(region_id(prism),box.to_data(),mode)
            if key not in records: records[key]=prism_cell_query(prism,box,interior=mode)
            return Relation(records[key]['relation'])
        relation=_arithmetic_relation(shape,query,interior,collect)
        if relation.value!=result['relation']: raise ValueError('Rational certificate differs from production relation')
        result.update(schema='adaptive-predicate-certificate-2',prism_queries=[records[k] for k in sorted(records)])
    return result


def verify_predicate_certificate(certificate, shape):
    rational=_has_prism(shape)
    fields(certificate, ("schema", "predicate_version", "source_id", "query", "interior", "relation", "grade", "assumptions")+(('prism_queries',) if rational else ()))
    schema='adaptive-predicate-certificate-2' if rational else 'adaptive-predicate-certificate-1'
    if certificate["schema"] != schema or certificate["predicate_version"] != predicate_version(shape):
        raise ValueError("Unsupported predicate certificate")
    if type(certificate["interior"]) is not bool or certificate["source_id"] != region_id(shape):
        raise ValueError("Certificate operand binding mismatch")
    query = Bounds.from_data(certificate["query"])
    resolve,complete=_prism_resolver(certificate['prism_queries']) if rational else (None,lambda:None)
    relation = _arithmetic_relation(shape, query, certificate["interior"],resolve)
    complete()
    expected_grade = "bounded" if supported(shape) else "unresolved"
    if certificate["relation"] != relation.value or certificate["grade"] != expected_grade:
        raise ValueError("Certificate arithmetic or grade mismatch")
    if certificate["assumptions"] != _predicate_assumptions(shape):
        raise ValueError("Certificate assumptions differ")
    return True


def cell_certificate(source, address):
    if address.domain_geometry_id != source.geometry_id:
        raise ValueError("Wrong source domain")
    query = source.root.cell(address)
    leaf = AnalyticClassifier(source).classify(address)
    record = {"schema": "adaptive-cell-certificate-1", "address": address.to_data(),
              "policy_id": identity(source.policy.to_data()), "leaf": leaf.to_data(),
              "predicates": {key: predicate_certificate(getattr(source, key), query)
                             for key in ("stock", "target", "protected")}}
    return record


def verify_cell_certificate(certificate, source):
    fields(certificate, ("schema", "address", "policy_id", "leaf", "predicates"))
    if certificate["schema"] != "adaptive-cell-certificate-1" or certificate["policy_id"] != identity(source.policy.to_data()):
        raise ValueError("Cell certificate schema/policy mismatch")
    address = CellAddress(**certificate["address"])
    if address.domain_geometry_id != source.geometry_id:
        raise ValueError("Wrong certificate domain")
    query = source.root.cell(address)
    fields(certificate["predicates"], ("stock", "target", "protected"))
    relations = {}
    for key, predicate in certificate["predicates"].items():
        if predicate["query"] != query.to_data() or predicate["interior"]:
            raise ValueError("Cell predicate queried another region")
        verify_predicate_certificate(predicate, getattr(source, key))
        relations[key] = Relation(predicate["relation"])
    # Independently derive the two set differences, including the explicit
    # shared-source Cutout implication used by the reference builder.
    def difference(other, relation, predicate):
        s = relations["stock"]
        if region_id(source.stock) == region_id(other) or s == O or relation == I:
            return False, False
        if isinstance(other, Cutout) and region_id(other.base) == region_id(source.stock):
            resolver=_prism_resolver(predicate['prism_queries'])[0] if _has_prism(other) else None
            cuts = _arithmetic_relation(Union(other.cutters), query, True,resolver)
            return s == I and cuts == I, s != O and cuts != O
        return s == I and relation == O, s != O and relation != I
    dl, du = difference(source.target, relations["target"],certificate['predicates']['target'])
    el, eu = difference(source.protected, relations["protected"],certificate['predicates']['protected'])
    expected = {"address": address.to_data(), **{k:v.value for k, v in relations.items()},
                "delta_lower": dl, "delta_upper": du, "eligible_lower": el, "eligible_upper": eu}
    if certificate["leaf"] != expected:
        raise ValueError("Cell set-bound proof mismatch")
    return True
