"""Independent saved-record checks; imports no simulator or study controller."""
from datetime import datetime
from fractions import Fraction
from hashlib import sha256
import json
import math

POLICIES = ('deterministic', 'random', 'greedy', 'model', 'model_mcts')
OBJECTIVE = 'shadow-gym-bounded-fixed-axis-core-roughing-v4'
CLAIM = 'stock_size_interpolation_in_previously_exposed_rounded_family'
GATES = ['complete_roster', 'no_execution_exceptions', 'fixed_weights',
         'reference_completion', 'model_completion', 'model_mcts_completion', 'exact_replay']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def logical_hash(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def rational(value):
    require(type(value) is list and len(value) == 2 and all(type(x) is int for x in value)
            and value[1] > 0, 'Invalid rational record')
    return Fraction(*value)


def roster(task_ids):
    require(len(task_ids) == len(set(task_ids)) == 9, 'Nine unique task identities required')
    return [dict(task_id=t, policy=p, seed=27001+i, epoch=None)
            for i, t in enumerate(task_ids) for p in POLICIES]


def aggregate(task_ids, rows, replay_passed):
    require(type(replay_passed) is bool, 'Explicit replay state required')
    require(len(rows) == 45, 'Incomplete episode denominator')
    for row, expected in zip(rows, roster(task_ids)):
        require(row['roster'] == expected, 'Episode roster changed')
        require(row['status'] in ('executed', 'error'), 'Unknown execution status')
        if row['status'] == 'error':
            require(type(row.get('error')) is str and bool(row['error']), 'Missing error detail')
            require(all(row.get(k) is None for k in ('steps', 'return_value', 'terminated', 'truncated')),
                    'Invented error metrics')
        else:
            require(type(row['steps']) is int and 1 <= row['steps'] <= 8, 'Invalid step count')
            require(finite(row['return_value']), 'Invalid return')
            require(type(row['terminated']) is bool and type(row['truncated']) is bool
                    and row['terminated'] != row['truncated'], 'Invalid terminal flags')
            require(row['learn'] is False and row['weights_unchanged'] is True, 'Weights changed or learning enabled')
    metrics = []
    for policy in POLICIES:
        valid = [r for r in rows if r['roster']['policy'] == policy and r['status'] == 'executed']
        metrics.append(dict(policy=policy, planned=9, executed=len(valid), errors=9-len(valid),
            completed=sum(r['terminated'] for r in valid), truncated=sum(r['truncated'] for r in valid),
            mean_return=sum(r['return_value'] for r in valid)/len(valid) if valid else None,
            mean_steps=sum(r['steps'] for r in valid)/len(valid) if valid else None))
    by = {m['policy']: m for m in metrics}
    values = [True, not any(m['errors'] for m in metrics), True,
              by['deterministic']['completed'] == 9,
              by['model']['completed'] >= by['deterministic']['completed'],
              by['model_mcts']['completed'] >= by['deterministic']['completed'], replay_passed]
    gates = [dict(id=g, status='Passed' if v else 'Failed') for g, v in zip(GATES, values)]
    pairs = []
    for t in task_ids:
        group = {r['roster']['policy']: r for r in rows if r['roster']['task_id'] == t}
        for p in ('model', 'model_mcts'):
            a, b = group[p], group['deterministic']
            valid = a['status'] == b['status'] == 'executed'
            pairs.append(dict(task_id=t, policy=p, comparable=valid,
                return_difference=a['return_value']-b['return_value'] if valid else None,
                action_difference=a['steps']-b['steps'] if valid else None))
    return dict(metrics=metrics, paired=pairs, gates=gates,
                technical_profile_outcome='Passed' if all(values) else 'NotQualified')


def check_episode(record, row, weights, task):
    require(record['schema'] == 'adaptive-bounded-mill-turn-training-episode-1', 'Wrong episode schema')
    require(type(record['steps']) is int and finite(record['return_value'])
            and type(record['terminated']) is bool and type(record['truncated']) is bool,
            'Invalid episode metric types')
    for key in ('roster', 'steps', 'return_value', 'terminated', 'truncated', 'learn'):
        require(record[key] == row[key], 'Episode/index disagreement: '+key)
    require(record['task_id'] == row['roster']['task_id'] and record['split'] == 'test'
            and record['family'] == task['family'], 'Episode task changed')
    expected = weights if row['roster']['policy'] in ('model', 'model_mcts') else None
    require(all(v is None or (type(v) is list and all(finite(x) for x in v))
                for v in (record['start_weights'], record['end_weights'])), 'Invalid episode weight types')
    require(record['start_weights'] == record['end_weights'] == expected, 'Episode weights changed')
    require(finite(record['epsilon']) and record['epsilon'] == 0 and record['learn'] is False, 'Evaluation training enabled')
    observations, decisions, trajectory = (record[k] for k in ('observations', 'decisions', 'trajectory'))
    require(len(decisions) == len(trajectory) == row['steps'] and len(observations) == row['steps']+1,
            'Episode trace length differs')
    for obs in observations:
        count = len(obs['mask'])
        require(1 <= count <= 505 and len(obs['candidates']) == count and len(obs['global']) == 4,
                'Observation shape differs')
        require(all(type(x) is int and x in (0, 1) for x in obs['mask']), 'Invalid mask')
        require(all(len(v) == 50 and all(finite(x) and -1 <= x <= 1 for x in v)
                    for v in obs['candidates']) and all(finite(x) and -1 <= x <= 1 for x in obs['global']),
                'Invalid feature values')
    total = 0.0
    for i, (obs, decision, transition) in enumerate(zip(observations, decisions, trajectory)):
        action = decision['action']
        require(type(action) is int and 0 <= action < len(obs['mask']) and obs['mask'][action] == 1,
                'Masked or invalid chosen action')
        require(type(transition['action']) is int and type(transition['step']) is int
                and transition['action'] == action and transition['step'] == i+1
                and transition['task_id'] == record['task_id'], 'Transition/action binding differs')
        require(all(transition[k] == record[k] for k in ('catalog_id', 'feature_contract_id', 'turning_axis_id')),
                'Transition context changed')
        components = transition['reward_components']
        require(set(components) == {'new_eligible_credit', 'attempt_cost', 'reach_cost', 'rejection_cost', 'tool_change_cost'},
                'Unknown reward components')
        reward = rational(components['new_eligible_credit']) - sum(
            rational(v) for k, v in components.items() if k != 'new_eligible_credit')
        require(finite(transition['reward']) and transition['reward'] == float(reward), 'Reward arithmetic differs')
        total += transition['reward']
        last = i == len(trajectory)-1
        require(transition['terminated'] is (row['terminated'] if last else False)
                and transition['truncated'] is (row['truncated'] if last else False), 'Premature/changed terminal flags')
        if i:
            prior = trajectory[i-1]
            require(transition['before_planning_state'] == prior['after_planning_state']
                    and transition['result']['before_hash'] == prior['result']['after_hash'], 'State chain broken')
    require(total == row['return_value'], 'Return does not equal trajectory rewards')
    end = trajectory[-1]; info = record['final_info']
    require(record['final_state_hash'] == end['result']['after_hash'] == info['state_hash']
            and record['final_planning_state'] == end['after_planning_state'] == info['planning_state_id']
            and info['task_id'] == record['task_id'] and info['transition'] == end, 'Final state binding differs')
    low, high = (rational(info['remaining'][k]) for k in ('lower_mm3', 'upper_mm3'))
    require(0 <= low <= high, 'Invalid remaining volume interval')
    satisfied, required = info['critical_obligations_satisfied'], info['critical_obligations_total']
    require(type(satisfied) is int and type(required) is int and 0 <= satisfied <= required
            and required == len(task['cores']), 'Invalid core obligation counts')
    complete = high <= rational(task['residual_budget_mm3']) and satisfied == required
    require(row['terminated'] == complete and (not row['truncated'] or row['steps'] == task['horizon']),
            'Completion/horizon differs from declared task')
    return dict(initial_observation_sha256=sha256(encoded(observations[0])).hexdigest(),
                initial_material=trajectory[0]['result']['before_hash'],
                initial_planning_state=trajectory[0]['before_planning_state'])


def evaluate(read):
    """read returns already authenticated ZIP member bytes; no code is imported."""
    data = lambda name: json.loads(read(name))
    protocol = data('plan/protocol.json'); tasks = data('plan/tasks.json')
    freeze = data('plan/freeze.json'); launch = data('run/launch.json')
    checkpoint_raw = read('plan/checkpoint.json'); checkpoint = json.loads(checkpoint_raw)
    pin = sha256(checkpoint_raw).hexdigest()
    require(protocol['schema'] == 'adaptive-v4-stock-confirmation-protocol-1'
            and protocol['acceptance'] == 'original_completion_rule_plus_exact_replay'
            and protocol['claim'] == CLAIM and protocol['model_fitting'] is False
            and protocol['family_disjoint'] is False, 'Unsupported frozen protocol')
    require(freeze['policy_outcomes_observed'] is False
            and launch['freeze_sha256'] == sha256(read('plan/freeze.json')).hexdigest()
            and protocol['checkpoint_sha256'] == launch['checkpoint_sha256'] == pin, 'Freeze/checkpoint binding differs')
    stamps = [datetime.fromisoformat(v['observed_at']) for v in (freeze, launch)]
    require(all(s.tzinfo is not None and s.utcoffset() is not None for s in stamps)
            and stamps[0] <= stamps[1], 'Launch predates freeze')
    require(all(v.get('runtime_activation') is False and v.get('canonical_model_admission') is False
                for v in (freeze, launch, protocol)), 'Unexpected authority')
    require(len(checkpoint['weights']) == 54 and all(finite(x) for x in checkpoint['weights']), 'Invalid weights')
    task_ids = [logical_hash(t) for t in tasks]
    require(task_ids == [r['task_id'] for r in protocol['tasks']]
            and protocol['roster'] == roster(task_ids), 'Task/roster identity changed')
    old = data('plan/old-family-evidence.json')['tasks']
    for key in ('task_id', 'source_geometry_id'):
        fresh = [t[key] for t in protocol['tasks']]; prior = [t[key] for t in old]
        require(len(set(fresh)) == 9 and len(set(prior)) == 27 and not set(fresh)&set(prior), 'Prior task/source overlap')
    rows = data('run/episode-index.json'); replays = data('run/replay-index.json')
    preliminary = aggregate(task_ids, rows, len(replays) == 45)
    expected_replays = []; cases = []; starts = {}; action_count = 0
    for i, row in enumerate(rows):
        if row['status'] == 'error':
            require(bool(read(f'run/episodes/{i:03d}.error.txt')), 'Error details absent')
            cases.append(dict(roster=row['roster'], status='error', error=row['error']))
            continue
        require(row['path'] == f'episodes/{i:03d}.json', 'Episode path/order differs')
        raw = read('run/'+row['path']); require(sha256(raw).hexdigest() == row['sha256'], 'Episode pin differs')
        initial = check_episode(json.loads(raw), row, checkpoint['weights'], tasks[i//5])
        task_id = row['roster']['task_id']
        require(task_id not in starts or starts[task_id] == initial, 'Policies did not share initial state and masks')
        starts[task_id] = initial; action_count += row['steps']
        expected_replays.append(dict(path=row['path'], sha256=row['sha256'], status='passed'))
        cases.append(dict(roster=row['roster'], status='executed', path=row['path'], sha256=row['sha256'],
                          steps=row['steps'], return_value=row['return_value'], terminated=row['terminated'], truncated=row['truncated']))
    require(replays == expected_replays, 'Replay coverage or binding differs')
    source = data('run/result.json')
    for key in ('metrics', 'paired', 'technical_profile_outcome'):
        require(source[key] == preliminary[key], 'Producer aggregate differs: '+key)
    require(source['exact_replay_passed'] is (len(replays) == 45) and source['checkpoint_sha256'] == pin
            and source['planned_episodes'] == 45 and source['coverage'] == protocol['tasks'], 'Result identity/coverage differs')
    for flag in ('canonical_model_admission', 'runtime_activation', 'manufacturing_qualified', 'evidence_case_sealed',
                 'superiority_claim', 'statistical_replication', 'family_disjoint_confirmation'):
        require(source[flag] is False, 'Unsupported result claim')
    return dict(**preliminary, cases=cases, checkpoint_sha256=pin, coverage=protocol['tasks'],
                checked_actions=action_count, exact_replay_rows=len(replays), same_initial_conditions=len(starts),
                frozen_at=freeze['observed_at'], launched_at=launch['observed_at'])


def reference(raw, schema, role):
    return dict(sha256=sha256(raw).hexdigest(), size=len(raw), media_type='application/json',
                schema=schema, role=role, classification='Internal')


def lifecycle_records(read, verified, archive_sha256):
    """Produce review subjects. No positive admission or trusted receipt is made."""
    source = {name: dict(archive_sha256=archive_sha256, member=name,
                        sha256=sha256(read(name)).hexdigest(), size=len(read(name)))
              for name in ('plan/freeze.json', 'plan/protocol.json', 'plan/CONTRACT.md', 'plan/tasks.json',
                           'plan/original-producer.json', 'run/index.json', 'run/result.json', 'run/replay-index.json')}
    disabled = dict(canonical_model_admission=False, runtime_activation=False,
                    manufacturing_qualified=False, evidence_case_sealed=False)
    limitations = ['Previously exposed rounded-bottom target family; nine designed stock instances only.',
        'No unfamiliar-family or industrial qualification, population interval, or repeated-training claim.',
        'Completion gates do not establish learned-policy superiority; retain every reference comparison.',
        'Replay receipts record the original producer replay, not independent geometric verification.',
        'No profile/dataset admission, trusted verification, selection, content clearance or package approval is supplied.']
    profile = dict(schema='task-evaluation-profile-1', objective_id=OBJECTIVE, claim_scope=CLAIM,
        frozen_before_outcomes=True, adapter_created_after_outcomes=True,
        freeze_statement='Only original protocol/contract/roster semantics were frozen before outcomes; this schema mapping was created later.',
        frozen_sources={k: v for k, v in source.items() if k.startswith('plan/')},
        locked_checkpoint_sha256=verified['checkpoint_sha256'], candidate_checkpoints=[verified['checkpoint_sha256']],
        selection_rule='Confirm the single previously locked epoch-36 checkpoint; no selection among test-exposed candidates.',
        nomination_lineage='Original validation epoch12/24/36 nomination and its full candidate set remain separate external evidence.',
        mandatory_gates=GATES, horizon=8, planned_episodes=45,
        metrics=dict(population='All nine designed stock tasks, separately for each of five policies.',
            completion=dict(unit='tasks', direction='higher', aggregation='count/planned9'),
            return_value=dict(unit='dimensionless frozen reward', direction='higher', aggregation='mean over executed including truncations'),
            actions=dict(unit='integer actions', direction='lower', aggregation='mean over executed including truncations'),
            pairs='Candidate minus deterministic reference on the same task; equal values stay zero.',
            missingness='Errors remain in planned denominator, with no invented return or action count.',
            uncertainty='Descriptive designed cases; no population confidence interval.',
            calibration='Inapplicable: nonprobabilistic action-value output.',
            multiplicity='One fixed checkpoint; two fixed inference policies, no test-based model selection or threshold tuning.'),
        limitations=limitations, **disabled)
    dataset = dict(schema='task-dataset-1', objective_id=OBJECTIVE, claim_scope=CLAIM,
        task_count=9, tasks=verified['coverage'], partition='prospective_stock_instance_confirmation',
        family_disjoint=False, prior_target_exposure=True, source=source['plan/tasks.json'],
        admission_status='Pending', **disabled)
    profile_raw, dataset_raw = encoded(profile), encoded(dataset)
    dispositions = [
        ('EVAL-001', 'Frozen protocol/contract predates launch; schema mapping is post-outcome and requires review.'),
        ('EVAL-002', 'Metrics, denominator, ties, missingness and uncertainty follow the frozen contract; calibration inapplicable.'),
        ('EVAL-003', 'Nine identical tasks and initial observations/masks verified across policies; actual dataset admission pending.'),
        ('EVAL-004', 'Saved episodes show fixed weights, zero exploration epsilon and no learning; original replay retained.'),
        ('EVAL-005', 'All45 roster entries and per-policy failures/truncations retained, with radius/axis coverage.'),
        ('EVAL-006', 'Frozen completion gates recomputed; independent record checks passed. No broader scientific qualification issued.'),
        ('EVAL-007', 'Reference leads return/action metrics. No learned-policy superiority claim.'),
        ('EVAL-008', 'Previously exposed target family and old pilot disclosed; no unfamiliar-family confirmation claim.'),
        ('EVAL-009', 'Every episode binds exact task and bytes; private Internal records, independent content review pending.'),
        ('EVAL-010', 'Runtime activation remains false regardless of outcome.')]
    report = dict(schema='task-evaluation-report-1', objective_id=OBJECTIVE, claim_scope=CLAIM,
        profile_sha256=sha256(profile_raw).hexdigest(), dataset_sha256=sha256(dataset_raw).hexdigest(),
        checkpoint_sha256=verified['checkpoint_sha256'], outcome='Blocked',
        technical_profile_outcome=verified['technical_profile_outcome'], gates=verified['gates'],
        blocking_requirements=['actual_profile_admission', 'actual_dataset_admission', 'trusted_independent_evaluation_verification'],
        evidence=source, metrics=verified['metrics'], paired=verified['paired'], cases=verified['cases'],
        checked_actions=verified['checked_actions'], exact_replay_rows=verified['exact_replay_rows'],
        same_initial_conditions=verified['same_initial_conditions'], evaluation_code_executed=False,
        simulation_replayed=False, independent_geometry_oracle=False,
        eval_dispositions=[dict(id=k, disposition=v) for k, v in dispositions], limitations=limitations, **disabled)
    return {'profile': profile_raw, 'dataset': dataset_raw, 'evaluation': encoded(report)}
