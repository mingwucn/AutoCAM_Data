"""Fixed-machine turning point shadows bound to saved identity-frame sessions."""
from .domain import fields, identity
from .stationary_turning_shadow import StationaryTurningShadowView
from .turning_point_shadow import TurningPointShadowView


def stationary_turning_shadow_response(browser, request):
    fields(request, ('operation', 'session_epoch', 'expected_semantic_id', 'candidate_id'))
    if request['operation'] != 'stationary_turning_shadow_view':
        raise ValueError('Stationary turning shadow operation required')
    with browser.initial._lock:
        if type(request['session_epoch']) is not int or request['session_epoch'] != browser.epoch:
            raise ValueError('Stale stationary turning shadow session epoch')
        if request['expected_semantic_id'] != browser.semantic_id:
            raise ValueError('Stale stationary turning shadow semantic state')
        if browser.suffix is not None:
            raise ValueError('Stationary turning shadow requires the initial turning phase')
        candidate = next((c for c in browser.initial.candidates if c.id == request['candidate_id']), None)
        if candidate is None or candidate.kind != 'turn':
            raise ValueError('Saved turning candidate required for stationary shadow inspection')
        journal, motion = browser.initial._journal, candidate.motion
        if not journal._context.matches(motion):
            raise ValueError('Stationary turning shadow candidate differs from mounted context')
        machine = journal._machine
        pose = machine.select(journal._pose)
        if machine.spindle != motion.spindle_axis or pose.spindle != motion.spindle_axis:
            raise ValueError('Stationary turning shadow machine spindle mismatch')
        if pose.cosine != 1 or pose.sine != 0:
            raise ValueError('Stationary turning shadow requires an identity setup frame')
        rotating = TurningPointShadowView(journal.material, motion.spindle_axis,
            motion.mode, motion.facing_sign, journal._fixture, browser.semantic_id)
        projection = StationaryTurningShadowView(rotating, motion.radial_axis,
            motion.radial_sign, journal._stationary).to_data()
        return dict(schema='adaptive-full-mill-turn-stationary-turning-shadow-1',
            session_epoch=browser.epoch, configuration_id=browser.config_id,
            candidate_id=candidate.id, candidate=candidate.to_data(),
            observation=browser.observe(), projection=projection,
            context=dict(journal_head=journal.head, mounted_context=journal._context.to_data(),
                machine=machine.to_data(), orientation_id=journal._pose,
                part_to_machine=pose.to_data(), frame_profile='identity_zero_spindle_phase_1',
                rotating_fixture_id=identity(journal._fixture.to_data()),
                stationary_obstacles=journal._stationary.to_data(),
                stationary_obstacles_id=identity(journal._stationary.to_data())))
