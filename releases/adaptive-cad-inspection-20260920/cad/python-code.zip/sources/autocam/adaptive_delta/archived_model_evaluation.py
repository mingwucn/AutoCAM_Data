"""Reconstruct the frozen v4 pilot evaluation; no selection authority or training."""
from collections import Counter
import math


def require(ok, message):
    if not ok:
        raise ValueError(message)


def evaluate(records):
    recipe, episodes, checkpoints, selection, weights, metrics, qualification, run, replay, package = (
        records[k] for k in ('recipe','episodes','checkpoints','selection','checkpoint',
                            'metrics','qualification','run','replay','package'))
    require(package['kind']=='PackageCandidate' and package['package_approval'] is None
            and all(package[k] is False for k in ('canonical_model_admission','runtime_activation',
                                                  'manufacturing_qualified')), 'Unexpected package authority')
    require(recipe['schema']=='adaptive-bounded-mill-turn-td-recipe-1'
            and recipe['planned_episode_count']==162 and recipe['episodes']==36
            and recipe['checkpoint_epochs']==[12,24,36]
            and recipe['heldout_previously_used_for_semantic_tests'] is True
            and recipe['test_access']=='after_checkpoint_selection_only', 'Frozen protocol mismatch')
    criterion='maximum_validation_completions_then_mean_return_then_earliest_checkpoint'
    require(selection['schema']=='adaptive-bounded-mill-turn-training-selection-1'
            and qualification['schema']=='adaptive-bounded-mill-turn-pilot-qualification-1'
            and qualification['scope']=='frozen_synthetic_core_roughing_pilot', 'Evaluation scope mismatch')
    require(recipe['selection']==criterion and selection['criterion']==criterion
            and selection['test_observed'] is False and selection['canonical_model_admission'] is False,
            'Selection criterion or chronology mismatch')
    require(len(episodes)==162 and [r['path'] for r in episodes]==
            [f'episodes/episode-{i:04d}.json' for i in range(162)], 'Episode roster mismatch')
    member_rows=package['members']; members={r['path']:r for r in member_rows}
    require(len(members)==len(member_rows), 'Duplicate package member')
    tasks={}; families={'through':'train','blind':'validation','rounded':'test'}
    for row in episodes:
        require(row['family'] in families and row['split']==families[row['family']], 'Family split mismatch')
        require(row['task_id'] not in tasks or tasks[row['task_id']]==(row['family'],row['split']),
                'Task split leakage')
        tasks[row['task_id']]=(row['family'],row['split'])
        require(type(row['steps']) is int and 0<row['steps']<=8, 'Invalid episode steps')
        require(type(row['return_value']) in (float,int) and math.isfinite(row['return_value']),
                'Nonfinite episode return')
        require(type(row['terminated']) is bool and type(row['truncated']) is bool
                and row['terminated'] != row['truncated'], 'Invalid terminal flags')
        require(type(row['learn']) is bool and row['learn']==(row['policy']=='td_train'), 'Invalid learning flag')
        require('evidence/'+row['path'] in members and
                members['evidence/'+row['path']]['sha256']==row['sha256'], 'Episode member identity mismatch')
    require(Counter(v[1] for v in tasks.values())=={'train':9,'validation':9,'test':9}, 'Task denominator mismatch')
    # Derive task order from the first complete baseline roster and first test block.
    non_test=[r['task_id'] for r in episodes[:18]]
    train=[t for t in non_test if tasks[t][1]=='train']
    valid=[t for t in non_test if tasks[t][1]=='validation']
    test=[episodes[117+i*5]['task_id'] for i in range(9)]
    require(len(set(non_test))==18 and len(train)==len(valid)==9 and len(set(test))==9
            and all(tasks[t][1]=='test' for t in test), 'Frozen task ordering mismatch')
    expected=[]
    for policy in ('deterministic','random','greedy'):
        expected.extend((t,policy,None) for t in non_test)
    for epoch in range(1,37):
        expected.append((train[(epoch-1)%9],'td_train',epoch))
        if epoch in (12,24,36):
            expected.extend((t,'validation_model',epoch) for t in valid)
    for task in test:
        expected.extend((task,p,None) for p in ('deterministic','random','greedy','model','model_mcts'))
    require([(r['task_id'],r['policy'],r['epoch']) for r in episodes]==expected, 'Policy/epoch roster mismatch')
    aggregates=[]
    for split,policy in sorted({(r['split'],r['policy']) for r in episodes}):
        group=[r for r in episodes if (r['split'],r['policy'])==(split,policy)]
        aggregates.append(dict(split=split,policy=policy,denominator=len(group),
            completed=sum(r['terminated'] for r in group),truncated=sum(r['truncated'] for r in group),
            mean_return=sum(r['return_value'] for r in group)/len(group),
            mean_steps=sum(r['steps'] for r in group)/len(group)))
    require(aggregates==metrics, 'Aggregate metrics mismatch')
    require([c['epoch'] for c in checkpoints]==[12,24,36], 'Checkpoint roster mismatch')
    for c in checkpoints:
        group=[r for r in episodes if r['policy']=='validation_model' and r['epoch']==c['epoch']]
        require(c['validation_episodes']==[r['path'] for r in group]
                and c['validation_completions']==sum(r['terminated'] for r in group)
                and c['validation_mean_return']==sum(r['return_value'] for r in group)/9,
                'Checkpoint validation mismatch')
        require(c['checkpoint_path']==f"checkpoints/checkpoint-{c['epoch']}.json"
                and members['evidence/'+c['checkpoint_path']]['sha256']==c['checkpoint_sha256'],
                'Checkpoint member identity mismatch')
    nominated=max(checkpoints,key=lambda c:(c['validation_completions'],c['validation_mean_return'],-c['epoch']))
    require(all(selection[k]==nominated[k] for k in ('epoch','checkpoint_path','checkpoint_sha256'))
            and members['checkpoint.json']['sha256']==selection['checkpoint_sha256'], 'Selected checkpoint mismatch')
    require(weights['schema']=='adaptive-linear-q-checkpoint-4' and weights['features']==54
            and len(weights['weights'])==54 and all(type(w) in (float,int) and math.isfinite(w)
                                                    for w in weights['weights']), 'Invalid checkpoint weights')
    require(weights['feature_contract_id']==selection['feature_contract_id']==package['feature_contract_id']
            and selection['catalog_id']==package['catalog_id'], 'Feature/catalog identity mismatch')
    heldout=[r for r in aggregates if r['split']=='test']; by_policy={r['policy']:r for r in heldout}
    gate=any(weights['weights']) and by_policy['deterministic']['completed']==9 and all(
        by_policy[p]['completed']>=by_policy['deterministic']['completed'] for p in ('model','model_mcts'))
    require(qualification['heldout_metrics']==heldout and qualification['status']==('passed' if gate else 'not_qualified')
            and qualification['learned_weights_nonzero'] is any(weights['weights'])
            and qualification['reference_completed_all_nine'] is (by_policy['deterministic']['completed']==9)
            and qualification['heldout_completion_at_least_deterministic'] is all(
                by_policy[p]['completed']>=by_policy['deterministic']['completed'] for p in ('model','model_mcts')),
            'Pilot qualification mismatch')
    require(all(qualification[k] is False for k in ('canonical_model_admission','runtime_activation','manufacturing_qualified')),
            'Unexpected qualification authority')
    require(run['status']=='passed' and run['regression_test_count']==154
            and run['canonical_model_admission'] is False and run['runtime_activation'] is False
            and run['qualified'] is gate and replay['status']=='passed'
            and replay['original_producer_without_recovery_adapter'] is True, 'Retained execution evidence mismatch')
    validation=records['validation']; integrity=validation['run_integrity']
    require(validation['status']=='passed' and validation['isolated_stdlib_process'] is True
            and validation['relocation_passed'] is True and validation['consumer_vectors']==2
            and validation['manifest_sha256']=='f42a2bda6b4a5b6b4846cd21474c704673d372b5c0480a3d37bbcd1033de04c5'
            and validation['canonical_model_admission'] is False and validation['runtime_activation'] is False
            and integrity['status']=='passed' and integrity['retained_producer_replay_verified'] is True
            and integrity['episodes']==162 and integrity['selected_epoch']==selection['epoch']
            and integrity['qualified_pilot'] is gate
            and integrity['feature_contract_id']==package['feature_contract_id']
            and integrity['catalog_id']==package['catalog_id'], 'Retained portable validation mismatch')
    for summary in (run['execution'],run['replay'],replay['result']):
        require(summary['episodes']==162 and summary['training_episodes']==36
                and summary['transitions']==sum(r['steps'] for r in episodes)
                and summary['selected_epoch']==selection['epoch']
                and summary['catalog_id']==package['catalog_id']
                and summary['feature_contract_id']==package['feature_contract_id'], 'Run denominator/identity mismatch')
    reference=by_policy['deterministic']
    comparison=[dict(policy=p,mean_return_delta=by_policy[p]['mean_return']-reference['mean_return'],
                     mean_action_delta=by_policy[p]['mean_steps']-reference['mean_steps']) for p in ('model','model_mcts')]
    return dict(schema='adaptive-archived-v4-evaluation-1',technical_status='verified_retained_index_evaluation',
        pilot_gate='passed' if gate else 'not_qualified',canonical_qualification='Blocked',
        automated_nomination=dict(epoch=nominated['epoch'],checkpoint_sha256=nominated['checkpoint_sha256'],
            criterion=criterion,human_selection_decision=None),candidate_checkpoints=checkpoints,
        episodes=162,learning_episodes=36,transitions=sum(r['steps'] for r in episodes),
        metrics=aggregates,heldout_comparison=comparison,
        per_test_episode=[dict(r) for r in episodes if r['split']=='test'],
        metric_semantics=dict(population='All episodes in each declared split/policy; held-out is nine rounded-family tasks.',
            return_unit='Task-defined dimensionless cumulative reward',action_unit='Count per episode',
            aggregation='Sequential binary64 sum in recorded episode order divided by complete denominator.',
            direction='Higher completion and return; lower action count.',missingness='Missing/duplicate/invalid evidence rejects; truncations remain.',
            ties=criterion,uncertainty='Descriptive finite-cohort observations only; no confidence interval, independent replication or generalization claim.'),
        prior_semantic_exposure=True,new_geometric_or_training_replay=False,
        eval_requirements={f'EVAL-{i:03d}':status for i,status in enumerate((
            'pilot_chronology_retained_external_protection_unproved','descriptive_metrics_no_canonical_profile',
            'same_task_roster_retained_dataset_admission_pending','frozen_selection_and_retained_unchanged_weight_checks',
            'all_denominators_and_failures_retained','pilot_gate_only_canonical_gates_unadmitted',
            'no_superiority_claim','prior_semantic_exposure_disclosed','per_episode_identity_bound_content_review_pending',
            'runtime_activation_false'),1)},
        blockers=['task_specific_canonical_evaluation_profile_unadmitted','canonical_dataset_admission_missing',
                  'attributable_canonical_selection_missing','final_package_approval_missing','independent_content_review_missing'],
        canonical_model_admission=False,runtime_activation=False,manufacturing_qualified=False,full_plan_complete=False)
