"""Bounded closed-cell queries on the certified nominal rational face patches."""
from collections import deque
from fractions import Fraction as Q

from .domain import Bounds, identity, qdata
from .rational_patch import RationalPatch, _split


POLICY = 'positive-weight-corner-witness-cover-63-depth8-v1'
MAXIMUM_NODES = 63
MAXIMUM_DEPTH = 8


def _children(net, axis):
    if axis == 1:
        pairs = [_split(row, Q(1, 2)) for row in net]
        return tuple(tuple(pair[side] for pair in pairs) for side in (0, 1))
    columns = [_split(tuple(row[j] for row in net), Q(1, 2))
               for j in range(len(net[0]))]
    return tuple(tuple(tuple(column[side][i] for column in columns)
                       for i in range(len(net))) for side in (0, 1))


def query_patch(patch, cell):
    """A witnessed hit or a complete disjoint cover; otherwise keep a candidate."""
    if type(patch) is not RationalPatch or type(cell) is not Bounds:
        raise ValueError('Typed rational face and exact cell required')
    queue = deque([(patch.homogeneous, (Q(0), Q(0)), (Q(1), Q(1)), 0)])
    visited = depth_limited = 0
    while queue and visited < MAXIMUM_NODES:
        net, low, high, depth = queue.popleft()
        visited += 1
        points = [tuple(v / p[3] for v in p[:3]) for row in net for p in row]
        if any(max(p[k] for p in points) < cell.low[k]
               or min(p[k] for p in points) > cell.high[k] for k in range(3)):
            continue
        for i, j in ((0, 0), (0, -1), (-1, 0), (-1, -1)):
            p = net[i][j]
            xyz = tuple(v / p[3] for v in p[:3])
            if all(a <= v <= b for a, v, b in zip(cell.low, xyz, cell.high)):
                return dict(relation='INTERSECTS', visited_nodes=visited,
                            reason='exact_patch_point_in_closed_cell',
                            witness=dict(uv=[qdata(low[0] if i == 0 else high[0]),
                                             qdata(low[1] if j == 0 else high[1])],
                                         xyz=[qdata(v) for v in xyz]))
        if depth == MAXIMUM_DEPTH:
            depth_limited += 1
            continue
        axis = depth % 2
        midpoint = (low[axis] + high[axis]) / 2
        for side, child in enumerate(_children(net, axis)):
            a, b = list(low), list(high)
            if side == 0:
                b[axis] = midpoint
            else:
                a[axis] = midpoint
            queue.append((child, tuple(a), tuple(b), depth + 1))
    unresolved = bool(queue or depth_limited)
    return dict(relation='UNRESOLVED' if unresolved else 'DISJOINT',
                visited_nodes=visited,
                reason=('node_budget' if queue else 'depth_or_contact_unresolved')
                       if unresolved else 'complete_strict_disjoint_cover', witness=None)


def query_faces(prepared, cell, certificate_sha256, metadata):
    tests = []
    for index, patch in prepared:
        tests.append(dict(source_face_index=index, source_face_id=identity(dict(
            certificate_sha256=certificate_sha256, source_face_index=index)),
            **query_patch(patch, cell)))
    faces = [{k: row[k] for k in ('source_face_index', 'source_face_id', 'relation')}
             for row in tests if row['relation'] != 'DISJOINT']
    return dict(schema='adaptive-cad-cell-faces-2', certificate_sha256=certificate_sha256,
                **metadata, frame='original_part', cell=cell.to_data(),
                relation='closed_cell_nominal_face_candidates', query_policy=POLICY,
                face_tests=tests, faces=faces, access_assessed=False,
                machining_task_generated=False)
