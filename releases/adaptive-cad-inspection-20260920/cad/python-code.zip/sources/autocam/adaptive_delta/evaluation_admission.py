"""Qualify an exact evaluated scope only after trusted prerequisite decisions."""
from . import model_finalization as p

INPUT_ROLES = frozenset(('profile', 'dataset', 'evaluation', 'profile_admission',
                        'dataset_admission', 'evaluation_verification'))
BLOCKERS = ('actual_profile_admission', 'actual_dataset_admission',
            'trusted_independent_evaluation_verification')
FLAGS = ('canonical_model_admission', 'runtime_activation', 'manufacturing_qualified', 'evidence_case_sealed')


@p.admission_boundary
def qualify(records, store, trusted):
    """Return a new report; never create trust, change inputs or select a model."""
    p.require(type(records) is dict and set(records) == INPUT_ROLES, 'Exact qualification inputs required')
    profile = p.document(records['profile'], store, role='profile', schema='task-evaluation-profile-1')
    dataset = p.document(records['dataset'], store, role='dataset', schema='task-dataset-1')
    report = p.document(records['evaluation'], store, role='evaluation', schema='task-evaluation-report-1')
    p.require(report.get('outcome') == 'Blocked' and report.get('technical_profile_outcome') == 'Passed',
              'Original evaluation is not technically eligible')
    p.require(report.get('blocking_requirements') == list(BLOCKERS), 'Unresolved or changed prerequisite list')
    p.require('qualification_basis' not in report, 'Original evaluation already has qualification basis')
    p.require(all(value.get(flag) is False for value in (profile, dataset, report) for flag in FLAGS),
              'Evaluation input asserts authority')
    for key in ('objective_id', 'claim_scope'):
        p.require(type(profile.get(key)) is str and bool(profile[key].strip())
                  and report.get(key) == dataset.get(key) == profile[key], 'Evaluation objective/scope mismatch')
    p.require(profile.get('frozen_before_outcomes') is True, 'Unfrozen evaluation profile')
    p.require(report.get('profile_sha256') == records['profile']['sha256']
              and report.get('dataset_sha256') == records['dataset']['sha256']
              and report.get('checkpoint_sha256') == profile.get('locked_checkpoint_sha256'),
              'Evaluation subject binding mismatch')
    checkpoint = report.get('checkpoint_sha256')
    p.require(type(checkpoint) is str and len(checkpoint) == 64
              and all(c in '0123456789abcdef' for c in checkpoint), 'Invalid checkpoint identity')
    gates = profile.get('mandatory_gates')
    p.require(type(gates) is list and bool(gates) and all(type(g) is str and bool(g.strip()) for g in gates)
              and len(set(gates)) == len(gates), 'Invalid mandatory gates')
    p.require(report.get('gates') == [dict(id=g, status='Passed') for g in gates], 'Evaluation gate failed/missing')
    for role, scope, decision, subject in (
        ('profile_admission', 'evaluation_profile', 'Admitted', 'profile'),
        ('dataset_admission', 'dataset', 'Admitted', 'dataset'),
        ('evaluation_verification', 'evaluation_verification', 'Verified', 'evaluation')):
        details = p.receipt(records[role], store, trusted, role=role, scope=scope,
                            decision=decision, subject=records[subject]['sha256'])
        if role == 'evaluation_verification':
            p.require(details.get('profile_sha256') == records['profile']['sha256']
                      and details.get('dataset_sha256') == records['dataset']['sha256']
                      and details.get('checkpoint_sha256') == checkpoint, 'Verification details bind another study')
    # Detached JSON objects ensure no in-memory source or caller store is mutated.
    report.update(outcome='Qualified', blocking_requirements=[],
                  qualification_basis=dict(schema='task-evaluation-qualification-basis-1', records=records))
    return p.encode(report)


@p.admission_boundary
def verify(qualified_ref, store, trusted):
    """Rebuild exact bytes; a successful check is not an attributable receipt."""
    report = p.document(qualified_ref, store, role='evaluation', schema='task-evaluation-report-1')
    basis = report.get('qualification_basis')
    p.require(type(basis) is dict and set(basis) == {'schema', 'records'}
              and basis['schema'] == 'task-evaluation-qualification-basis-1', 'Invalid qualification basis')
    expected = qualify(basis['records'], store, trusted)
    p.require(expected == p.resolve(qualified_ref, store), 'Qualified report differs from verified derivation')
    return dict(schema='task-evaluation-admission-check-1', status='Passed',
        evaluation_sha256=qualified_ref['sha256'], original_evaluation_sha256=basis['records']['evaluation']['sha256'],
        attributable_receipt=False, **{flag: False for flag in FLAGS})
