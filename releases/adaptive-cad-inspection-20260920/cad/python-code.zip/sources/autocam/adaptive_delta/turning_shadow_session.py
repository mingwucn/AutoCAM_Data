"""Read-only turning occlusion bound to a full session's saved candidate."""
from .domain import fields, identity
from .geometry import Empty, Union
from .turning_point_shadow import TurningPointShadowView


def _structurally_empty(shape):
    return type(shape) is Empty or (type(shape) is Union and
                                   all(_structurally_empty(c) for c in shape.children))


def turning_shadow_response(browser, request):
    fields(request, ('operation', 'session_epoch', 'expected_semantic_id', 'candidate_id'))
    with browser.initial._lock:
        if type(request['session_epoch']) is not int or request['session_epoch'] != browser.epoch:
            raise ValueError('Stale turning shadow session epoch')
        if request['expected_semantic_id'] != browser.semantic_id:
            raise ValueError('Stale turning shadow semantic state')
        if browser.suffix is not None:
            raise ValueError('Turning shadow requires the initial turning phase')
        candidate = next((c for c in browser.initial.candidates if c.id == request['candidate_id']), None)
        if candidate is None or candidate.kind != 'turn':
            raise ValueError('Saved turning candidate required for shadow inspection')
        journal = browser.initial._journal
        if not journal._context.matches(candidate.motion):
            raise ValueError('Turning shadow candidate differs from mounted context')
        if not _structurally_empty(journal._stationary):
            raise ValueError('Turning shadow requires structurally empty stationary obstacles')
        motion = candidate.motion
        projection = TurningPointShadowView(journal.material, motion.spindle_axis,
            motion.mode, motion.facing_sign, journal._fixture, browser.semantic_id).to_data()
        return dict(schema='adaptive-full-mill-turn-turning-shadow-1',
            session_epoch=browser.epoch, configuration_id=browser.config_id,
            candidate_id=candidate.id, candidate=candidate.to_data(),
            observation=browser.observe(), projection=projection,
            context=dict(journal_head=journal.head, mounted_context=journal._context.to_data(),
                machine=journal._machine.to_data(), orientation_id=journal._pose,
                rotating_fixture_id=identity(journal._fixture.to_data()),
                stationary_obstacles=journal._stationary.to_data(),
                stationary_obstacles_id=identity(journal._stationary.to_data()),
                stationary_input_profile='structurally_empty_1'))
