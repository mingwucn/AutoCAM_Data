"""Task-scoped immutable package assembly, gated by caller-trusted exact records.

This module authenticates content and authority references; it creates no owner
decisions, scientific evidence, trust anchors, runtime activation or model code.
"""
from datetime import datetime
from functools import wraps
from hashlib import sha256
import json
from pathlib import PurePosixPath
import re

ROLES=('payload','model_definition','compatibility','profile','dataset','evaluation',
       'profile_admission','dataset_admission','evaluation_verification','selection',
       'consumer_validation','content_review','training_run','negative_evidence')
REFERENCE_FIELDS={'sha256','size','media_type','schema','role','classification'}


class AdmissionError(ValueError):pass


def require(value,message):
    if not value:raise AdmissionError(message)


def admission_boundary(operation):
    @wraps(operation)
    def checked(*args,**kwargs):
        try:return operation(*args,**kwargs)
        except AdmissionError:raise
        except (KeyError,IndexError,TypeError,ValueError,AttributeError) as error:
            raise AdmissionError('Malformed lifecycle input: '+str(error)) from error
    return checked


def encode(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(raw):return sha256(raw).hexdigest()


def reference(raw,*,schema,role,media_type='application/json',classification='Internal'):
    return dict(sha256=digest(raw),size=len(raw),media_type=media_type,schema=schema,role=role,classification=classification)


def resolve(ref,store,*,role=None):
    require(type(ref) is dict and set(ref)==REFERENCE_FIELDS,'Invalid reference fields')
    require(type(ref['sha256']) is str and re.fullmatch('[0-9a-f]{64}',ref['sha256']) is not None,'Invalid content hash')
    require(type(ref['size']) is int and ref['size']>=0,'Invalid content size')
    require(all(type(ref[k]) is str and bool(ref[k]) for k in ('media_type','schema','role')),'Incomplete reference metadata')
    require(ref['classification'] in ('Public','Internal','Restricted'),'Unknown classification')
    require(role is None or ref['role']==role,'Reference role mismatch')
    require(ref['sha256'] in store,'Unresolved exact reference')
    raw=store[ref['sha256']]
    require(type(raw) is bytes and len(raw)==ref['size'] and digest(raw)==ref['sha256'],'Referenced content changed')
    return raw


def document(ref,store,*,role=None,schema=None):
    raw=resolve(ref,store,role=role)
    require(ref['media_type']=='application/json','Expected JSON document')
    try:value=json.loads(raw)
    except (ValueError,UnicodeError) as error:raise AdmissionError('Invalid document JSON') from error
    require(type(value) is dict and value.get('schema')==ref['schema'],'Document schema/reference mismatch')
    require(schema is None or value['schema']==schema,'Unsupported document schema')
    return value


def receipt(ref,store,trusted,*,role,scope,decision,subject):
    resolve(ref,store,role=role)
    require(type(trusted) is frozenset and ref['sha256'] in trusted,'Untrusted decision or verification receipt')
    row=document(ref,store,role=role,schema='task-attributable-record-1')
    require(all(type(row.get(k)) is str and bool(row[k].strip()) for k in ('actor','authority','provenance')),
            'Missing attribution')
    require(row.get('scope')==scope and row.get('decision')==decision and row.get('subject_sha256')==subject,
            'Decision scope, outcome or subject mismatch')
    require(row.get('runtime_activation') is False,'Receipt grants activation')
    try:stamp=datetime.fromisoformat(row['decided_at'])
    except (KeyError,TypeError,ValueError) as error:raise AdmissionError('Invalid decision timestamp') from error
    require(stamp.tzinfo is not None and stamp.utcoffset() is not None,'Decision timestamp lacks timezone')
    require(type(row.get('details')) is dict,'Receipt details missing')
    return row['details']


def check_inputs(records,store,trusted,objective_id,claim_scope):
    require(type(records) is dict and set(records)==set(ROLES),'Mandatory lifecycle references missing or unknown')
    values={role:document(ref,store,role=role) for role,ref in records.items()}
    payload=values['payload'];require(payload['schema']=='task-consumer-payload-1','Unsupported payload schema')
    members=payload.get('members');require(type(members) is list and bool(members),'Empty consumer payload')
    names=set();member_roles=[];checkpoint=None;features=None
    for row in members:
        name=row.get('path');require(type(name) is str and bool(name),'Invalid payload path')
        path=PurePosixPath(name)
        require(bool(path.parts) and not path.is_absolute() and path.as_posix()==name and '..' not in path.parts
                and '\\' not in name and ':' not in name and '\x00' not in name and name.casefold() not in names,'Unsafe/duplicate payload path')
        names.add(name.casefold());ref=row['reference'];resolve(ref,store)
        require(ref['classification']!='Restricted','Restricted embedded content')
        member_roles.append(ref['role'])
        if ref['role']=='checkpoint':checkpoint=ref['sha256']
        if ref['role']=='features':features=ref['sha256']
    require(all(member_roles.count(r)==1 for r in ('checkpoint','features','model_card','consumer_vectors')),
            'Mandatory consumer member roles missing or duplicated')
    definition=values['model_definition'];compatibility=values['compatibility']
    require(definition['schema']=='task-model-definition-1' and compatibility['schema']=='task-model-compatibility-1',
            'Unsupported definition/compatibility schema')
    require(not set(definition)&{'checkpoint','checkpoint_sha256','dataset','split','training_result','runtime_activation'},
            'Model definition contains lifecycle state')
    require(definition.get('objective_id')==objective_id and definition.get('features_sha256')==features,
            'Model definition objective/features mismatch')
    require(compatibility.get('definition_sha256')==records['model_definition']['sha256']
            and compatibility.get('checkpoint_sha256')==checkpoint and compatibility.get('features_sha256')==features,
            'Model/adapter/parameter identity mismatch')
    require(compatibility.get('status')=='Compatible','Incompatible adapter')
    profile=values['profile'];dataset=values['dataset'];evaluation=values['evaluation']
    require(profile['schema']=='task-evaluation-profile-1' and dataset['schema']=='task-dataset-1'
            and evaluation['schema']=='task-evaluation-report-1','Unsupported evaluation lifecycle schema')
    require(profile.get('objective_id')==objective_id and profile.get('claim_scope')==claim_scope
            and profile.get('frozen_before_outcomes') is True,'Evaluation objective/scope/freeze mismatch')
    gates=profile.get('mandatory_gates')
    require(type(gates) is list and bool(gates) and all(type(g) is str and bool(g) for g in gates)
            and len(set(gates))==len(gates),'Invalid mandatory gate set')
    require(profile.get('locked_checkpoint_sha256')==checkpoint,'Checkpoint differs from frozen nomination')
    candidates=profile.get('candidate_checkpoints')
    require(type(candidates) is list and all(type(c) is str and re.fullmatch('[0-9a-f]{64}',c) for c in candidates)
            and checkpoint in candidates and len(set(candidates))==len(candidates),
            'Candidate set missing or ambiguous')
    rule=profile.get('selection_rule');require(type(rule) is str and bool(rule),'Missing predeclared selection rule')
    require(evaluation.get('outcome')=='Qualified' and evaluation.get('runtime_activation') is False,
            'Evaluation not Qualified or grants activation')
    require(evaluation.get('profile_sha256')==records['profile']['sha256']
            and evaluation.get('dataset_sha256')==records['dataset']['sha256']
            and evaluation.get('checkpoint_sha256')==checkpoint and evaluation.get('claim_scope')==claim_scope,
            'Evaluation identity/scope mismatch')
    require(evaluation.get('gates')==[dict(id=g,status='Passed') for g in gates],'Mandatory evaluation gate failed/missing')
    specs=(('profile_admission','evaluation_profile','Admitted','profile'),
           ('dataset_admission','dataset','Admitted','dataset'),
           ('evaluation_verification','evaluation_verification','Verified','evaluation'))
    for role,scope,decision,subject in specs:
        receipt(records[role],store,trusted,role=role,scope=scope,decision=decision,subject=records[subject]['sha256'])
    selected=receipt(records['selection'],store,trusted,role='selection',scope='model_selection',decision='Selected',subject=checkpoint)
    require(selected.get('evaluation_sha256')==records['evaluation']['sha256']
            and selected.get('candidate_checkpoints')==candidates and selected.get('selection_rule')==rule,
            'Selection evidence, candidates or rule mismatch')
    validation=receipt(records['consumer_validation'],store,trusted,role='consumer_validation',
        scope='consumer_validation',decision='Passed',subject=records['payload']['sha256'])
    require(validation.get('definition_sha256')==records['model_definition']['sha256']
            and validation.get('compatibility_sha256')==records['compatibility']['sha256'],'Consumer validation scope mismatch')
    closure=digest(encode({k:records[k]['sha256'] for k in ('payload','model_definition','compatibility')}))
    review=receipt(records['content_review'],store,trusted,role='content_review',scope='content_review',decision='Cleared',subject=closure)
    require(review.get('restricted_content_present') is False and review.get('secrets_present') is False,
            'Content review did not clear complete consumer closure')
    require(values['training_run']['schema']=='task-training-run-reference-1'
            and values['negative_evidence']['schema']=='task-negative-evidence-reference-1','Missing retained run/negative evidence')
    require(checkpoint in values['training_run'].get('checkpoint_sha256s',[]),'Training run does not bind checkpoint')
    resolve(values['training_run'].get('run_reference'),store,role='training_run_evidence')
    lineage=values['training_run'].get('lineage')
    require(type(lineage) is dict and {'recipe','producer','environment'}<=set(lineage),'Recipe/environment lineage missing')
    for role in ('recipe','producer','environment'):resolve(lineage[role],store,role=role)
    require(compatibility.get('environment_sha256')==lineage['environment']['sha256'],'Adapter environment identity mismatch')
    negatives=values['negative_evidence'].get('references')
    require(type(negatives) is list and bool(negatives),'Negative evidence closure missing')
    for ref in negatives:resolve(ref,store,role='negative_run_evidence')


@admission_boundary
def prepare_subject(records,store,trusted,*,objective_id,claim_scope,limitations,prohibited_uses):
    require(all(type(v) is str and bool(v.strip()) for v in (objective_id,claim_scope)),'Objective/claim scope missing')
    for value in (limitations,prohibited_uses):
        require(type(value) is list and bool(value) and all(type(v) is str and bool(v.strip()) for v in value),
                'Prominent limitations/prohibited uses missing')
    check_inputs(records,store,trusted,objective_id,claim_scope)
    return encode(dict(schema='task-model-package-subject-1',version='1.0.0',records=records,
        objective_id=objective_id,claim_scope=claim_scope,limitations=limitations,prohibited_uses=prohibited_uses,
        runtime_activation=False,manufacturing_qualified=False))


@admission_boundary
def finalize(subject_ref,approval_ref,store,trusted):
    subject=document(subject_ref,store,role='package_subject',schema='task-model-package-subject-1')
    expected=prepare_subject(subject['records'],store,trusted,objective_id=subject['objective_id'],
        claim_scope=subject['claim_scope'],limitations=subject['limitations'],prohibited_uses=subject['prohibited_uses'])
    require(expected==resolve(subject_ref,store),'Subject fields, version or authority changed')
    receipt(approval_ref,store,trusted,role='package_approval',scope='model_package',decision='Approved',subject=subject_ref['sha256'])
    return encode(dict(schema='task-model-package-1',version='1.0.0',kind='ModelPackage',
        subject=subject_ref,approval=approval_ref,runtime_activation=False,manufacturing_qualified=False))


@admission_boundary
def load(package_raw,expected_sha256,store,trusted):
    require(type(package_raw) is bytes and digest(package_raw)==expected_sha256,'Package pin mismatch')
    package=json.loads(package_raw)
    require(package.get('schema')=='task-model-package-1','Unsupported package schema')
    require(package_raw==finalize(package['subject'],package['approval'],store,trusted),'Package envelope changed')
    return document(package['subject'],store,role='package_subject')
