"""Immutable principal linear tool paths and their geometric construction."""
from dataclasses import dataclass
from .domain import fields, integer, qdata, qread, rational, triple
from .machining_values import MillingTool, AxialPlunge, SideMill
from .milling_geometry import milling_pose_geometry, plunge_geometry, side_geometry


@dataclass(frozen=True, slots=True)
class LinearToolPath:
    tool_axis: int
    tool_sign: int
    start_tip: tuple
    end_tip: tuple

    def __post_init__(self):
        integer(self.tool_axis, 'tool axis', 0, 2)
        if type(self.tool_sign) is not int or self.tool_sign not in (-1,1): raise ValueError('Signed tool axis required')
        object.__setattr__(self, 'start_tip', triple(self.start_tip))
        object.__setattr__(self, 'end_tip', triple(self.end_tip))
        if len([k for k in range(3) if self.start_tip[k] != self.end_tip[k]]) != 1:
            raise ValueError('Exactly one nonzero principal translation required; sampled/general paths unsupported')

    @property
    def travel_axis(self): return next(k for k in range(3) if self.start_tip[k] != self.end_tip[k])

    def tip(self, t):
        t = rational(t)
        if not 0 <= t <= 1: raise ValueError('Path time outside closed unit interval')
        return tuple(a+t*(b-a) for a,b in zip(self.start_tip,self.end_tip))

    def to_data(self):
        return dict(schema='adaptive-linear-tool-path-1', tool_axis=self.tool_axis, tool_sign=self.tool_sign,
                    start_tip=[qdata(v) for v in self.start_tip], end_tip=[qdata(v) for v in self.end_tip])

    @classmethod
    def from_data(cls, data):
        fields(data, ('schema','tool_axis','tool_sign','start_tip','end_tip'))
        if data['schema'] != 'adaptive-linear-tool-path-1': raise ValueError('Unsupported linear path')
        return cls(data['tool_axis'], data['tool_sign'], tuple(qread(v) for v in data['start_tip']), tuple(qread(v) for v in data['end_tip']))

    def geometry(self, tool, a=0, b=1):
        if type(tool) is not MillingTool: raise ValueError('Existing exact milling assembly required')
        a, b = rational(a), rational(b)
        if not 0 <= a <= b <= 1: raise ValueError('Ordered closed subinterval required')
        first, last = self.tip(a), self.tip(b)
        if a == b: return milling_pose_geometry(tool, self.tool_axis, self.tool_sign, first)
        if self.travel_axis == self.tool_axis:
            if (last[self.tool_axis]-first[self.tool_axis])*self.tool_sign < 0: first,last = last,first
            return plunge_geometry(tool, AxialPlunge(self.tool_axis, self.tool_sign, first, last))
        travel_sign = 1 if last[self.travel_axis] > first[self.travel_axis] else -1
        return side_geometry(tool, SideMill(self.tool_axis, self.tool_sign, self.travel_axis, travel_sign, first, last))


