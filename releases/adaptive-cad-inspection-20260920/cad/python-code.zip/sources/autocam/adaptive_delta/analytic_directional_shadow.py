"""Exact closed point-ray shadows for axis-aligned analytic blockers."""
from dataclasses import dataclass

from .directional_shadow_view import DirectionalShadowView, REASONS
from .domain import Bounds, digest, integer
from .geometry import Box, Cylinder, Empty, Sphere, Union
from .transitions import MaterialState

PROFILE = 'closed_analytic_axis_point_shadow_1'


def _primitives(shape):
    if type(shape) is Empty:
        return ()
    if type(shape) in (Box, Cylinder, Sphere):
        return (shape,)
    if type(shape) is Union:
        return tuple(item for child in shape.children for item in _primitives(child))
    raise ValueError('Analytic point-shadow requires Box, Cylinder, Sphere, Empty or Union blockers')


def _extrude(shape, axis, sign, exterior):
    end = exterior.high[axis] if sign == 1 else exterior.low[axis]
    if type(shape) is Cylinder and shape.axis == axis:
        return Cylinder(axis, shape.center, shape.radius,
                        shape.low if sign == 1 else end,
                        end if sign == 1 else shape.high)
    if type(shape) is Sphere:
        center = tuple(shape.center[k] for k in range(3) if k != axis)
        start = shape.center[axis]
        extension = Cylinder(axis, center, shape.radius, min(start, end), max(start, end))
        return Union((shape, extension))
    low, high = list(shape.bounds.low), list(shape.bounds.high)
    if type(shape) is Cylinder:
        start = shape.center[shape.radial_axes.index(axis)]
        if sign == 1:
            low[axis] = start
        else:
            high[axis] = start
    if sign == 1:
        high[axis] = end
    else:
        low[axis] = end
    extension = Box(Bounds(tuple(low), tuple(high)))
    return Union((shape, extension)) if type(shape) is Cylinder else extension


@dataclass(frozen=True, slots=True)
class AnalyticDirectionalShadowView(DirectionalShadowView):
    def __post_init__(self):
        if type(self.state) is not MaterialState:
            raise ValueError('Typed accepted material required')
        integer(self.axis, 'part-frame direction axis', 0, 2)
        integer(self.sign, 'part-frame travel sign', -1, 1)
        if self.sign == 0:
            raise ValueError('Nonzero direction required')
        digest(self.semantic_id)
        exterior = self.exterior
        for shape in (self.state.domain.source.protected, self.fixture):
            for primitive in _primitives(shape):
                bounds = primitive.bounds
                if any(bounds.low[k] <= exterior.low[k] or
                       bounds.high[k] >= exterior.high[k] for k in range(3)):
                    raise ValueError('Blockers must lie strictly within the declared exterior')

    def shadow(self, reason='combined'):
        if reason not in REASONS:
            raise ValueError('Unknown point-shadow reason')
        protected = self.state.domain.source.protected
        obstacles = (protected, self.fixture) if reason == 'combined' else (
            protected if reason == 'protected' else self.fixture,)
        return Union(tuple(_extrude(shape, self.axis, self.sign, self.exterior)
                           for obstacle in obstacles for shape in _primitives(obstacle)))

    def to_data(self):
        payload = DirectionalShadowView.to_data(self)
        payload['predicate_version'] = PROFILE
        return payload
