"""Read-only exact drill length sets, independent of preparation and acceptance."""
from dataclasses import dataclass

from .domain import Bounds, Relation, canonical, digest, identity, qdata, qread
from .drill_geometry import drill_sweep_geometry
from .drill_motion import DrillEntry
from .drill_operation import DrillOperation
from .drill_tools import DrillTool
from .geometry import Cutout, IndexedSolid
from .hole_requirements import verify_hole_requirement
from .indexed_frames import IndexedOrientation
from .tool_catalog import AxialPlunge
from .transitions import MaterialState

REASONS = ('usable_reach', 'active_length')


@dataclass(frozen=True, slots=True)
class DrillLengthView:
    state: MaterialState
    tool_id: str
    operation: DrillOperation
    pose: IndexedOrientation
    semantic_id: str

    def __post_init__(self):
        if (type(self.state) is not MaterialState or type(self.operation) is not DrillOperation
                or type(self.pose) is not IndexedOrientation):
            raise ValueError('Typed accepted material, drill operation and index required')
        digest(self.semantic_id)
        if self.state.tool_catalog is None: raise ValueError('Accepted tool catalog required')
        tool = self.state.tool_catalog.select(self.tool_id)
        if type(tool) is not DrillTool: raise ValueError('Finite drill assembly required')
        op = self.operation; pose = self.pose
        if pose.spindle != self.state.turning_axis or pose.id != op.orientation_id:
            raise ValueError('Drill diagnostic orientation differs')
        verify_hole_requirement(self.state.domain.source, op.requirement)
        if DrillEntry.from_data(op.requirement.to_data()['entry']) != op.entry:
            raise ValueError('Drill diagnostic entry differs from source requirement')
        direction = tuple(op.entry.sign if k == op.entry.axis else 0 for k in range(3))
        world = tuple(op.world_motion.sign if k == op.world_motion.axis else 0 for k in range(3))
        if pose.vector(direction) != world: raise ValueError('Drill diagnostic axis differs')
        entry = pose.point(op.entry.point); motion = op.world_motion
        depth = qread(op.depth.resolve(tool)['derived_tip_depth'])
        if motion.end_tip != tuple(v+d*depth for v, d in zip(entry, world)):
            raise ValueError('Drill diagnostic final gauge differs')
        if (any(motion.start_tip[k] != entry[k] for k in range(3) if k != motion.axis)
                or motion.sign*(motion.start_tip[motion.axis]-entry[motion.axis]) >= 0):
            raise ValueError('Drill diagnostic start must precede the source entry')

    @property
    def tool(self): return self.state.tool_catalog.select(self.tool_id)

    @property
    def requested_depth(self): return qread(self.operation.depth.resolve(self.tool)['derived_tip_depth'])

    def limit(self, reason):
        if reason not in REASONS: raise ValueError('Unknown drill length reason')
        return self.tool.usable_reach if reason == 'usable_reach' else self.tool.point_height+self.tool.active_length

    def sweep(self, depth):
        op = self.operation; entry = self.pose.point(op.entry.point); motion = op.world_motion
        end = tuple(v+(motion.sign*depth if k == motion.axis else 0) for k, v in enumerate(entry))
        prefix = AxialPlunge(motion.axis, motion.sign, motion.start_tip, end)
        return IndexedSolid(drill_sweep_geometry(self.tool, prefix)['cutting'], self.pose.inverse())

    def classify(self, query, reason):
        if type(query) is not Bounds: raise ValueError('Exact positive-volume cell bounds required')
        limit = self.limit(reason)
        if self.requested_depth <= limit: return Relation.OUTSIDE
        source = self.state.domain.source
        remaining = Cutout(source.stock, self.state.envelopes).classify(query)
        requested = self.sweep(self.requested_depth).classify(query, interior=True)
        protected = source.protected.classify(query)
        prefix = self.sweep(limit).classify(query)
        if (Relation.OUTSIDE in (remaining, requested)
                or Relation.INSIDE in (protected, prefix)):
            return Relation.OUTSIDE
        if (remaining == requested == Relation.INSIDE
                and protected == prefix == Relation.OUTSIDE):
            return Relation.INSIDE
        return Relation.MIXED

    def to_data(self):
        source = self.state.domain.source
        return dict(schema='adaptive-drill-length-view-1', projection_only=True,
            operation_authorized=False, source_geometry_id=source.geometry_id,
            material_hash=self.state.logical_hash, semantic_id=self.semantic_id,
            assembly_hash=self.tool.id, assembly=self.tool.to_data(), catalog_id=self.state.tool_catalog.id,
            operation_id=identity(self.operation.to_data()), operation=self.operation.to_data(),
            part_to_machine=self.pose.to_data(), requested_tip_depth=qdata(self.requested_depth),
            remaining_stock=Cutout(source.stock, self.state.envelopes).to_data(),
            protected=source.protected.to_data(), requested_sweep=self.sweep(self.requested_depth).to_data(),
            reasons={reason:dict(tip_limit=qdata(self.limit(reason)),
                empty=self.requested_depth <= self.limit(reason),
                prefix_sweep=self.sweep(min(self.requested_depth, self.limit(reason))).to_data()) for reason in REASONS},
            set_semantics='closed_current_stock_intersect_open_requested_minus_closed_protected_and_prefix',
            shadow_status='NOT_ASSESSED', machine_motion_status='NOT_ASSESSED')

    def verify(self, payload):
        if canonical(payload) != canonical(self.to_data()):
            raise ValueError('Drill length projection differs from current inputs')
        return identity(payload)
