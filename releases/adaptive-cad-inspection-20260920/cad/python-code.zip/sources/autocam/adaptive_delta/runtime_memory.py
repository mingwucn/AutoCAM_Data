"""Platform memory observation shared by runtime adapters and the operator CLI."""
from pathlib import Path
import ctypes
import sys


def memory_observation():
    if sys.platform != "win32":
        try:
            values = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
            return {"available_bytes": int(values["MemAvailable"].split()[0])*1024,
                    "total_bytes": int(values["MemTotal"].split()[0])*1024}
        except (OSError, KeyError):
            return {"available_bytes": None, "total_bytes": None}
    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)]+[(n, ctypes.c_ulonglong) for n in
                    ("total", "available", "page_total", "page_available", "virtual_total", "virtual_available", "extended")]
    status = MemoryStatus(); status.length = ctypes.sizeof(status)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        raise OSError("Cannot observe physical memory")
    return {"available_bytes": status.available, "total_bytes": status.total}
