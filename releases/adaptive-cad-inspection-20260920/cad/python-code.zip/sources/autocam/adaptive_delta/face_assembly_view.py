"""Read-only face-plan component sweeps; never a motion or material authority."""
from dataclasses import dataclass

from .domain import Bounds, Relation, canonical, digest, integer, identity, qread
from .face_geometry import face_linear_geometry
from .face_operation import FaceOperation
from .face_requirements import verify_face_requirement
from .face_tools import FaceMillTool
from .geometry import Cutout, IndexedSolid, supported
from .indexed_frames import IndexedOrientation
from .transitions import MaterialState

COMPONENTS = ('cutting', 'body', 'arbor', 'holder')


@dataclass(frozen=True, slots=True)
class FaceAssemblyView:
    state: MaterialState
    tool_id: str
    operation: FaceOperation
    pose: IndexedOrientation
    fixed_geometry: object
    semantic_id: str

    def __post_init__(self):
        if (type(self.state) is not MaterialState or type(self.operation) is not FaceOperation
                or type(self.pose) is not IndexedOrientation):
            raise ValueError('Typed accepted material, face operation and pose required')
        digest(self.semantic_id)
        if not supported(self.fixed_geometry): raise ValueError('Supported declared fixed geometry required')
        if self.state.tool_catalog is None or type(self.tool) is not FaceMillTool:
            raise ValueError('Accepted physical face-mill assembly required')
        if self.pose.spindle != self.state.turning_axis or self.pose.id != self.operation.orientation_id:
            raise ValueError('Face view orientation differs')
        verify_face_requirement(self.state.domain.source, self.operation.requirement)
        req = self.operation.requirement.to_data(); axis, sign = req['axis'], req['sign']
        expected = self.pose.vector(tuple(sign if k == axis else 0 for k in range(3)))
        inverse = self.pose.inverse()
        for motion in self.operation.plan.passes:
            direction = tuple(motion.sign if k == motion.axis else 0 for k in range(3))
            if expected != direction: raise ValueError('Face view direction differs from source')
            if any(inverse.point(p)[axis] != qread(req['floor']) for p in (motion.entry, motion.exit)):
                raise ValueError('Face view gauge differs from required floor')

    @property
    def tool(self): return self.state.tool_catalog.select(self.tool_id)

    @property
    def segments(self):
        rows = []
        for lane, (motion, connections) in enumerate(zip(self.operation.plan.passes, self.operation.plan.connections)):
            rows.extend((lane, 'connection', i, path) for i, path in enumerate(connections))
            rows.extend((lane, phase, None, path) for phase, path in zip(('descent', 'lateral', 'retract'), motion.paths))
        return tuple(rows)

    def components(self, segment, *, frame='part'):
        integer(segment, 'face view segment', 0, len(self.segments)-1)
        if frame not in ('part', 'machine'): raise ValueError('Explicit part or machine frame required')
        shapes = face_linear_geometry(self.tool, self.segments[segment][3])
        return shapes if frame == 'machine' else {name: IndexedSolid(shape, self.pose.inverse()) for name, shape in shapes.items()}

    def classify_fixed(self, query, segment, component):
        if type(query) is not Bounds: raise ValueError('Exact positive-volume query bounds required')
        if component not in COMPONENTS: raise ValueError('Unknown face assembly component')
        region = self.components(segment)[component]
        fixed = IndexedSolid(self.fixed_geometry, self.pose.inverse())
        a, b = region.classify(query), fixed.classify(query)
        if Relation.OUTSIDE in (a, b): return Relation.OUTSIDE
        return Relation.INSIDE if a == b == Relation.INSIDE else Relation.MIXED

    def to_data(self):
        source = self.state.domain.source
        rows = []
        for index, (lane, phase, connection, path) in enumerate(self.segments):
            rows.append(dict(index=index, lane=lane, phase=phase, connection_index=connection,
                path_machine=path.to_data(),
                components_machine={k: v.to_data() for k, v in self.components(index, frame='machine').items()},
                components_part={k: v.to_data() for k, v in self.components(index).items()}))
        return dict(schema='adaptive-face-assembly-view-1', projection_only=True, operation_authorized=False,
            scope='lane_plan_only_excludes_parked_approach_exchange_and_index',
            source_geometry_id=source.geometry_id, material_hash=self.state.logical_hash,
            semantic_id=self.semantic_id, catalog_id=self.state.tool_catalog.id,
            assembly=self.tool.to_data(), assembly_hash=self.tool.id,
            operation=self.operation.to_data(), operation_id=identity(self.operation.to_data()),
            part_to_machine=self.pose.to_data(), fixed_machine=self.fixed_geometry.to_data(),
            fixed_geometry_id=identity(self.fixed_geometry.to_data()),
            fixed_part=IndexedSolid(self.fixed_geometry, self.pose.inverse()).to_data(),
            remaining_stock=Cutout(source.stock, self.state.envelopes).to_data(),
            protected=source.protected.to_data(), segments=rows,
            query_semantics='closed_component_sweep_intersect_closed_fixed_geometry_in_part_frame',
            stock_clearance_status='NOT_ASSESSED', machine_motion_status='NOT_ASSESSED',
            shadow_status='NOT_ASSESSED', material_removal_status='NOT_ASSESSED')

    def verify(self, payload):
        if canonical(payload) != canonical(self.to_data()):
            raise ValueError('Face assembly projection differs from current bound inputs')
        return identity(payload)
