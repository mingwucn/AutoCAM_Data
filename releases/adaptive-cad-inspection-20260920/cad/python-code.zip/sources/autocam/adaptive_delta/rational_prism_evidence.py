"""Independent recorded-trace checks using direct Bernstein blossom restriction."""
from collections import deque
from fractions import Fraction as Q
from math import comb

from .domain import Bounds, Relation, canonical, identity, integer, qdata


def _coefficients(degree, low, high):
    # Blossom at degree-j copies of low and j copies of high. This directly
    # computes the restricted control points without de Casteljau subdivision.
    return tuple(tuple(sum((Q(comb(j,k)*comb(degree-j,i-k)) * high**k * (1-high)**(j-k)
                            * low**(i-k) * (1-low)**(degree-j-i+k)
                            for k in range(max(0,i-degree+j),min(i,j)+1)),Q())
                       for i in range(degree+1)) for j in range(degree+1))


def _restricted_controls(original, low, high):
    u=_coefficients(len(original)-1,low[0],high[0])
    v=_coefficients(len(original[0])-1,low[1],high[1])
    first=tuple(tuple(tuple(sum((weight*original[i][j][k] for i,weight in enumerate(row)),Q())
                           for k in range(4)) for j in range(len(v))) for row in u)
    return tuple(tuple(tuple(sum((weight*row[j][k] for j,weight in enumerate(coeff)),Q())
                             for k in range(4)) for coeff in v) for row in first)


def _cartesian_bounds(net, thickness):
    if any(p[3]<=0 for row in net for p in row):raise ValueError('Nonpositive restricted weight')
    cart=tuple(tuple(tuple(p[k]/p[3] for k in range(3)) for p in row) for row in net)
    lo=tuple(min(p[k] for row in cart for p in row) for k in range(3))
    hi=tuple(max(p[k] for row in cart for p in row) for k in range(3))
    return cart,Bounds((lo[0],lo[1],lo[2]-thickness),hi),lo[2],hi[2]


def verify_recorded_prism_query(record,prism,query,*,maximum_nodes=128,maximum_depth=16,interior=False):
    from .rational_prism_queries import NominalRationalPrism
    if type(prism) is not NominalRationalPrism or type(query) is not Bounds:
        raise ValueError('Typed nominal prism and positive query box required')
    integer(maximum_nodes,'query node budget',0,4096);integer(maximum_depth,'query depth budget',0,24)
    if type(interior) is not bool:raise ValueError('Boolean interior mode required')
    if type(record) is not dict or type(record.get('trace')) is not list or len(record['trace'])>maximum_nodes:
        raise ValueError('Invalid or excessive prism trace')
    expected=dict(schema='adaptive-rational-prism-cell-query-1',geometry_id=identity(prism.to_data()),query=query.to_data(),
        maximum_nodes=maximum_nodes,maximum_depth=maximum_depth,interior=interior,regularity_id=prism._regularity_id,
        method='binary-control-cover-and-expanded-poincare-miranda-1',nominal_geometry_only=True,source_admitted=False)
    pending=deque([('',0,prism.uv_low,prism.uv_high)]);unresolved=[];trace=[];inside_path=None
    original=prism.upper_cap.homogeneous
    for supplied in record['trace']:
        if not pending or inside_path is not None:raise ValueError('Extra prism trace row')
        path,depth,low,high=pending.popleft()
        _,enclosure,_,_=_cartesian_bounds(_restricted_controls(original,low,high),prism.thickness)
        row=dict(path=path,depth=depth,uv_low=[qdata(v) for v in low],uv_high=[qdata(v) for v in high],enclosure=enclosure.to_data())
        separated=[k for k in range(3) if query.high[k]<enclosure.low[k] or query.low[k]>enclosure.high[k]]
        if separated:
            row.update(status='PRUNED_STRICT_DISJOINT',separating_axis=separated[0])
        else:
            wl=tuple(max(prism.uv_low[k],low[k]-(high[k]-low[k])/2) for k in range(2))
            wh=tuple(min(prism.uv_high[k],high[k]+(high[k]-low[k])/2) for k in range(2))
            cart,_,zlo,zhi=_cartesian_bounds(_restricted_controls(original,wl,wh),prism.thickness)
            margins=(query.low[0]-max(p[0] for p in cart[0]),min(p[0] for p in cart[-1])-query.high[0],
                     query.low[1]-max(r[0][1] for r in cart),min(r[-1][1] for r in cart)-query.high[1],
                     query.low[2]-(zhi-prism.thickness),zlo-query.high[2])
            if all(m>0 for m in margins):
                row.update(status='INSIDE_WITNESS',strict_margins_mm=[qdata(v) for v in margins],
                           witness_uv_low=[qdata(v) for v in wl],witness_uv_high=[qdata(v) for v in wh])
                inside_path=path
            elif depth==maximum_depth:
                row['status']='DEPTH_UNRESOLVED';unresolved.append(path)
            else:
                row['status']='SPLIT_COVER';axis=depth%2;middle=(low[axis]+high[axis])/2
                left_high=list(high);left_high[axis]=middle
                right_low=list(low);right_low[axis]=middle
                pending.extend(((path+'0',depth+1,low,tuple(left_high)),(path+'1',depth+1,tuple(right_low),high)))
        if canonical(row)!=canonical(supplied):raise ValueError('Prism trace arithmetic or coverage differs')
        trace.append(row)
    if inside_path is not None:
        expected.update(relation=Relation.INSIDE.value,reason='uniform_xy_root_and_vertical_bracket',witness_path=inside_path)
    elif not pending and not unresolved:
        expected.update(relation=Relation.OUTSIDE.value,reason='complete_strict_disjoint_cover')
    else:
        if pending and len(trace)!=maximum_nodes:raise ValueError('Premature prism trace termination')
        expected.update(relation=Relation.MIXED.value,reason='node_budget' if pending else 'depth_or_contact_unresolved',
                        pending_paths=[p[0] for p in pending],unresolved_paths=unresolved)
    expected.update(nodes=len(trace),trace=trace)
    if canonical(record)!=canonical(expected):raise ValueError('Cell query or caller geometry/policy differs')
    return True
