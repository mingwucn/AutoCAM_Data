"""Bounded eligibility for reusing clearance on immutable geometric inputs."""
from dataclasses import fields
from fractions import Fraction

from .domain import Bounds, Root, Relation
from .geometry import (Box, Cylinder, RoundedCylinder, RoundedAnnulus, Sphere,
                       Empty, Union, Cutout, IndexedSolid, NominalRationalPrism)
from .drill_geometry import ConicalPoint, DrillCutting
from .face_geometry import AnnularSweep
from .indexed_frames import IndexedOrientation
from .turning_tools import TurningAxis
from .rational_patch import RationalPatch
from .partition import SourceDomain, GeometryPolicy, DomainSnapshot
from .packed_domain import PackedDomainSnapshot
from .transitions import MaterialState

PROFILE = 'immutable_remaining_clearance_integer_or_fraction_1'
_VALUES = frozenset((Bounds, Root, Box, Cylinder, RoundedCylinder, RoundedAnnulus,
    Sphere, Empty, Union, Cutout, IndexedSolid, NominalRationalPrism, ConicalPoint,
    DrillCutting, AnnularSweep, IndexedOrientation, TurningAxis, RationalPatch, GeometryPolicy))
_SCALARS = frozenset((type(None), str, bytes, int, bool, float, Fraction, Relation))


def immutable_clearance_inputs(state, envelope):
    if type(state) is not MaterialState or type(state.envelopes) is not tuple:
        return False
    if type(state.domain) not in (DomainSnapshot, PackedDomainSnapshot):
        return False
    if type(state.domain) is DomainSnapshot and type(state.domain.leaves) is not tuple:
        return False
    source = state.domain.source
    if type(source) is not SourceDomain:
        return False
    pending = [(value, 0) for value in (source.root, source.policy, source.stock,
        source.target, source.protected, envelope, state.envelopes)]
    seen = set(); visits = 0
    while pending:
        value, depth = pending.pop(); kind = type(value); visits += 1
        if depth > 128 or visits > 8192:
            return False
        if kind in _SCALARS:
            continue
        if kind is not tuple and kind not in _VALUES:
            return False
        if id(value) in seen:
            continue
        seen.add(id(value))
        children = value if kind is tuple else tuple(getattr(value, f.name) for f in fields(value))
        if len(pending)+len(children)+visits > 8192:
            return False
        pending.extend((child, depth+1) for child in children)
    return True
