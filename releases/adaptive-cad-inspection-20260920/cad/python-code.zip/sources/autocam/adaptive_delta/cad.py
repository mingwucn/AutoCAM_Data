"""Non-mutating numerical CAD audit adapter; never a strict analytic Region."""
from dataclasses import dataclass
from hashlib import sha256
import json
import math
from pathlib import Path
import re
import subprocess


def file_digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


@dataclass(frozen=True, slots=True)
class CadAuditPolicy:
    tolerance_ceiling_mm: str = "0.000001"
    timeout_seconds: int = 90
    maximum_bytes: int = 100*1024*1024

    def __post_init__(self):
        from .domain import rational, integer
        value = self.tolerance_ceiling_mm
        if (type(value) is not str or
                re.fullmatch(r'\+?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', value.strip()) is None or
                rational(value) <= 0 or not math.isfinite(float(value)) or float(value) <= 0):
            raise ValueError("Positive finite decimal CAD tolerance required by the executable")
        integer(self.timeout_seconds, "CAD timeout", 1, 600)
        integer(self.maximum_bytes, "CAD byte budget", 1, 100*1024*1024)


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate CAD observation field: '+key)
        result[key] = value
    return result


def _invalid_constant(value):
    raise ValueError('Nonfinite CAD observation number: '+value)


def _validate_observation(observation, kind, policy, construction_profile):
    """Check protocol consistency; this is not a geometry or placement proof."""
    from .domain import fields, integer
    required = ('schema', 'kernel', 'status', 'strict_admission', 'shape_processing', 'source_units',
                'output_units', 'valid', 'closed_shells', 'solid_count', 'face_count', 'edge_count',
                'all_geometry_attached', 'manifold_incidence', 'same_parameter_flags', 'source_unchanged',
                'max_tolerance_mm', 'tolerance_ceiling_mm', 'tolerance_budget_pass', 'planar_cylindrical_only',
                'bounds_available', 'bounds_mm', 'faces', 'edge_occurrences', 'tolerances_mm',
                'complete_trimmed_patch_bound', 'sampled_pcurve_check', 'rectilinear_parameters',
                'revolution_parameters', 'trimmed_parameters')
    fields(observation, (*required, *(('spherical_parameters',) if construction_profile else ())))
    processing = 'explicit_empty_sequence' if kind == 'step' else 'not_applicable_brep_read'
    units = observation['source_units']
    if (observation['schema'] != 'adaptive-cad-audit-1' or observation['kernel'] != '7.8.1' or
            observation['strict_admission'] is not False or observation['output_units'] != 'mm' or
            observation['shape_processing'] != processing or type(units) is not list or not units or
            any(type(unit) is not str or not unit.strip() for unit in units) or
            (kind == 'brep' and units != ['caller_declared_mm'])):
        raise ValueError('Unexpected CAD import contract')
    gates = ('valid', 'closed_shells', 'all_geometry_attached', 'manifold_incidence',
             'same_parameter_flags', 'source_unchanged', 'tolerance_budget_pass', 'bounds_available')
    for key in (*gates, 'planar_cylindrical_only'):
        if type(observation[key]) is not bool:
            raise ValueError('CAD gate must be a boolean: '+key)
    if observation['complete_trimmed_patch_bound'] is not False or observation['sampled_pcurve_check'] != 'NOT_ASSESSED':
        raise ValueError('Unexpected CAD proof scope')
    for key in ('solid_count', 'face_count', 'edge_count'):
        integer(observation[key], key, 0)
    def number(value):
        try:
            finite = type(value) in (int, float) and math.isfinite(value)
        except OverflowError:
            finite = False
        if not finite:
            raise ValueError('CAD metadata requires finite numerical values')
    faces = observation['faces']
    if type(faces) is not list or len(faces) != observation['face_count']:
        raise ValueError('CAD face inventory differs')
    for index, face in enumerate(faces, 1):
        fields(face, ('session_index', 'surface_type', 'orientation', 'location'))
        integer(face['session_index'], 'face session index', index, index)
        integer(face['surface_type'], 'surface type', 0, 10)
        integer(face['orientation'], 'face orientation', 0, 3)
        if type(face['location']) is not list or len(face['location']) != 12:
            raise ValueError('CAD face placement requires twelve coefficients')
        for value in face['location']: number(value)
    occurrences = observation['edge_occurrences']
    if type(occurrences) is not list or len(occurrences) != observation['edge_count']:
        raise ValueError('CAD edge inventory differs')
    for value in occurrences: integer(value, 'edge occurrence', 0)
    tolerances = observation['tolerances_mm']
    if type(tolerances) is not list or len(tolerances) < observation['face_count']+observation['edge_count']:
        raise ValueError('CAD tolerance inventory differs')
    for value in (*tolerances, observation['max_tolerance_mm'], observation['tolerance_ceiling_mm']):
        number(value)
        if value < 0: raise ValueError('Negative CAD tolerance')
    ceiling = float(policy.tolerance_ceiling_mm)
    if (observation['tolerance_ceiling_mm'] != ceiling or
            observation['max_tolerance_mm'] != max(tolerances, default=0) or
            observation['tolerance_budget_pass'] != all(value <= ceiling for value in tolerances)):
        raise ValueError('CAD tolerance summary differs')
    bounds = observation['bounds_mm']
    if type(bounds) is not list or len(bounds) != 6:
        raise ValueError('CAD bounds require six coordinates')
    for value in bounds: number(value)
    if any(bounds[k] > bounds[k+3] for k in range(3)):
        raise ValueError('CAD bounds are inverted')
    expected = 'EVALUATED' if all(observation[key] for key in gates) and observation['solid_count'] > 0 else 'QUARANTINED'
    if observation['status'] != expected:
        raise ValueError('CAD status contradicts numerical gates')
    for key in ('rectilinear_parameters', 'revolution_parameters', 'trimmed_parameters',
                *(('spherical_parameters',) if construction_profile else ())):
        if type(observation[key]) is not dict:
            raise ValueError('CAD extraction must be an object: '+key)


def audit_cad(source, output, *, executable, expected_sha256, policy=CadAuditPolicy(), construction_profile=None):
    """Each output directory is a new execution with a frozen input copy."""
    if construction_profile is not None and construction_profile != "spherical_nominal":
        raise ValueError("Unsupported optional construction profile")
    source, output, executable = Path(source).resolve(), Path(output).resolve(), Path(executable).resolve()
    if source.stat().st_size > policy.maximum_bytes:
        raise ValueError("CAD input byte budget exceeded")
    raw = source.read_bytes()
    if not raw or sha256(raw).hexdigest() != expected_sha256:
        raise ValueError("CAD source bytes differ from explicit input pin")
    kind = "step" if source.suffix.lower() in (".step", ".stp") else "brep" if source.suffix.lower()==".brep" else None
    if kind is None:
        raise ValueError("Unsupported CAD file format")
    output.mkdir(parents=True, exist_ok=False)
    frozen = output/("source"+source.suffix.lower())
    frozen.write_bytes(raw)
    snapshot = output/"imported.brep"
    command = [str(executable), kind, str(frozen), policy.tolerance_ceiling_mm, str(snapshot)]
    if construction_profile is not None:
        command.append(construction_profile)
    record = {"schema": "adaptive-cad-execution-1", "source_sha256": expected_sha256,
              "source_path": str(source), "executable_sha256": file_digest(executable),
              "command": command, "timeout_seconds": policy.timeout_seconds,
              "tolerance_ceiling_mm": policy.tolerance_ceiling_mm, "strict_admission": False}
    try:
        result = subprocess.run(command, capture_output=True, timeout=policy.timeout_seconds)
        (output/"stdout.txt").write_bytes(result.stdout)
        (output/"stderr.txt").write_bytes(result.stderr)
        record["returncode"] = result.returncode
        if result.returncode:
            record.update(status="QUARANTINED", reason="cad_reader_or_audit_failure")
        else:
            lines = result.stdout.decode("utf-8").splitlines()
            observation = json.loads(next(line for line in reversed(lines) if line.startswith('{"schema":"adaptive-cad-audit-1"')),
                                     object_pairs_hook=_object, parse_constant=_invalid_constant)
            _validate_observation(observation, kind, policy, construction_profile)
            record["imported_snapshot_sha256"] = file_digest(snapshot)
            for face in observation["faces"]:
                binding = {"source_sha256": expected_sha256, "snapshot_sha256": record["imported_snapshot_sha256"],
                           "importer_sha256": record["executable_sha256"], "face": face.copy()}
                face["source_face_id"] = sha256(json.dumps(binding, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            record.update(status=observation["status"], observation=observation)
    except subprocess.TimeoutExpired as error:
        (output/"stdout.txt").write_bytes(error.stdout or b"")
        (output/"stderr.txt").write_bytes(error.stderr or b"")
        record.update(status="QUARANTINED", reason="cad_audit_timeout")
    except (ValueError, KeyError, StopIteration) as error:
        record.update(status="QUARANTINED", reason="invalid_adapter_output", detail=str(error))
    except OSError as error:
        record.update(status="QUARANTINED", reason="cad_io_failure", detail=str(error))
    try:
        record["raw_source_unchanged"] = file_digest(source)==expected_sha256 and file_digest(frozen)==expected_sha256
    except OSError:
        record["raw_source_unchanged"] = False
    if not record["raw_source_unchanged"]:
        record.update(status="QUARANTINED", reason="source_bytes_changed")
    record["limitations"] = ["Numerical source audit only; no complete trimmed-patch enclosure",
                             "SameParameter flags do not prove curve/pcurve consistency",
                             "STEP translation creates a pinned imported source; no source-to-import tolerance equality claim",
                             "No strict CAD-to-analytic conversion or material-removal admission"]
    (output/"result.json").write_text(json.dumps(record, indent=2, sort_keys=True)+"\n", encoding="utf-8")
    return record
