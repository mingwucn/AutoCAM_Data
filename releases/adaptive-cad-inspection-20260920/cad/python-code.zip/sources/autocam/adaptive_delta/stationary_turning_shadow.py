"""Fixed-bearing point rays through stationary obstacles, not rotating fixtures."""
from dataclasses import dataclass

from .annular_directional_shadow import annular_band
from .domain import Relation, canonical, identity, integer, qdata
from .geometry import Box, Cutout, Cylinder, Empty, Sphere, Union
from .transitions import ClosedQuery
from .turning_point_shadow import TurningPointShadowView, _RadialBand, _ShadowUnion, _radial_squared

PROFILE = 'closed_fixed_bearing_stationary_turning_point_shadow_1'
REASONS = ('protected', 'fixture', 'stationary', 'combined')
I, O, M = Relation.INSIDE, Relation.OUTSIDE, Relation.MIXED


@dataclass(frozen=True, slots=True)
class _AxisShadow:
    """Closed spindle contact has zero volume but is not the empty set."""
    spindle: object
    low: object
    high: object

    def classify(self, query, *, interior=False):
        if interior:
            return O
        low, high = query.low[self.spindle.axis], query.high[self.spindle.axis]
        rlow, rhigh = _radial_squared(query, self.spindle)
        if high < self.low or low > self.high or rlow > 0:
            return O
        return I if self.low <= low and high <= self.high and rhigh == 0 else M

    def to_data(self):
        return dict(kind='turning_stationary_axis_shadow_1', spindle=self.spindle.to_data(),
                    low=qdata(self.low), high=qdata(self.high))


@dataclass(frozen=True, slots=True)
class StationaryTurningShadowView:
    rotating: TurningPointShadowView
    radial_axis: int
    radial_sign: int
    stationary_obstacles: object

    def __post_init__(self):
        if type(self.rotating) is not TurningPointShadowView:
            raise ValueError('Bound rotating turning projection required')
        integer(self.radial_axis, 'fixed radial bearing axis', 0, 2)
        if self.radial_axis == self.rotating.spindle.axis:
            raise ValueError('Fixed bearing must be perpendicular to spindle')
        if type(self.radial_sign) is not int or self.radial_sign not in (-1, 1):
            raise ValueError('Explicit signed fixed bearing required')
        # Validate even components that later prove outside the approach plane.
        self._operands(self.stationary_obstacles)

    @property
    def tangent_axis(self):
        return next(k for k in range(3) if k not in (self.radial_axis, self.rotating.spindle.axis))

    def _box_section(self, box):
        origin = self.rotating.spindle.origin
        if not box.bounds.low[self.tangent_axis] <= origin[self.tangent_axis] <= box.bounds.high[self.tangent_axis]:
            return None
        inner, outer = sorted(self.radial_sign*(v-origin[self.radial_axis])
                              for v in (box.bounds.low[self.radial_axis], box.bounds.high[self.radial_axis]))
        return None if outer < 0 else (max(0, inner), outer)

    def _box(self, box, cutters=()):
        section = self._box_section(box)
        if section is None:
            return ()
        inner, outer = section
        view, axis = self.rotating, self.rotating.spindle.axis
        low, high = list(box.bounds.low), list(box.bounds.high)
        low[self.tangent_axis] = high[self.tangent_axis] = view.spindle.origin[self.tangent_axis]
        if view.mode == 'OUTSIDE':
            low[self.radial_axis] = high[self.radial_axis] = view.spindle.origin[self.radial_axis]+self.radial_sign*outer
        else:
            low[axis] = high[axis] = box.bounds.low[axis] if view.facing_sign == 1 else box.bounds.high[axis]
            low[self.radial_axis], high[self.radial_axis] = sorted(
                view.spindle.origin[self.radial_axis]+self.radial_sign*r for r in (inner, outer))
        witness = ClosedQuery(tuple(low), tuple(high))
        if any(c.classify(witness, interior=True) != O for c in cutters):
            raise ValueError('Stationary box cutout lacks a complete fixed-plane extremal witness')
        a, b = box.bounds.low[axis], box.bounds.high[axis]
        if view.mode == 'OUTSIDE':
            inner = 0
        elif view.facing_sign == 1:
            b = view.exterior.high[axis]
        else:
            a = view.exterior.low[axis]
        operand = (_AxisShadow(view.spindle, a, b) if outer == 0 else
                   _RadialBand(view.spindle, a, b, inner*inner, outer*outer))
        return (operand,)

    def _operands(self, shape):
        if type(shape) is Empty:
            return ()
        if type(shape) is Union:
            return tuple(p for child in shape.children for p in self._operands(child))
        if type(shape) not in (Box, Cylinder, Sphere, Cutout):
            raise ValueError('Unsupported stationary turning point-shadow geometry')
        if type(shape) is Cutout and type(shape.base) is Union:
            if len(shape.cutters) != 1 or type(shape.cutters[0]) is not Cylinder:
                raise ValueError('Stationary cylinder union requires one common through bore')
            if any(type(c) not in (Cylinder, Union, Empty) for c in shape.base.children):
                raise ValueError('Stationary through-bore union requires cylinder components')
            return tuple(p for child in shape.base.children if type(child) is not Empty
                         for p in self._operands(Cutout(child, shape.cutters)))
        bounds = shape.bounds
        if bounds is None:
            raise ValueError('Unsupported empty stationary difference')
        if any(bounds.low[k] <= self.rotating.exterior.low[k] or
               bounds.high[k] >= self.rotating.exterior.high[k] for k in range(3)):
            raise ValueError('Stationary blockers must lie strictly within declared exterior')
        if type(shape) is Box:
            return self._box(shape)
        if type(shape) is Cutout and type(shape.base) is Box:
            if any(type(c) not in (Box, Cylinder, Sphere) for c in shape.cutters):
                raise ValueError('Unsupported stationary box cutout predicate')
            return self._box(shape.base, shape.cutters)
        base = annular_band(shape)[0] if type(shape) is Cutout else shape
        spindle = self.rotating.spindle
        center = tuple(spindle.origin[k] for k in range(3) if k != spindle.axis)
        coaxial = (type(base) is Cylinder and base.axis == spindle.axis and base.center == center or
                   type(shape) is Sphere and tuple(shape.center[k] for k in range(3) if k != spindle.axis) == center)
        if not coaxial:
            raise ValueError('Stationary round blocker requires coaxial principal geometry')
        return (self.rotating._project(shape),)

    def shadow(self, reason='combined'):
        if reason not in REASONS:
            raise ValueError('Unknown stationary turning point-shadow reason')
        if reason in ('protected', 'fixture'):
            return self.rotating.shadow(reason)
        stationary = self._operands(self.stationary_obstacles)
        return _ShadowUnion(stationary if reason == 'stationary' else
                            (*self.rotating.shadow().children, *stationary))

    def classify_shadow(self, query, reason='combined', *, interior=False):
        self.rotating._query(query)
        return self.shadow(reason).classify(query, interior=interior)

    def classify(self, query, reason='combined'):
        self.rotating._query(query)
        state = self.rotating.state
        source = state.domain.source
        shadow = self.shadow(reason).classify(query)
        stock = Cutout(source.stock, state.envelopes).classify(query)
        protected = source.protected.classify(query)
        fixture = self.rotating.rotating_fixture.classify(query)
        if O in (shadow, stock) or I in (protected, fixture):
            return O
        return I if shadow == stock == I and protected == fixture == O else M

    def to_data(self):
        return dict(schema='adaptive-stationary-turning-point-shadow-view-1', predicate_version=PROFILE,
            projection_only=True, operation_authorized=False, frame='original_part_zero_spindle_phase',
            rotating_projection=self.rotating.to_data(), radial_axis=self.radial_axis, radial_sign=self.radial_sign,
            stationary_obstacles=self.stationary_obstacles.to_data(),
            stationary_obstacles_id=identity(self.stationary_obstacles.to_data()),
            shadows={reason: self.shadow(reason).to_data() for reason in REASONS},
            stationary_model='fixed_bearing_meridional_half_plane_point_rays',
            set_semantics='accepted_stock_intersect_shadow_minus_closed_protected_and_rotating_fixture',
            boundary_semantics='closed_tangency_blocks_axis_contact_retained_partial_cells_mixed',
            stationary_point_shadow_status='ASSESSED', stationary_rotation_collision_status='NOT_ASSESSED',
            finite_tool_access_status='NOT_ASSESSED', tool_length_status='NOT_ASSESSED', machine_motion_status='NOT_ASSESSED')

    def verify(self, payload):
        if canonical(payload) != canonical(self.to_data()):
            raise ValueError('Stationary turning shadow differs from bound inputs')
        return identity(payload)
