"""Read-only content resolution for a caller-pinned, already-fetched ZIP."""
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import re
import zipfile


def require(ok, message):
    if not ok:
        raise ValueError(message)


def safe_path(value):
    require(type(value) is str and bool(value), 'Invalid relative path')
    path = PurePosixPath(value)
    require(not path.is_absolute() and path.as_posix() == value
            and '..' not in path.parts and '\\' not in value
            and ':' not in value and '\x00' not in value
            and not value.endswith('/'), 'Unsafe relative path')
    return value


def check_hash(value):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value) is not None,
            'Invalid SHA-256')


def stream_hash(stream):
    digest = sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(block)
    return digest.hexdigest()


@dataclass(frozen=True)
class ArchiveIdentity:
    repository: str
    commit: str
    path: str
    sha256: str

    def __post_init__(self):
        require(type(self.repository) is str and re.fullmatch(
            r'[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+', self.repository) is not None
            and self.repository.split('/')[1] not in ('.', '..'), 'Invalid repository')
        require(type(self.commit) is str and re.fullmatch('[0-9a-f]{40}', self.commit) is not None,
                'Exact Git commit required')
        safe_path(self.path)
        check_hash(self.sha256)

    def as_dict(self):
        return dict(repository=self.repository, commit=self.commit, path=self.path, sha256=self.sha256)


class PinnedArchive:
    """Hold one verified file descriptor; never resolve through workspace paths."""

    def __init__(self, path, identity):
        require(isinstance(identity, ArchiveIdentity), 'Archive identity required')
        self.identity = identity
        self._stream = Path(path).open('rb')
        self._archive = None
        try:
            self._stream.seek(0, 2)
            require(self._stream.tell() <= 512 * 1024**2, 'Compressed archive size limit')
            self._stream.seek(0)
            require(stream_hash(self._stream) == identity.sha256, 'Archive hash mismatch')
            self._stream.seek(0)
            self._archive = zipfile.ZipFile(self._stream)
            infos = self._archive.infolist()
            require(len(infos) <= 20000 and sum(i.file_size for i in infos) <= 4 * 1024**3,
                    'Archive resource limit')
            names = [safe_path(i.filename) for i in infos]
            require(len(names) == len(set(names)), 'Duplicate archive member')
            self._infos = {i.filename: i for i in infos}
            require('review-manifest.json' in self._infos, 'Missing review manifest')
            require(self._infos['review-manifest.json'].file_size <= 4 * 1024**2,
                    'Review manifest size limit')
            manifest = json.loads(self._archive.read('review-manifest.json'))
            require(manifest['schema'] == 'shadow-gym-owner-review-1', 'Wrong review schema')
            rows = manifest['members']
            require(type(rows) is list and 0 < len(rows) < 20000, 'Invalid inventory')
            self._rows = {}
            self._origins = {}
            for row in rows:
                name = safe_path(row['path'])
                require(name not in self._rows and name != 'review-manifest.json', 'Duplicate inventory')
                check_hash(row['sha256'])
                require(type(row['size']) is int and row['size'] >= 0, 'Invalid member size')
                require(name in self._infos and self._infos[name].file_size == row['size'],
                        'Missing or wrong-size member')
                self._rows[name] = row
                origin = row.get('origin')
                if origin != 'generated_review_draft':
                    safe_path(origin)
                    require(origin not in self._origins, 'Ambiguous source origin')
                    self._origins[origin] = name
            require(set(names) == set(self._rows) | {'review-manifest.json'}, 'Unindexed archive member')
        except BaseException:
            self.close()
            raise

    def close(self):
        if self._archive is not None:
            self._archive.close()
        self._stream.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def reference(self, origin, *, expected_sha256, expected_size):
        safe_path(origin)
        require(origin in self._origins, 'Source origin unavailable in archive')
        row = self._rows[self._origins[origin]]
        check_hash(expected_sha256)
        require(type(expected_size) is int and expected_size >= 0, 'Invalid expected size')
        require(row['sha256'] == expected_sha256 and row['size'] == expected_size,
                'Source identity mismatch')
        ref = dict(kind='git_commit_archive_member', archive=self.identity.as_dict(),
                   member=row['path'], sha256=row['sha256'], size=row['size'])
        self.verify(ref)
        return ref

    def _check(self, ref):
        require(ref['kind'] == 'git_commit_archive_member' and ref['archive'] == self.identity.as_dict(),
                'Archive reference identity mismatch')
        name = safe_path(ref['member'])
        require(name in self._rows, 'Unindexed member reference')
        row = self._rows[name]
        require(type(ref['size']) is int and ref['size'] == row['size']
                and ref['sha256'] == row['sha256'], 'Member reference identity mismatch')
        return row

    def verify(self, ref):
        row = self._check(ref)
        with self._archive.open(row['path']) as stream:
            require(stream_hash(stream) == row['sha256'], 'Member content mismatch')

    def read_json(self, ref, *, max_bytes=1024**2):
        require(type(max_bytes) is int and 0 < max_bytes <= 4 * 1024**2, 'JSON read budget limit')
        row = self._check(ref)
        require(row['size'] <= max_bytes, 'Member exceeds JSON read budget')
        raw = self._archive.read(row['path'])
        require(sha256(raw).hexdigest() == row['sha256'], 'Member content mismatch')
        return json.loads(raw)


def rebind_lineage(mapping, archive):
    """Preserve claims and topology while replacing local-only node resolvers."""
    require(mapping['schema'] == 'adaptive-bounded-admission-map-1'
            and mapping['kind'] == 'unsealed_candidate_lineage', 'Wrong lineage input')
    require(all(mapping[key] is False for key in ('canonical_model_admission',
            'canonical_evidence_case_sealed', 'runtime_activation', 'manufacturing_qualified',
            'full_plan_complete')), 'Unexpected lineage authority claim')
    result = json.loads(json.dumps(mapping))
    ids = [node['id'] for node in result['nodes']]
    require(len(ids) == len(set(ids)), 'Duplicate lineage node')
    graph = {name: [] for name in ids}
    for edge in result['edges']:
        require(edge['source'] in graph and edge['target'] in graph, 'Unresolved graph edge')
        if edge['relation'] == 'derived_from':
            graph[edge['source']].append(edge['target'])
    def visit(name, active):
        require(name not in active, 'Derivation cycle')
        for child in graph[name]:
            visit(child, active | {name})
    for name in ids:
        visit(name, set())
    for node in result['nodes']:
        resolver = node['resolver']
        require(resolver['kind'] == 'workspace_relative', 'Unexpected original resolver')
        node['resolver'] = archive.reference(resolver['path'], expected_sha256=node['sha256'],
                                             expected_size=node['size'])
    result['schema'] = 'adaptive-archived-admission-map-1'
    result['canonical_model_admission'] = False
    result['case_sealed'] = False
    result['runtime_activation'] = False
    result['custody_scope'] = 'Exact listed nodes resolved from caller-pinned archive; not qualification.'
    for blocker in result['blockers']:
        if blocker['code'] == 'durable_evidence_resolver':
            blocker['state'] = 'resolved_for_listed_nodes'
            blocker['resolution'] = archive.identity.as_dict()
    for requirement in result['requirements']:
        if 'durable_evidence_resolver' in requirement['blocker_codes']:
            requirement['resolved_blocker_codes'] = ['durable_evidence_resolver']
            requirement['blocker_codes'].remove('durable_evidence_resolver')
            requirement['assessment'] = 'archived_candidate_support_without_canonical_admission'
    return result
