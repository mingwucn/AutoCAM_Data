"""Exact principal-direction point shadows of closed through-bore bands."""
from dataclasses import dataclass

from .analytic_directional_shadow import _extrude
from .directional_shadow_view import DirectionalShadowView, REASONS
from .domain import digest, integer
from .geometry import Box, Cutout, Cylinder, Empty, Sphere, Union
from .transitions import MaterialState

PROFILE = 'closed_annular_axis_point_shadow_1'


def annular_band(shape):
    """Recognize the exact closed band; equal bore endpoints leave cap disks."""
    if (type(shape) is not Cutout or type(shape.base) is not Cylinder or
            len(shape.cutters) != 1 or type(shape.cutters[0]) is not Cylinder):
        raise ValueError('Annular point-shadow requires one coaxial through bore')
    outer, bore = shape.base, shape.cutters[0]
    if (outer.axis != bore.axis or outer.center != bore.center or
            not 0 < bore.radius < outer.radius or
            not bore.low < outer.low or not outer.high < bore.high):
        raise ValueError('Annular point-shadow requires one coaxial through bore')
    return outer, bore


def _primitives(shape):
    if type(shape) is Empty:
        return ()
    if type(shape) in (Box, Cylinder, Sphere):
        return (shape,)
    if type(shape) is Cutout:
        annular_band(shape)
        return (shape,)
    if type(shape) is Union:
        return tuple(item for child in shape.children for item in _primitives(child))
    raise ValueError('Annular point-shadow obstacle geometry is unsupported')


def _shadow(shape, axis, sign, exterior):
    if type(shape) is not Cutout:
        return _extrude(shape, axis, sign, exterior)
    outer, bore = annular_band(shape)
    projected = _extrude(outer, axis, sign, exterior)
    if axis != outer.axis:
        # The upstream outer wall blocks the bore under transverse travel.
        return projected
    width = exterior.high[axis]-exterior.low[axis]
    clear_bore = Cylinder(axis, bore.center, bore.radius,
                          exterior.low[axis]-width, exterior.high[axis]+width)
    return Cutout(projected, (clear_bore,))


@dataclass(frozen=True, slots=True)
class AnnularDirectionalShadowView(DirectionalShadowView):
    def __post_init__(self):
        if type(self.state) is not MaterialState:
            raise ValueError('Typed accepted material required')
        integer(self.axis, 'part-frame direction axis', 0, 2)
        integer(self.sign, 'part-frame travel sign', -1, 1)
        if self.sign == 0:
            raise ValueError('Nonzero direction required')
        digest(self.semantic_id)
        exterior = self.exterior
        for shape in (self.state.domain.source.protected, self.fixture):
            for primitive in _primitives(shape):
                bounds = primitive.bounds
                if any(bounds.low[k] <= exterior.low[k] or
                       bounds.high[k] >= exterior.high[k] for k in range(3)):
                    raise ValueError('Blockers must lie strictly within the declared exterior')

    def shadow(self, reason='combined'):
        if reason not in REASONS:
            raise ValueError('Unknown point-shadow reason')
        protected = self.state.domain.source.protected
        obstacles = (protected, self.fixture) if reason == 'combined' else (
            protected if reason == 'protected' else self.fixture,)
        return Union(tuple(_shadow(shape, self.axis, self.sign, self.exterior)
                           for obstacle in obstacles for shape in _primitives(obstacle)))

    def to_data(self):
        payload = DirectionalShadowView.to_data(self)
        payload['predicate_version'] = PROFILE
        return payload
