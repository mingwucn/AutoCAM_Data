"""Prospective stock-size evaluation; never trains or selects a checkpoint."""
from fractions import Fraction
import math

CHECKPOINT_SHA256='8c73afff07da6436829ce97fdd5d1801daf5d69d47cb1ec4ed4f08911e9037c1'
POLICIES=('deterministic','random','greedy','model','model_mcts')


def require(ok,message):
    if not ok:raise ValueError(message)


def tasks():
    # These imports resolve to the authenticated, original producer in a run.
    from dataclasses import replace
    from autocam.adaptive_delta.mill_turn_training_tasks import distinct_bore_tasks,bore_family_evidence
    from autocam.adaptive_delta.geometry import Cylinder
    old=distinct_bore_tasks()
    templates={t.turning_axis.axis:t for t in old if t.family=='rounded' and t.source.stock.radius==12}
    require(len(templates)==3,'Original axis templates missing')
    result=[]
    for numerator in (25,27,29):
        radius=Fraction(numerator,2)
        for axis in range(3):
            base=templates[axis]
            stock=Cylinder(axis,(0,0),radius,0,20)
            task=replace(base,variant=f'confirmation-R{numerator}-over-2-'+'XYZ'[axis],
                         source=replace(base.source,stock=stock),residual_budget=Fraction(3,2)*radius**2*20)
            bore_family_evidence(task);result.append(task)
    check_disjoint([dict(task_id=t.id,source_geometry_id=t.source.geometry_id) for t in result],
                   [dict(task_id=t.id,source_geometry_id=t.source.geometry_id) for t in old])
    return tuple(result)


def check_disjoint(new,old):
    require(len(new)==9 and len(old)==27,'Task denominator mismatch')
    for key in ('task_id','source_geometry_id'):
        fresh=[r[key] for r in new];prior=[r[key] for r in old]
        require(len(set(fresh))==9 and len(set(prior))==27,'Task identities alias')
        require(not set(fresh)&set(prior),'Previously observed task/source identity')


def roster(task_ids):
    require(len(task_ids)==9 and len(set(task_ids))==9,'Nine distinct tasks required')
    return [dict(task_id=task_id,policy=policy,seed=27001+i,epoch=None)
            for i,task_id in enumerate(task_ids) for policy in POLICIES]


def summarize(task_ids,records,*,replay_passed,checkpoint_sha256):
    require(checkpoint_sha256==CHECKPOINT_SHA256,'Checkpoint changed')
    expected=roster(task_ids)
    require(len(records)==45,'Full 45-episode denominator required')
    require(type(replay_passed) is bool,'Explicit replay result required')
    for row,wanted in zip(records,expected):
        require(row['roster']==wanted,'Roster order, policy or seed changed')
        require(row['status'] in ('executed','error'),'Unknown episode status')
        if row['status']=='error':
            require(type(row['error']) is str and bool(row['error']),'Error evidence missing')
            require(all(row.get(k) is None for k in ('return_value','steps','terminated','truncated')),
                    'Error has fabricated metrics')
            continue
        require(type(row['terminated']) is bool and type(row['truncated']) is bool
                and row['terminated']!=row['truncated'],'Invalid terminal flags')
        require(type(row['steps']) is int and 1<=row['steps']<=8,'Invalid action count')
        require(type(row['return_value']) in (int,float) and math.isfinite(row['return_value']),
                'Invalid return')
        require(row['learn'] is False and row['weights_unchanged'] is True,'Evaluation learned or changed weights')
    metrics=[]
    for policy in POLICIES:
        subset=[r for r in records if r['roster']['policy']==policy]
        valid=[r for r in subset if r['status']=='executed']
        metrics.append(dict(policy=policy,planned=9,executed=len(valid),errors=9-len(valid),
            completed=sum(r['terminated'] for r in valid),truncated=sum(r['truncated'] for r in valid),
            mean_return=sum(r['return_value'] for r in valid)/len(valid) if valid else None,
            mean_steps=sum(r['steps'] for r in valid)/len(valid) if valid else None))
    by_policy={r['policy']:r for r in metrics}
    qualified=(replay_passed and not any(r['errors'] for r in metrics)
        and by_policy['deterministic']['completed']==9
        and all(by_policy[p]['completed']>=by_policy['deterministic']['completed'] for p in ('model','model_mcts')))
    paired=[]
    for task_id in task_ids:
        subset={r['roster']['policy']:r for r in records if r['roster']['task_id']==task_id}
        for policy in ('model','model_mcts'):
            baseline,candidate=subset['deterministic'],subset[policy]
            both=baseline['status']==candidate['status']=='executed'
            paired.append(dict(task_id=task_id,policy=policy,comparable=both,
                return_difference=candidate['return_value']-baseline['return_value'] if both else None,
                action_difference=candidate['steps']-baseline['steps'] if both else None))
    return dict(schema='adaptive-v4-stock-confirmation-result-1',
        technical_profile_outcome='Passed' if qualified else 'NotQualified',
        checkpoint_sha256=checkpoint_sha256,planned_episodes=45,metrics=metrics,paired=paired,
        exact_replay_passed=replay_passed,scope='new_stock_instances_in_previously_exposed_family',
        family_disjoint_confirmation=False,superiority_claim=False,statistical_replication=False,
        canonical_model_admission=False,runtime_activation=False,manufacturing_qualified=False,
        evidence_case_sealed=False)
