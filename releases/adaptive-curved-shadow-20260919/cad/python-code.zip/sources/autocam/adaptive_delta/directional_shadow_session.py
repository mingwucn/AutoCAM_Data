"""Bind spatial point shadow to an existing validated tool diagnostic."""
from .codec import parse_canonical
from .domain import fields
from .geometry import Box, Cylinder, Empty, IndexedSolid, Sphere, Union
from .indexed_frames import IndexedOrientation


def exact_part_boxes(shape, pose):
    """Transform supported boxes exactly; never use an oblique enclosure."""
    if type(pose) is not IndexedOrientation:
        raise ValueError('Explicit candidate frame transform required')
    if type(shape) is Empty:
        return shape
    if type(shape) is Union:
        return Union(tuple(exact_part_boxes(child, pose) for child in shape.children))
    if type(shape) is IndexedSolid:
        return exact_part_boxes(shape.base, pose.compose(shape.pose))
    if type(shape) is Box:
        if pose.cosine not in (-1, 0, 1) or pose.sine not in (-1, 0, 1):
            raise ValueError('Point-shadow boxes require an exact signed-permutation pose')
        return Box(pose.enclose(shape.bounds))
    raise ValueError('Point-shadow obstacle geometry is unsupported')


def exact_part_analytic(shape, pose):
    """Preserve analytic geometry under an exactly representable candidate pose."""
    if type(pose) is not IndexedOrientation:
        raise ValueError('Explicit candidate frame transform required')
    if type(shape) is Empty:
        return shape
    if type(shape) is Union:
        return Union(tuple(exact_part_analytic(child, pose) for child in shape.children))
    if type(shape) is IndexedSolid:
        return exact_part_analytic(shape.base, pose.compose(shape.pose))
    if type(shape) is Box:
        return exact_part_boxes(shape, pose)
    if type(shape) is Sphere:
        return Sphere(pose.point(shape.center), shape.radius)
    if type(shape) is Cylinder:
        direction = pose.vector(tuple(int(k == shape.axis) for k in range(3)))
        axes = [k for k, value in enumerate(direction) if value != 0]
        if len(axes) != 1 or direction[axes[0]] not in (-1, 1):
            raise ValueError('Analytic point-shadow cylinder axis is oblique')
        axis = axes[0]
        endpoints = []
        for end in (shape.low, shape.high):
            point = [end]*3
            for k, value in zip(shape.radial_axes, shape.center):
                point[k] = value
            endpoints.append(pose.point(point))
        return Cylinder(axis, tuple(endpoints[0][k] for k in range(3) if k != axis),
                        shape.radius, min(p[axis] for p in endpoints), max(p[axis] for p in endpoints))
    raise ValueError('Analytic point-shadow obstacle geometry is unsupported')


def directional_shadow_response(browser, request):
    from .drill_browser_session import bounded, drill_length_response
    from .face_browser_session import face_assembly_response
    from .drill_candidates import DrillCandidateBatch
    from .face_candidates import FaceCandidateBatch
    from .directional_shadow_view import DirectionalShadowView
    fields(request, ('operation', 'session_epoch', 'expected_semantic_id', 'batch_id', 'candidate_id'))
    if request['operation'] not in ('shadow_view', 'analytic_shadow_view'):
        raise ValueError('Unsupported point-shadow diagnostic')
    transform, view_type = exact_part_boxes, DirectionalShadowView
    if request['operation'] == 'analytic_shadow_view':
        from .analytic_directional_shadow import AnalyticDirectionalShadowView
        transform, view_type = exact_part_analytic, AnalyticDirectionalShadowView
    if type(request['session_epoch']) is not int or request['session_epoch'] != browser.epoch:
        raise ValueError('Stale point-shadow session epoch')
    with browser.session._lock:
        if request['expected_semantic_id'] != browser.session.semantic_id:
            raise ValueError('Stale point-shadow semantic state')
        batch = browser._batches.get(request['batch_id'])
        if type(batch) is FaceCandidateBatch:
            raw = face_assembly_response(browser, request)
        elif type(batch) is DrillCandidateBatch:
            raw = drill_length_response(browser, request)
        else:
            raise ValueError('Point-shadow requires a saved face or drill candidate batch')
        response = parse_canonical(raw.encode('utf-8'))
        operation = response['projection']['operation']
        direction = (operation['requirement'] if type(batch) is FaceCandidateBatch
                     else operation['requirement']['entry'])
        journal = browser.session._journal
        pose = journal._machine.select(operation['orientation_id'])
        stationary = transform(journal._stationary, pose.inverse())
        # Part-fixed geometry is already in the original-part frame.
        rotating = transform(journal._fixture, IndexedOrientation(pose.spindle, 1, 0))
        fixture = Union((rotating, stationary))
        projection = view_type(journal.material, direction['axis'], direction['sign'],
                                           fixture, browser.session.semantic_id)
        accepted = journal.semantic_snapshot()['orientation_id']
        context = dict(schema='adaptive-point-shadow-obstacle-context-1', machine_id=journal._machine.id,
            fixture_part=journal._fixture.to_data(), stationary_machine=journal._stationary.to_data(),
            stationary_part=stationary.to_data(), part_to_machine=pose.to_data(),
            accepted_orientation_id=accepted, candidate_orientation_id=pose.id, pose_is_current=pose.id == accepted)
        return bounded(dict(schema=browser._schema('shadow'), session_epoch=browser.epoch,
            observation=response['observation'], batch_id=response['batch_id'], candidate_id=response['candidate_id'],
            row=response['row'], obstacle_context=context, projection=projection.to_data())).decode('utf-8')
