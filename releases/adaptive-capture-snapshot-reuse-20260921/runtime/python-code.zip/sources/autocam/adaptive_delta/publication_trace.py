"""Optional immutable speculative writer events; never an accepted browser record."""
from dataclasses import dataclass,field,replace
from .domain import canonical
from .capture_capacity import record_limit

MAX_EVENTS=128
MAX_EVENT_BYTES=64*1024**2

@dataclass(frozen=True, slots=True)
class PublicationTrace:
    entries: tuple=()
    size: int=0
    overflow: bool=False
    profile: str=field(default='default',kw_only=True)

    def __post_init__(self):record_limit(self.profile,MAX_EVENTS)

    def append(self,before,after,event,result):
        if self.overflow:return self
        raw=canonical(event)
        if len(self.entries)>=record_limit(self.profile,MAX_EVENTS) or self.size+len(raw)>MAX_EVENT_BYTES:
            return replace(self,overflow=True)
        return replace(self,entries=self.entries+((before,after,raw,result),),size=self.size+len(raw))
