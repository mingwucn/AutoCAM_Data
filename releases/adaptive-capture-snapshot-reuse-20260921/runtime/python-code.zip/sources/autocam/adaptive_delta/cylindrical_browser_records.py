"""Supplement the selected choice journal without changing ordinary decisions."""
from hashlib import sha256
import json
from .browser_transition_records import BrowserTransitionRecords
from .journal_browser_records import writer
from .prepared_browser_records import collect_writer


def start(browser,configuration,snapshot,origin):
    browser._transition_input_hashes=(sha256(configuration).hexdigest(),sha256(snapshot).hexdigest())
    initial=BrowserTransitionRecords.start(origin,initial_snapshot=snapshot,profile='bounded_journal_256')
    prefix=collect_writer(initial,writer(browser._initial))
    browser._transition_prefix_records=prefix
    browser._transition_records=prefix
    export(browser)


def bind_configuration(browser,configuration):
    browser._transition_input_hashes=(sha256(configuration).hexdigest(),browser._transition_input_hashes[1])
    export(browser)


def encoded(browser,session,records):
    episode=browser._encode(session.export())
    task_hash,initial_hash=browser._transition_input_hashes
    material=json.loads(records.export(episode,task_sha256=task_hash,initial_sha256=initial_hash))
    return browser._encode(dict(schema='adaptive-cylindrical-browser-transition-record-1',
        configuration_id=browser.config_id,task_id=session.task_id,planning_head=session.head,
        prefix_record_count=len(browser._transition_prefix_records.records),material=material))


def prepare(browser,session,*,replacement=False):
    initial=browser._transition_prefix_records if replacement else browser._transition_records
    records=collect_writer(initial,writer(session._journal))
    encoded(browser,session,records)
    return records


def export(browser):
    records=browser._transition_records
    if collect_writer(records,writer(browser.session._journal))!=records:
        raise ValueError('Choice material has uncaptured accepted publications')
    return encoded(browser,browser.session,records)
