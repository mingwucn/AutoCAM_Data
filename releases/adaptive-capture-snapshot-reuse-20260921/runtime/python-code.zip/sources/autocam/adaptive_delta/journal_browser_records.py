"""Select real branch events into bounded browser publication supplements."""
from hashlib import sha256
import json
from .domain import canonical,fields,identity
from .browser_transition_records import BrowserTransitionRecords,BrowserTransitionCapture
from .combined_inference import numeric_bytes

def writer(journal):
    from .initial_mill_turn import InitialMillTurnJournal
    from .indexed_cut_journal import IndexedCutJournal
    from .turning_exchange_journal import TurningExchangeJournal
    if isinstance(journal,InitialMillTurnJournal) and journal._continuation is not None:
        service=writer(journal._continuation)
    elif isinstance(journal,TurningExchangeJournal) and journal._indexed is not None:
        service=writer(journal._indexed)
    elif isinstance(journal,(InitialMillTurnJournal,TurningExchangeJournal,IndexedCutJournal)):
        service=journal._service
    else:raise ValueError('Unsupported journal publication owner')
    if service.state.logical_hash!=journal.material.logical_hash:
        raise ValueError('Journal publication writer differs from material')
    return service

def start(session,configuration,snapshot):
    session._transition_input_hashes=(sha256(configuration).hexdigest(),sha256(snapshot).hexdigest())
    writer(session.gym._initial).enable_publication_trace()
    writer(session.gym._journal).enable_publication_trace()
    session.gym._trials=None
    session._transition_records=BrowserTransitionRecords.start(writer(session.gym._journal))

def selected(session):
    service=writer(session.gym._journal);trace=service.publication_trace
    records=session._transition_records
    if trace is None or trace.overflow or len(trace.entries)<len(records.records):
        raise ValueError('Selected publication trace is missing or exceeds its budget')
    for entry,record in zip(trace.entries,records.records):
        if entry[2]!=canonical(json.loads(record)['event']):
            raise ValueError('Selected publication trace replaces accepted history')
    sink=BrowserTransitionCapture(records)
    for before,after,raw,result in trace.entries[len(records.records):]:
        sink.publish(before,after,json.loads(raw),result,{})
    sink.synchronize(service)
    session._transition_records=sink.records

def reset(session):
    session._transition_records=BrowserTransitionRecords.start(writer(session.gym._journal))

def export(session):
    fields_to_bind=session._transition_input_hashes
    selected(session)
    episode=numeric_bytes(session.gym.export()).decode('utf-8')
    material=json.loads(session._transition_records.export(episode,
        task_sha256=fields_to_bind[0],initial_sha256=fields_to_bind[1]))
    return numeric_bytes(dict(schema='adaptive-journal-browser-transition-record-1',
        configuration_id=session.config_id,planning_head=session.gym.head,material=material)).decode('utf-8')

def restore(session,request):
    fields(request,('operation','episode','expected_export_id'))
    episode=request['episode']
    if (type(episode) is not dict or identity(episode)!=request['expected_export_id']
            or identity(episode.get('task'))!=session.gym.task_id
            or type(episode.get('records')) is not list or len(episode['records'])>session.gym.horizon):
        raise ValueError('Restore requires the same bounded journal task and exact episode')
    session.gym.reset();reset(session)
    for record in episode['records']:
        result=session.gym.step(record['action'],expected_head=session.gym.head)
        if canonical(result)!=canonical(record):raise ValueError('Journal step replay differs')
        selected(session)
    if canonical(session.gym.export())!=canonical(episode):raise ValueError('Journal final replay differs')
    session.receipts={};session.epoch+=1
    return numeric_bytes(dict(session.gym.observe(),session_epoch=session.epoch)).decode('utf-8')

def invoke_trial(session,request,invoke):
    """Called only on the private browser fork; publication follows response checks."""
    if not hasattr(session,'_transition_records'):return invoke(request)
    operation=request.get('operation')
    if operation=='export_transition_evidence':
        fields(request,('operation',));return export(session)
    if operation=='restore':return restore(session,request)
    response=invoke(request)
    if operation=='reset':reset(session)
    elif operation=='step':selected(session)
    return response
