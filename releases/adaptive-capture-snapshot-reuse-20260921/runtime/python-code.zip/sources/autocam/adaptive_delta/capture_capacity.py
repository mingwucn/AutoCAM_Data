"""Closed capture profiles; byte budgets and ordinary journals are unchanged."""
JOURNAL_RECORD_LIMIT=256

def record_limit(profile,default):
    if type(profile) is not str or profile not in ('default','bounded_journal_256'):
        raise ValueError('Unknown publication capture profile')
    return default if profile=='default' else JOURNAL_RECORD_LIMIT
