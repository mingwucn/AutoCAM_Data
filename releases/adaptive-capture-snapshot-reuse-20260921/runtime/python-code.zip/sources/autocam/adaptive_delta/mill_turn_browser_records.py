"""Bind original-stock lineage across the existing mill-turn material owners."""
from hashlib import sha256
import json

from .browser_transition_records import BrowserTransitionRecords
from .combined_inference import numeric_bytes
from .domain import fields
from .journal_browser_records import writer
from .prepared_browser_records import collect_writer


def start_compound(session, origin):
    from .prepared_browser_records import finish_initialization
    session._transition_input_hashes = (sha256(session._config).hexdigest(), sha256(session._snapshot).hexdigest())
    session._transition_records = BrowserTransitionRecords.start(origin, initial_snapshot=session._snapshot)
    finish_initialization(session)


def full_writer(session):
    journal = session.initial._journal if session.suffix is None else session.suffix.session._journal
    service = writer(journal)
    if service.state.logical_hash != session.material.logical_hash:
        raise ValueError('Full mill-turn writer differs from accepted material')
    return service


def start_full(session):
    from .full_mill_turn_browser_session import FullMillTurnBrowserSession
    if type(session) is not FullMillTurnBrowserSession:
        return
    service = full_writer(session)
    service.enable_publication_trace()
    session._transition_records = BrowserTransitionRecords.start(service, initial_snapshot=session._snapshot)
    export_full(session)


def checked_full_records(session):
    if not hasattr(session, '_transition_records'):
        raise ValueError('Unsupported full mill-turn operation')
    records = collect_writer(session._transition_records, full_writer(session))
    if records != session._transition_records:
        raise ValueError('Full mill-turn material has uncaptured accepted publications')
    return records


def selected_full(session):
    if hasattr(session, '_transition_records'):
        session._transition_records = collect_writer(session._transition_records, full_writer(session))
        export_full(session)


def export_full(session):
    from .drill_browser_session import bounded
    records = checked_full_records(session)
    episode = bounded(session.export()).decode('utf-8')
    material = json.loads(records.export(episode,
        task_sha256=sha256(session._config).hexdigest(), initial_sha256=sha256(session._snapshot).hexdigest()))
    return bounded(dict(schema='adaptive-prepared-browser-transition-record-1',
        configuration_id=session.config_id, semantic_id=session.semantic_id,
        prefix_record_count=0, material=material)).decode('utf-8')


def export_learning(session):
    from .drill_browser_session import LIMIT
    records = checked_full_records(session.gym._session)
    episode = numeric_bytes(session.gym.export()).decode('utf-8')
    material = json.loads(records.export(episode,
        task_sha256=sha256(session._configuration).hexdigest(), initial_sha256=sha256(session._snapshot).hexdigest()))
    raw = numeric_bytes(dict(schema='adaptive-mixed-learning-browser-transition-record-1',
        configuration_id=session.config_id, manifest_id=session.gym.manifest.id,
        planning_head=session.gym.head, material=material))
    if len(raw) > min(LIMIT, session.RESPONSE_BYTES):
        raise ValueError('Mixed learning transition record budget exceeded')
    return raw.decode('utf-8')


def invoke_full_export(session, request):
    fields(request, ('operation',))
    return export_full(session)
