"""Transactional inference transport over the existing mixed learning owner."""
from hashlib import sha256

from .codec import parse_canonical
from .combined_browser_session import CombinedBrowserSession, _json
from .combined_inference import numeric_bytes
from .domain import canonical, fields, identity, integer
from .mixed_learning_gym import MixedLearningGym
from .mixed_learning_inference import validate_checkpoint, model_action, mcts_action
from .mixed_learning_manifest import MixedLearningManifest
from .ordered_motion import MotionBudget


SCHEMA = 'adaptive-mixed-learning-browser-config-1'


def encode_mixed_learning_browser(configuration, initial_snapshot, **parameters):
    gym = MixedLearningGym(configuration, initial_snapshot, **parameters)
    wrapper = dict(schema=SCHEMA,
        configuration=parse_canonical(configuration, maximum_bytes=32*1024**2),
        manifest=gym.manifest.to_data())
    return canonical(wrapper), initial_snapshot


def _load(configuration, initial_snapshot):
    config = parse_canonical(configuration, maximum_bytes=32*1024**2)
    fields(config, ('schema', 'configuration', 'manifest'))
    if config['schema']!=SCHEMA: raise ValueError('Unknown mixed learning browser profile')
    manifest = MixedLearningManifest.from_data(config['manifest']); data = manifest.to_data()
    completion = data['completion']
    gym = MixedLearningGym(canonical(config['configuration']), initial_snapshot,
        horizon=data['horizon'], cost_provenance=data['cost']['provenance'],
        face_budget=MotionBudget(**completion['face_budget']),
        maximum_profiles=completion['maximum_profiles'], maximum_events=completion['maximum_events'])
    if gym.manifest.id!=manifest.id: raise ValueError('Mixed browser manifest differs from actual inputs')
    return identity(config), gym


class MixedLearningBrowserSession(CombinedBrowserSession):
    _checkpoint_validator = staticmethod(validate_checkpoint)
    _policy = staticmethod(model_action)
    _search = staticmethod(mcts_action)

    def __init__(self, configuration, initial_snapshot):
        self.config_id, self.gym = _load(configuration, initial_snapshot)
        self._configuration, self._snapshot = configuration, initial_snapshot
        self.model = None; self.receipts = {}; self.epoch = 0

    @property
    def material(self): return self.gym._session.material

    def _bindings(self):
        return dict(configuration_id=self.config_id, session_epoch=self.epoch,
            head=self.gym.head, manifest_id=self.gym.manifest.id)

    def _current(self, request):
        if type(request['session_epoch']) is not int or request['session_epoch']!=self.epoch or request['expected_head']!=self.gym.head:
            raise ValueError('Stale mixed learning browser request')

    def view(self):
        return dict(schema='adaptive-mixed-learning-browser-view-1', **self._bindings(),
            observation=self.gym.observe(), full_view=self.gym._session.view(),
            inference_available=True, model_loaded=self.model is not None,
            checkpoint_sha256=None if self.model is None else sha256(numeric_bytes(self.model)).hexdigest(),
            model_qualified=False)

    def _selected(self, response):
        if response['head']!=self.gym.head: raise ValueError('Inference returned another learning head')
        observed = self.gym.observe()
        action = integer(response['action'], 'suggested checked index', 0, len(observed['choices'])-1)
        entry = observed['choices'][action]['entry']
        return dict(response, **{k:v for k,v in self._bindings().items() if k!='head'},
            candidate_id=entry['candidate_id'], evaluation_id=entry['evaluation_id'],
            exposed_set_id=observed['bank']['exposed_set_id'])

    def _invoke(self, request):
        operation = request.get('operation')
        if operation=='export_transition_evidence':
            from .mill_turn_browser_records import export_learning
            fields(request, ('operation',))
            return export_learning(self)
        if operation=='reset':
            fields(request, ('operation',))
            config_id, fresh = _load(self._configuration, self._snapshot)
            if config_id!=self.config_id: raise ValueError('Reset wrapper identity differs')
            if self.model is not None: self._checkpoint_validator(fresh, self.model)
            self.gym = fresh; self.receipts = {}; self.epoch += 1
            response = dict(self.gym.observe(), session_epoch=self.epoch)
        elif operation=='restore':
            fields(request, ('operation', 'episode', 'expected_export_id'))
            episode = request['episode']
            if (type(episode) is not dict or episode.get('schema')!='adaptive-mixed-learning-episode-1'
                    or MixedLearningManifest.from_data(episode.get('manifest')).id!=self.gym.manifest.id):
                raise ValueError('Restore requires the same mixed learning experiment')
            restored = MixedLearningGym.replay(episode, expected_export_id=request['expected_export_id'])
            if self.model is not None: self._checkpoint_validator(restored, self.model)
            self.gym = restored; self.receipts = {}; self.epoch += 1
            response = dict(self.gym.observe(), session_epoch=self.epoch)
        elif operation in ('geometry', 'preview'):
            fields(request, ('operation', 'expected_head', 'session_epoch', 'action') if operation=='preview'
                else ('operation', 'expected_head', 'session_epoch'))
            self._current(request)
            if operation=='geometry':
                response = dict(schema='adaptive-mixed-learning-browser-geometry-1', **self._bindings(),
                    preview=False, geometry=self.gym._session.geometry())
            else:
                observed = self.gym.observe()
                if observed['terminated'] or observed['truncated']: raise ValueError('No preview after learning episode ends')
                action = integer(request['action'], 'preview checked index', 0, len(observed['choices'])-1)
                entry = observed['choices'][action]['entry']
                branch = self.gym._actions().selected_branch(self.gym._session, entry['candidate_id'])
                response = dict(schema='adaptive-mixed-learning-browser-geometry-1', **self._bindings(),
                    preview=True, action=action, candidate_id=entry['candidate_id'], evaluation_id=entry['evaluation_id'],
                    exposed_set_id=observed['bank']['exposed_set_id'], geometry=branch.geometry())
        elif operation=='search':
            fields(request, ('operation', 'simulations', 'depth', 'exploration') if 'exploration' in request
                else ('operation', 'simulations', 'depth'))
            if self.model is None: raise ValueError('Load a mixed learning checkpoint first')
            action, trace = self._search(self.gym, self.model, simulations=request['simulations'],
                depth=request['depth'], exploration=request.get('exploration', 1.0))
            response = self._selected(dict(action=action, trace=trace, head=self.gym.head))
        elif operation=='suggest':
            response = self._selected(_json(super()._invoke(request), self.RESPONSE_BYTES))
        else:
            raw = super()._invoke(request)
            if operation=='step':
                from .mill_turn_browser_records import export_learning
                export_learning(self)
            return raw
        if operation in ('reset','restore'):
            from .mill_turn_browser_records import export_learning
            export_learning(self)
        return numeric_bytes(response).decode('utf-8')
