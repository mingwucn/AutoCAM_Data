"""Material recording at the existing prepared-browser acceptance boundary."""
from hashlib import sha256
import json

from .browser_transition_records import BrowserTransitionRecords, BrowserTransitionCapture
from .domain import canonical, fields
from .journal_browser_records import writer


def start(session, configuration, snapshot):
    # Other transports inherit drill methods but own different prefix histories.
    from .drill_browser_session import DrillBrowserSession
    from .face_browser_session import FaceBrowserSession
    if type(session) not in (DrillBrowserSession, FaceBrowserSession):
        return
    session._transition_input_hashes = (sha256(configuration).hexdigest(), sha256(snapshot).hexdigest())
    session._initial.enable_publication_trace()
    session._transition_records = BrowserTransitionRecords.start(session._initial, initial_snapshot=snapshot)


def collect(session):
    return collect_writer(session._transition_records, writer(session.session._journal))


def collect_writer(records, service):
    """Read only accepted publications from the caller's actual selected writer."""
    trace = service.publication_trace
    if trace is None or trace.overflow or len(trace.entries) < len(records.records):
        raise ValueError('Prepared publication trace is missing or exceeds its budget')
    for entry, record in zip(trace.entries, records.records):
        if entry[2] != canonical(json.loads(record)['event']):
            raise ValueError('Prepared publication replaces accepted history')
    sink = BrowserTransitionCapture(records)
    for before, after, raw, result in trace.entries[len(records.records):]:
        sink.publish(before, after, json.loads(raw), result, {})
    sink.synchronize(service)
    return sink.records


def finish_initialization(session):
    if not hasattr(session, '_transition_records'):
        return
    session._transition_records = collect(session)
    session._transition_prefix_count = len(session._transition_records.records)
    export(session)


def selected(session):
    if hasattr(session, '_transition_records'):
        session._transition_records = collect(session)
        # Check the complete supplement before the caller adopts this private trial.
        export(session)


def export(session):
    from .drill_browser_session import bounded
    if not hasattr(session, '_transition_records'):
        raise ValueError('Unsupported drill browser operation')
    if collect(session) != session._transition_records:
        raise ValueError('Prepared material has uncaptured accepted publications')
    episode = bounded(session.export()).decode('utf-8')
    task_hash, initial_hash = session._transition_input_hashes
    material = json.loads(session._transition_records.export(episode,
        task_sha256=task_hash, initial_sha256=initial_hash))
    return bounded(dict(schema='adaptive-prepared-browser-transition-record-1',
        configuration_id=session.config_id, semantic_id=session.session.semantic_id,
        prefix_record_count=session._transition_prefix_count, material=material)).decode('utf-8')


def invoke_export(session, request):
    fields(request, ('operation',))
    return export(session)
