"""Frozen controller fixture; not an industrial case or learned checkpoint."""
import base64
from hashlib import sha256
import json

from autocam.adaptive_delta.bounded_mill_turn_features import bounded_mill_turn_checkpoint
from autocam.adaptive_delta.bounded_mill_turn_replay import verify_bounded_mill_turn_trajectory
from autocam.adaptive_delta.bounded_mill_turn_tasks import BoundedMillTurnTask, execution_budget
from autocam.adaptive_delta.browser_session import BrowserSession, encoded
from autocam.adaptive_delta.codec import encode_snapshot
from autocam.adaptive_delta.domain import Root, canonical, fields
from autocam.adaptive_delta.fixtures import box
from autocam.adaptive_delta.geometry import Empty
from autocam.adaptive_delta.partition import DomainBuilder, SourceDomain
from autocam.adaptive_delta.turning_tools import TurningAxis, teaching_mill_turn_catalog
from autocam.adaptive_delta.tool_catalog import ToolCatalog


def fixture():
    source = SourceDomain(box((0, 0, 0), (4, 4, 4)), Empty(), Empty(), Root((0, 0, 0), 8))
    catalog = ToolCatalog(tuple(t for t in teaching_mill_turn_catalog().tools
                                if t.tool_id in ('flat_end-short', 'turning-blade-short')))
    task = BoundedMillTurnTask('browser_controller_fixture', 'Z', 'train', source, catalog,
                              TurningAxis(2, (0, 0, 0)), 0, 1, (box(('3/2',)*3, ('5/2',)*3),), 1)
    initial = DomainBuilder().build(source, execution_budget())
    return task, initial


def perform(session, command, files):
    """Only closed commands and preloaded bytes; never evaluate a supplied string."""
    try:
        if command.get('kind') == 'invoke':
            fields(command, ('kind', 'request_raw'))
            raw = session.invoke(command['request_raw'].encode('utf-8'))
        elif command.get('kind') == 'load_model':
            fields(command, ('kind', 'file', 'expected_sha256'))
            raw = session.load_model(files[command['file']], command['expected_sha256'])
        else:
            raise ValueError('Unknown probe command kind')
        return encoded(dict(ok=True, raw=raw))
    except (ValueError, KeyError, TypeError) as error:
        return encoded(dict(ok=False, error_type=type(error).__name__, message=str(error)))


def commands_for(session, checkpoint_sha):
    initial = json.loads(session.invoke(canonical(dict(operation='reset', seed=301))))
    safe = next(i for i in range(len(session.task.candidates)) if initial['observation']['mask'][i])
    rejected = next(i for i, safety in enumerate(session.env.safety) if safety.status == 'REJECTED')
    refine = len(session.task.candidates)
    commands = []
    def invoke(**data): commands.append(dict(kind='invoke', request_raw=encoded(data)))
    def model(pin): commands.append(dict(kind='load_model', file='checkpoint.json', expected_sha256=pin))
    invoke(operation='reset', seed=301)
    invoke(operation='step', action=safe)
    invoke(operation='step', action=safe)
    invoke(operation='step', action=refine)
    invoke(operation='step', action=refine)
    invoke(operation='export')
    invoke(operation='reset', seed=302)
    invoke(operation='step', action=rejected)
    invoke(operation='export')
    invoke(operation='reset', seed=303)
    model(checkpoint_sha)
    invoke(operation='infer_step', policy='model', seed=320)
    invoke(operation='infer_step', policy='model_mcts', seed=321)
    invoke(operation='export')
    invoke(operation='reset', seed=304)
    invoke(operation='export')
    invoke(operation='eval', code='raise RuntimeError("must remain data")')
    commands.append(dict(kind='invoke', request_raw='{'))
    invoke(operation='step', action=True)
    invoke(operation='step', action=505)
    model('0'*64)
    invoke(operation='infer_step', policy='unknown', seed=321)
    invoke(operation='export')
    return commands, dict(safe_candidate=safe, rejected_candidate=rejected, refinement_candidate=refine)


def verify_responses(task, initial, checkpoint_raw, responses):
    values = [json.loads(raw) for raw in responses]
    error_indices = list(range(16, 22))
    if [i for i, value in enumerate(values) if not value['ok']] != error_indices:
        raise ValueError('Unexpected controller error denominator')
    decoded = [json.loads(v['raw']) if v['ok'] else None for v in values]
    for index in (2, 3, 4):
        if decoded[index]['info']['transition']['reward_components']['new_eligible_credit'] != [0, 1]:
            raise ValueError('Repeat/refinement earned new material credit')
    rejected = decoded[7]['info']['transition']
    if rejected['result']['status'] != 'REJECTED' or decoded[6]['info']['state_hash'] != decoded[7]['info']['state_hash']:
        raise ValueError('Rejected attempt changed material or was not rejected')
    if values[15]['raw'] != values[22]['raw']:
        raise ValueError('Malformed request changed exported session')
    replay = []
    expected_initial = encode_snapshot(initial)
    for index in (5, 8, 13):
        episode = decoded[index]
        initial_raw = base64.b64decode(episode['initial_snapshot_base64'], validate=True)
        if initial_raw != expected_initial or sha256(initial_raw).hexdigest() != episode['initial_snapshot_sha256']:
            raise ValueError('Export changed initial bytes')
        record = verify_bounded_mill_turn_trajectory(task, initial, episode['trajectory'])
        if record['final_state_hash'] != episode['final_state_hash'] or record['final_planning_state'] != episode['final_planning_state']:
            raise ValueError('Export final identities differ from material-service replay')
        replay.append(dict(export_response=index, verification=record))
    inferred = decoded[13]
    pin = sha256(checkpoint_raw).hexdigest()
    if inferred['checkpoint_sha256'] != pin or inferred['checkpoint'] != json.loads(checkpoint_raw):
        raise ValueError('Inference changed weights')
    if base64.b64decode(inferred['checkpoints_base64'][pin], validate=True) != checkpoint_raw:
        raise ValueError('Export changed original checkpoint bytes')
    traces = [r['trace'] for r in inferred['records'] if r['operation'] == 'infer_step']
    if [t['mode'] for t in traces] != ['model', 'model_mcts']:
        raise ValueError('Missing model or MCTS execution')
    search = traces[1]['search']
    if (search['simulations'], search['depth_limit'], search['seed']) != (4, 2, 321):
        raise ValueError('Search budget or seed changed')
    return dict(status='passed', responses=len(values), expected_errors=len(error_indices),
                replayed_episodes=3, replayed_transitions=7, replay=replay,
                repeat_refinement_credit_zero=True, rejection_material_unchanged=True,
                malformed_requests_export_unchanged=True, initial_checkpoint_bytes_unchanged=True,
                model_and_mcts_executed=True, trained_model=False, training_performed=False)


def prepare(output):
    task, initial = fixture()
    task_raw = canonical(task.to_data()); initial_raw = encode_snapshot(initial)
    checkpoint_raw = (encoded(bounded_mill_turn_checkpoint([0.0]*54))+'\n').encode('utf-8')
    session = BrowserSession(task_raw, initial_raw)
    commands, choices = commands_for(session, sha256(checkpoint_raw).hexdigest())
    for name, raw in (('task.json', task_raw), ('initial.bin', initial_raw), ('checkpoint.json', checkpoint_raw)):
        (output/name).write_bytes(raw)
    (output/'commands.json').write_text(encoded(commands)+'\n', encoding='utf-8')
    responses = []
    for index, command in enumerate(commands):
        raw = perform(session, command, {'checkpoint.json': checkpoint_raw})
        (output/f'expected-{index}.json').write_text(raw, encoding='utf-8'); responses.append(raw)
        print(encoded(dict(phase='local_controller_response', index=index)), flush=True)
    verification = verify_responses(task, initial, checkpoint_raw, responses)
    (output/'local-verification.json').write_text(encoded(dict(**verification, choices=choices))+'\n', encoding='utf-8')
    return commands, verification
