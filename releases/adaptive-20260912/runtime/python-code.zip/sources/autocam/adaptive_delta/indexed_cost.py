"""Frozen rational time estimates for checked indexed operations."""
from dataclasses import dataclass
from .domain import digest, fields, identity, qdata, qread, rational, triple
from .tool_catalog import MillingTool, AxialPlunge
from .side_milling import SideMill


def path_length(points):
    values = tuple(triple(p) for p in points)
    return sum((sum(abs(b-a) for a,b in zip(first,last)) for first,last in zip(values,values[1:])), rational(0))


@dataclass(frozen=True, slots=True)
class IndexedCostModel:
    machine_id: str
    catalog_id: str
    rapid_mm_per_second: object
    cutting_rates: tuple
    index_times: tuple

    def __post_init__(self):
        digest(self.machine_id); digest(self.catalog_id)
        speed=rational(self.rapid_mm_per_second)
        if speed <= 0: raise ValueError('Positive rapid rate required')
        object.__setattr__(self,'rapid_mm_per_second',speed)
        cuts=tuple((tool,method,rational(rate)) for tool,method,rate in self.cutting_rates)
        indices=tuple((before,after,rational(seconds)) for before,after,seconds in self.index_times)
        if not 1 <= len(cuts) <= 512 or len(indices) > 65536: raise ValueError('Cost table budget')
        if len({r[:2] for r in cuts}) != len(cuts) or len({r[:2] for r in indices}) != len(indices):
            raise ValueError('Duplicate cost table entry')
        for tool,method,rate in cuts:
            if type(tool) is not str or not tool or method not in ('plunge','side') or rate <= 0: raise ValueError('Invalid cutting rate')
        for before,after,seconds in indices:
            digest(before); digest(after)
            if before == after or seconds <= 0: raise ValueError('Invalid index time')
        object.__setattr__(self,'cutting_rates',tuple(sorted(cuts)))
        object.__setattr__(self,'index_times',tuple(sorted(indices)))

    def validate_context(self,machine,catalog):
        if machine.id != self.machine_id or catalog.id != self.catalog_id: raise ValueError('Cost context mismatch')
        poses={p.id for p in machine.orientations}
        if {r[:2] for r in self.index_times} != {(a,b) for a in poses for b in poses if a != b}:
            raise ValueError('Complete ordered index table required')
        tools={t.tool_id for t in catalog.tools if type(t) is MillingTool}
        if {r[:2] for r in self.cutting_rates} != {(t,m) for t in tools for m in ('plunge','side')}:
            raise ValueError('Complete milling method rates required')

    @property
    def id(self): return identity(self.to_data())

    def to_data(self):
        return dict(schema='adaptive-indexed-cost-1',machine_id=self.machine_id,catalog_id=self.catalog_id,
                    rapid_mm_per_second=qdata(self.rapid_mm_per_second),
                    cutting_rates=[[t,m,qdata(v)] for t,m,v in self.cutting_rates],
                    index_times=[[a,b,qdata(v)] for a,b,v in self.index_times])

    @classmethod
    def from_data(cls,data):
        fields(data,('schema','machine_id','catalog_id','rapid_mm_per_second','cutting_rates','index_times'))
        if data['schema'] != 'adaptive-indexed-cost-1': raise ValueError('Unsupported indexed cost schema')
        result=cls(data['machine_id'],data['catalog_id'],qread(data['rapid_mm_per_second']),
                   tuple((t,m,qread(v)) for t,m,v in data['cutting_rates']),tuple((a,b,qread(v)) for a,b,v in data['index_times']))
        if result.to_data() != data: raise ValueError('Noncanonical cost table')
        return result

    def estimate(self,*,motion=None,tool_id=None,approach=(),retract=None,before=None,after=None):
        cutting=rational(0); indexing=rational(0)
        if motion is not None:
            if type(motion) not in (AxialPlunge,SideMill): raise ValueError('Supported world motion required')
            method='side' if type(motion) is SideMill else 'plunge'
            rate=next((r for t,m,r in self.cutting_rates if (t,m)==(tool_id,method)),None)
            if rate is None: raise ValueError('Missing cutting rate')
            cutting=path_length((motion.start_tip,motion.end_tip))*rate
        if before != after:
            indexing=next((v for a,b,v in self.index_times if (a,b)==(before,after)),None)
            if indexing is None: raise ValueError('Missing index time')
        retraction=path_length((retract.start_tip,retract.end_tip))/self.rapid_mm_per_second if retract is not None else rational(0)
        approach_time=path_length(approach)/self.rapid_mm_per_second
        parts=dict(cutting=cutting,approach=approach_time,retract=retraction,index=indexing)
        return dict(schema='adaptive-indexed-time-estimate-1',model_id=self.id,units='seconds',
                    approach_metric='L1_segment_length',components={k:qdata(v) for k,v in parts.items()},
                    total_seconds=qdata(sum(parts.values(),rational(0))))
