"""Complete-cell exact analytic predicates. No CAD or sampling dependencies."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Protocol

from .domain import Bounds, Relation, fields, identity, integer, qdata, qread, rational, triple

I, O, M = Relation.INSIDE, Relation.OUTSIDE, Relation.MIXED


class Region(Protocol):
    def classify(self, query: Bounds, *, interior=False) -> Relation: ...
    def to_data(self) -> dict: ...
    @property
    def bounds(self) -> Bounds | None: ...


@dataclass(frozen=True, slots=True)
class Empty:
    @property
    def bounds(self):
        return None

    def classify(self, query, *, interior=False):
        return O

    def to_data(self):
        return {"kind": "empty"}


@dataclass(frozen=True, slots=True)
class Box:
    bounds: Bounds

    def __post_init__(self):
        if not isinstance(self.bounds, Bounds):
            raise ValueError("Box requires exact bounds")

    def classify(self, query, *, interior=False):
        a, b, x, y = self.bounds.low, self.bounds.high, query.low, query.high
        if interior:
            if any(y[k] <= a[k] or x[k] >= b[k] for k in range(3)):
                return O
            return I if all(a[k] < x[k] and y[k] < b[k] for k in range(3)) else M
        if any(y[k] < a[k] or x[k] > b[k] for k in range(3)):
            return O
        return I if all(a[k] <= x[k] and y[k] <= b[k] for k in range(3)) else M

    def to_data(self):
        return {"kind": "box", "bounds": self.bounds.to_data()}


@dataclass(frozen=True, slots=True)
class Cylinder:
    axis: int
    center: tuple
    radius: Fraction
    low: Fraction
    high: Fraction

    def __post_init__(self):
        integer(self.axis, "principal cylinder axis", 0, 2)
        object.__setattr__(self, "center", tuple(rational(v) for v in self.center))
        for field in ("radius", "low", "high"):
            object.__setattr__(self, field, rational(getattr(self, field)))
        if len(self.center) != 2 or self.radius <= 0 or self.low >= self.high:
            raise ValueError("Invalid cylinder")

    @property
    def radial_axes(self):
        return tuple(k for k in range(3) if k != self.axis)

    @property
    def bounds(self):
        low, high = [self.low]*3, [self.high]*3
        for k, center in zip(self.radial_axes, self.center):
            low[k], high[k] = center-self.radius, center+self.radius
        return Bounds(tuple(low), tuple(high))

    def radial_squared_bounds(self, query):
        minima, maxima = [], []
        for k, c in zip(self.radial_axes, self.center):
            a, b = query.low[k]-c, query.high[k]-c
            minima.append(0 if a <= 0 <= b else min(a*a, b*b))
            maxima.append(max(a*a, b*b))
        return sum(minima, Fraction()), sum(maxima, Fraction())

    def classify(self, query, *, interior=False):
        lo, hi = query.low[self.axis], query.high[self.axis]
        if (hi <= self.low or lo >= self.high) if interior else (hi < self.low or lo > self.high):
            return O
        rlo, rhi = self.radial_squared_bounds(query)
        r2 = self.radius*self.radius
        if interior:
            if hi <= self.low or lo >= self.high or rlo >= r2:
                return O
            return I if self.low < lo and hi < self.high and rhi < r2 else M
        if hi < self.low or lo > self.high or rlo > r2:
            return O
        return I if self.low <= lo and hi <= self.high and rhi <= r2 else M

    def to_data(self):
        return {"kind": "cylinder", "axis": self.axis, "center": [qdata(v) for v in self.center],
                "radius": qdata(self.radius), "low": qdata(self.low), "high": qdata(self.high)}


@dataclass(frozen=True, slots=True)
class Sphere:
    center: tuple
    radius: Fraction

    def __post_init__(self):
        object.__setattr__(self, "center", triple(self.center))
        object.__setattr__(self, "radius", rational(self.radius))
        if self.radius <= 0:
            raise ValueError("Sphere radius must be positive")

    @property
    def bounds(self):
        return Bounds(tuple(c-self.radius for c in self.center),
                      tuple(c+self.radius for c in self.center))

    def classify(self, query, *, interior=False):
        minimum, maximum = Fraction(), Fraction()
        for a, b, center in zip(query.low, query.high, self.center):
            lo, hi = a-center, b-center
            minimum += 0 if lo <= 0 <= hi else min(lo*lo, hi*hi)
            maximum += max(lo*lo, hi*hi)
        radius2 = self.radius*self.radius
        if interior:
            return O if minimum >= radius2 else (I if maximum < radius2 else M)
        return O if minimum > radius2 else (I if maximum <= radius2 else M)

    def to_data(self):
        return {"kind": "sphere", "center": [qdata(c) for c in self.center], "radius": qdata(self.radius)}


@dataclass(frozen=True, slots=True)
class Union:
    children: tuple

    def __post_init__(self):
        object.__setattr__(self, "children", tuple(self.children))
        for child in self.children:
            region_id(child)

    @property
    def bounds(self):
        boxes = [c.bounds for c in self.children if c.bounds is not None]
        if not boxes:
            return None
        return Bounds(tuple(min(b.low[k] for b in boxes) for k in range(3)),
                      tuple(max(b.high[k] for b in boxes) for k in range(3)))

    def classify(self, query, *, interior=False):
        # Sufficient whole-cell proofs; union coverage may require refinement.
        relations = [c.classify(query, interior=interior) for c in self.children]
        if I in relations:
            return I
        return O if all(r == O for r in relations) else M

    def to_data(self):
        return {"kind": "union", "children": [c.to_data() for c in self.children]}


@dataclass(frozen=True, slots=True)
class Cutout:
    """Closed base minus open cutters; no general solid regularization claim."""
    base: Region
    cutters: tuple

    def __post_init__(self):
        object.__setattr__(self, "cutters", tuple(self.cutters))
        region_id(self.base)
        for cutter in self.cutters:
            region_id(cutter)

    @property
    def bounds(self):
        return self.base.bounds

    def classify(self, query, *, interior=False):
        base = self.base.classify(query, interior=interior)
        if base == O:
            return O
        # For a closed remainder exclude cutter interiors; for interior
        # certification conservatively exclude their closed supports.
        cuts = [c.classify(query, interior=not interior) for c in self.cutters]
        if I in cuts:
            return O
        return I if base == I and all(c == O for c in cuts) else M

    def to_data(self):
        return {"kind": "cutout", "base": self.base.to_data(), "cutters": [c.to_data() for c in self.cutters]}


@dataclass(frozen=True, slots=True)
class UnresolvedRegion:
    """Explicit unsupported-source sentinel; never strict-task admission."""
    source_id: str
    bounds: Bounds

    def __post_init__(self):
        if type(self.source_id) is not str or not self.source_id:
            raise ValueError("Unresolved source must have an identity")

    def classify(self, query, *, interior=False):
        return M

    def to_data(self):
        return {"kind": "unresolved", "source_id": self.source_id, "bounds": self.bounds.to_data()}


@dataclass(frozen=True, slots=True)
class IndexedSolid:
    """Rigidly transformed analytic set with conservative exact cell predicates."""
    base: Region
    pose: object

    def __post_init__(self):
        from .indexed_frames import IndexedOrientation
        if not supported(self.base) or type(self.pose) is not IndexedOrientation:
            raise ValueError('Supported base and exact indexed pose required')

    @property
    def bounds(self):
        return None if self.base.bounds is None else self.pose.enclose(self.base.bounds)

    def classify(self, query, *, interior=False):
        from .indexed_queries import transform_query
        return self.base.classify(transform_query(self.pose.inverse(), query), interior=interior)

    def to_data(self):
        return dict(kind='indexed_solid_1', base=self.base.to_data(), pose=self.pose.to_data())


def region_id(region):
    if not isinstance(region, (Box, Cylinder, Sphere, Empty, Union, Cutout, UnresolvedRegion, IndexedSolid)):
        raise ValueError("Unsupported region type")
    return identity(region.to_data())


def supported(region):
    if isinstance(region, IndexedSolid):
        return supported(region.base)
    if isinstance(region, UnresolvedRegion):
        return False
    if isinstance(region, Union):
        return all(supported(c) for c in region.children)
    if isinstance(region, Cutout):
        return supported(region.base) and all(supported(c) for c in region.cutters)
    return isinstance(region, (Box, Cylinder, Sphere, Empty))


def has_sphere(region):
    if isinstance(region, IndexedSolid):
        return has_sphere(region.base)
    if isinstance(region, Union):
        return any(has_sphere(c) for c in region.children)
    if isinstance(region, Cutout):
        return has_sphere(region.base) or any(has_sphere(c) for c in region.cutters)
    return isinstance(region, Sphere)


def from_data(data, _depth=0):
    if _depth > 64 or not isinstance(data, dict):
        raise ValueError("Invalid or excessive region nesting")
    kind = data.get("kind")
    if kind == 'indexed_solid_1':
        from .indexed_frames import IndexedOrientation
        fields(data, ('kind', 'base', 'pose'))
        return IndexedSolid(from_data(data['base'], _depth+1), IndexedOrientation.from_data(data['pose']))
    if kind == "empty":
        fields(data, ("kind",)); return Empty()
    if kind == "box":
        fields(data, ("kind", "bounds")); return Box(Bounds.from_data(data["bounds"]))
    if kind == "cylinder":
        fields(data, ("kind", "axis", "center", "radius", "low", "high"))
        return Cylinder(data["axis"], tuple(qread(v) for v in data["center"]),
                        qread(data["radius"]), qread(data["low"]), qread(data["high"]))
    if kind == "sphere":
        fields(data, ("kind", "center", "radius"))
        return Sphere(tuple(qread(v) for v in data["center"]), qread(data["radius"]))
    if kind == "union":
        fields(data, ("kind", "children"))
        return Union(tuple(from_data(c, _depth+1) for c in data["children"]))
    if kind == "cutout":
        fields(data, ("kind", "base", "cutters"))
        return Cutout(from_data(data["base"], _depth+1), tuple(from_data(c, _depth+1) for c in data["cutters"]))
    if kind == "unresolved":
        fields(data, ("kind", "source_id", "bounds"))
        return UnresolvedRegion(data["source_id"], Bounds.from_data(data["bounds"]))
    raise ValueError("Unsupported region encoding")
