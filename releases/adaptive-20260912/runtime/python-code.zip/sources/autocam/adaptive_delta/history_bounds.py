"""Residual-only projection from original material and accepted union coverage."""
from fractions import Fraction

from .domain import Relation
from .partition import VolumeInterval
from .transitions import MaterialState

HISTORY_DIFFERENCE_PROFILE = 'initial_material_minus_accepted_shadow_union_1'


def remaining_from_history(state, *, eligible=False):
    """Tighten residual bounds without inferring additional removal credit.

    This is Delta or Q remaining, not physical stock (which includes target).
    The legacy projection, state identities and writer rewards are unchanged.
    """
    if not isinstance(state, MaterialState) or type(eligible) is not bool:
        raise ValueError('Typed material state and explicit boolean role required')
    lower, upper = Fraction(), Fraction()
    role = 'eligible' if eligible else 'delta'
    root_volume = state.domain.source.root.side**3
    volumes = {}
    for leaf in state.domain.leaves:
        if not getattr(leaf, role+'_upper'): continue
        relation = state.history_relation(leaf.address)
        depth = leaf.address.depth
        if depth not in volumes: volumes[depth] = root_volume/(1 << (3*depth))
        if getattr(leaf, role+'_lower') and relation == Relation.OUTSIDE: lower += volumes[depth]
        if relation != Relation.INSIDE: upper += volumes[depth]
    return VolumeInterval(lower, upper)
