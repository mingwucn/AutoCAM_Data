"""Optional immutable speculative writer events; never an accepted browser record."""
from dataclasses import dataclass
from .domain import canonical

MAX_EVENTS=128
MAX_EVENT_BYTES=64*1024**2

@dataclass(frozen=True, slots=True)
class PublicationTrace:
    entries: tuple=()
    size: int=0
    overflow: bool=False

    def append(self,before,after,event,result):
        if self.overflow:return self
        raw=canonical(event)
        if len(self.entries)>=MAX_EVENTS or self.size+len(raw)>MAX_EVENT_BYTES:
            return PublicationTrace(self.entries,self.size,True)
        return PublicationTrace(self.entries+((before,after,raw,result),),self.size+len(raw))
